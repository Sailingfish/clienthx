package com.szkingdom.kcbpcli;

public class tagKCBPConnectOption {

	public String szServerName;
	public int nProtocal;
	public String szAddress;
	public int nPort;
	public String szSendQName;
	public String szReceiveQName;
	public String szReserved;
	private String username;
	private String password;
	private String strProtocal;
	private String strPort;

	public tagKCBPConnectOption() {
		szServerName = new String();
		szAddress = new String();
		szSendQName = new String();
		szReceiveQName = new String();
		szReserved = new String();
	}

	public tagKCBPConnectOption(String szServerName, String username,
			String password, String strProtocal, String szAddress,
			String strPort, String szSendQName, String szReceiveQName) {
		this.szServerName = szServerName;
		this.username = username;
		this.password = password;
		this.strProtocal = strProtocal;
		this.szAddress = szAddress;
		this.strPort = strPort;
		this.szSendQName = szSendQName;
		this.szReceiveQName = szReceiveQName;
	}

	public String getSzServerName() {
		return szServerName;
	}

	public void setSzServerName(String szServerName) {
		this.szServerName = szServerName;
	}

	public String getSzAddress() {
		return szAddress;
	}

	public void setSzAddress(String szAddress) {
		this.szAddress = szAddress;
	}

	public String getSzSendQName() {
		return szSendQName;
	}

	public void setSzSendQName(String szSendQName) {
		this.szSendQName = szSendQName;
	}

	public String getSzReceiveQName() {
		return szReceiveQName;
	}

	public void setSzReceiveQName(String szReceiveQName) {
		this.szReceiveQName = szReceiveQName;
	}

	public String getSzReserved() {
		return szReserved;
	}

	public void setSzReserved(String szReserved) {
		this.szReserved = szReserved;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getStrProtocal() {
		return strProtocal;
	}

	public void setStrProtocal(String strProtocal) {
		this.strProtocal = strProtocal;
	}

	public String getStrPort() {
		return strPort;
	}

	public void setStrPort(String strPort) {
		this.strPort = strPort;
	}
}
