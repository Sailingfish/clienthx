package com.szkingdom.kcbpcli;

public class KCBPClientC {

	public static final int KCBP_OPTION_CONNECT = 0;
	public static final int KCBP_OPTION_TIMEOUT = 1;
	public static final int KCBP_OPTION_TRACE = 2;
	public static final int KCBP_OPTION_CRYPT = 3;
	public static final int KCBP_OPTION_COMPRESS = 4;
	public static final int KCBP_OPTION_PARITY = 5;
	public static final int KCBP_OPTION_SEQUENCE = 6;
	public static final int KCBP_OPTION_CURRENT_CONNECT = 7;
	public static final int KCBP_OPTION_CONNECT_HANDLE = 8;
	public static final int KCBP_OPTION_CONFIRM = 9;
	public static final int KCBP_OPTION_NULL_PASS = 10;
	public static final int KCBP_OPTION_TIME_COST = 11;
	public static final int KCBP_OPTION_CONNECT_EX = 12;
	public static final int KCBP_OPTION_CURRENT_CONNECT_EX = 13;
	public static final int KCBP_OPTION_AUTHENTICATION = 14;
	public static final int KCBP_PARAM_NODE = 0;
	public static final int KCBP_PARAM_CLIENT_MAC = 1;
	public static final int KCBP_PARAM_CONNECTION_ID = 2;
	public static final int KCBP_PARAM_SERIAL = 3;
	public static final int KCBP_PARAM_USERNAME = 4;
	public static final int KCBP_PARAM_PACKETTYPE = 5;
	public static final int KCBP_PARAM_PACKAGETYPE = 5;
	public static final int KCBP_PARAM_SERVICENAME = 6;
	public static final int KCBP_PARAM_RESERVED = 7;
	public static final int KCBP_PARAM_DESTNODE = 8;

	public KCBPClientC() {
	}
}
