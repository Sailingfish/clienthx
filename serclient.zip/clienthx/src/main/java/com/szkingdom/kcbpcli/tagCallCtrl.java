package com.szkingdom.kcbpcli;

public class tagCallCtrl {

	public int nFlags;
	public String szId;
	public String szMsgId;
	public String szCorrId;
	public int nExpiry;
	public int nPriority;
	public int tTimeStamp;

	public tagCallCtrl() {
		szId = new String();
		szMsgId = new String();
		szCorrId = new String();
	}
}
