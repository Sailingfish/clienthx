package com.szkingdom.kcbpcli;

public class KCBPInt {

	public int x;

	public KCBPInt() {
		x = 0;
	}

	public int getX() {
		return x;
	}

	public void setX(int s) {
		x = s;
	}
}
