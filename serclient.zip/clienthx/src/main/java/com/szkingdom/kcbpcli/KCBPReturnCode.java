package com.szkingdom.kcbpcli;

public class KCBPReturnCode {

	public static final int RC_OK = 0;
	public static final int RC_ERROR = 1;

	public KCBPReturnCode() {
	}
}
