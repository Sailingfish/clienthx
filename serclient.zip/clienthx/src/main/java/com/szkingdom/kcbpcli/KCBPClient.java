package com.szkingdom.kcbpcli;

import java.io.*;
import java.net.URL;

public class KCBPClient {

	public KCBPClient() {
	}

	public native int KCBPCLI_Init(KCBPInt kcbpint);

	public native int KCBPCLI_Exit(int i);

	public native int KCBPCLI_GetVersion(int i);

	public native int KCBPCLI_SetConnectOption(int i,
			tagKCBPConnectOption tagkcbpconnectoption);

	public native int KCBPCLI_GetConnectOption(int i,
			tagKCBPConnectOption tagkcbpconnectoption);

	public native int KCBPCLI_ConnectServer(int i, String s, String s1,
			String s2);

	public native int KCBPCLI_DisConnect(int i);

	public native int KCBPCLI_DisConnectForce(int i);

	public native int KCBPCLI_BeginWrite(int i);

	public native int KCBPCLI_CallProgramAndCommit(int i, String s);

	public native int KCBPCLI_CallProgram(int i, String s);

	public native int KCBPCLI_Commit(int i);

	public native int KCBPCLI_RollBack(int i);

	public native int KCBPCLI_ACallProgramAndCommit(int i, String s,
			tagCallCtrl tagcallctrl);

	public native int KCBPCLI_ACallProgram(int i, String s,
			tagCallCtrl tagcallctrl);

	public native int KCBPCLI_GetReply(int i, tagCallCtrl tagcallctrl);

	public native int KCBPCLI_Cancel(int i, tagCallCtrl tagcallctrl);

	public native String KCBPCLI_GetValue(int i, String s, int j);

	public native int KCBPCLI_SetValue(int i, String s, String s1);

	public native int KCBPCLI_RsCreate(int i, String s, int j, String s1);

	public native int KCBPCLI_RsNewTable(int i, String s, int j, String s1);

	public native int KCBPCLI_RsAddRow(int i);

	public native int KCBPCLI_RsSaveRow(int i);

	public native int KCBPCLI_RsSetCol(int i, int j, String s);

	public native int KCBPCLI_RsSetColByName(int i, String s, String s1);

	public native int KCBPCLI_RsOpen(int i);

	public native int KCBPCLI_RsMore(int i);

	public native int KCBPCLI_RsClose(int i);

	public native String KCBPCLI_RsGetCursorName(int i, int j);

	public native String KCBPCLI_RsGetColNames(int i, int j);

	public native String KCBPCLI_RsGetColName(int i, int j, int k);

	public native int KCBPCLI_RsFetchRow(int i);

	public native String KCBPCLI_RsGetCol(int i, int j);

	public native String KCBPCLI_RsGetColByName(int i, String s);

	public native int KCBPCLI_RsGetRowNum(int i);

	public native int KCBPCLI_RsGetColNum(int i, KCBPInt kcbpint);

	public native int KCBPCLI_RsGetTableRowNum(int i, int j);

	public native int KCBPCLI_RsGetTableColNum(int i, int j);

	public native int KCBPCLI_GetErrorCode(int i);

	public native String KCBPCLI_GetErrorMsg(int i);

	public native int KCBPCLI_GetCommLen(int i);

	public native int KCBPCLI_SetCliTimeOut(int i, int j);

	public native int KCBPCLI_SetIntOption(int i, int j, int k);

	public native int KCBPCLI_GetIntOption(int i, int j);

	public native int KCBPCLI_SetOption(int i, int j, Object obj);

	public native Object KCBPCLI_GetOption(int i, int j);

	public native int KCBPCLI_SQLConnect(int i, String s, String s1, String s2);

	public native int KCBPCLI_SQLDisconnect(int i);

	public native int KCBPCLI_SQLExecute(int i, String s);

	public native int KCBPCLI_SQLNumResultCols(int i);

	public native String KCBPCLI_SQLGetCursorName(int i, int j);

	public native String KCBPCLI_SQLGetColNames(int i, int j);

	public native String KCBPCLI_SQLGetColName(int i, int j, int k);

	public native int KCBPCLI_SQLFetch(int i);

	public native int KCBPCLI_SQLMoreResults(int i);

	public native int KCBPCLI_SQLCloseCursor(int i);

	public native int KCBPCLI_SQLEndTran(int i, int j);

	public native int KCBPCLI_Subscribe(int i, tagCallCtrl tagcallctrl,
			String s, String s1);

	public native int KCBPCLI_Unsubscribe(int i, tagCallCtrl tagcallctrl);

	public native int KCBPCLI_ReceivePublication(int i,
			tagCallCtrl tagcallctrl, byte abyte0[]);

	public native int KCBPCLI_RegisterPublisher(int i, tagCallCtrl tagcallctrl,
			String s);

	public native int KCBPCLI_DeregisterPublisher(int i, tagCallCtrl tagcallctrl);

	public native int KCBPCLI_Publish(int i, tagCallCtrl tagcallctrl, String s,
			String s1);

	public native int KCBPCLI_Notify(int i, String s, String s1, int j, int k);

	public native int KCBPCLI_Broadcast(int i, String s, String s1, String s2,
			String s3, int j, int k);

	public native int KCBPCLI_CheckUnsoliciety(int i);

	public native int KCBPCLI_SetUnsoliciety(int i);

	public native byte[] KCBPCLI_GetVal(int i, String s, KCBPInt kcbpint);

	public native int KCBPCLI_SetVal(int i, String s, byte abyte0[], int j);

	public native byte[] KCBPCLI_RsGetVal(int i, int j, KCBPInt kcbpint);

	public native byte[] KCBPCLI_RsGetValByName(int i, String s, KCBPInt kcbpint);

	public native int KCBPCLI_RsSetVal(int i, int j, byte abyte0[], int k);

	public native int KCBPCLI_RsSetValByName(int i, String s, byte abyte0[],
			int j);

	public native int KCBPCLI_SetSystemParam(int i, int j, String s);

	public native int KCBPCLI_GetSystemParam(int i, int j,
			StringBuffer stringbuffer);

	private static void loadJar(String name, String ext) throws IOException,
			SecurityException, UnsatisfiedLinkError {
		String sep = "/";
		String path = (new StringBuilder()).append(sep).append("resources")
				.append(sep).append(name).append(ext).toString();
		String tmpPath = KCBPClient.class.getClassLoader().getResource("")
				.getPath();
		File tmp = new File(tmpPath);
		if (!tmp.exists())
			tmp.mkdir();
		File jni = new File((new StringBuilder()).append(tmpPath).append(sep)
				.append(name).append(ext).toString());
		if (!jni.exists()) {
			InputStream in = KCBPClient.class.getResourceAsStream(path);
			FileOutputStream out = new FileOutputStream(jni);
			byte buf[] = new byte[1024];
			int i;
			while ((i = in.read(buf)) != -1)
				out.write(buf, 0, i);
			in.close();
			out.close();
			jni.deleteOnExit();
		}
		System.load(jni.toString());
	}

	private static void loadDll() throws SecurityException,
			UnsatisfiedLinkError, IOException {
		loadJar("libidea", ".dll");
		loadJar("libidea1", ".dll");
		loadJar("libzlib1", ".dll");
		loadJar("libzlib", ".dll");
		loadJar("libeay32", ".dll");
		loadJar("SSLeay32", ".dll");
		loadJar("libdes", ".dll");
		loadJar("libzip", ".dll");
		loadJar("kcbpcrypt", ".dll");
		loadJar("kcxpapi", ".dll");
		loadJar("KCBPCli", ".dll");
		loadJar("libKCBPCliJNI", ".dll");
	}

	private static void loadSo() throws SecurityException,
			UnsatisfiedLinkError, IOException {
		loadJar("libidea", ".so");
		loadJar("libidea1", ".so");
		loadJar("libzlib1", ".so");
		loadJar("libzlib", ".so");
		loadJar("libdes", ".so");
		loadJar("libkcbpcrypt", ".so");
		loadJar("libkcxpmq", ".so");
		loadJar("libkcbpcli", ".so");
		loadJar("libKCBPCliJNI", ".so");
	}

	static {
		String os = "windows";
		os = System.getProperty("os.name");
		os = os.trim();
		if (os.length() >= 7 && os.substring(0, 7).equalsIgnoreCase("windows"))
			os = "windows";
		try {
			if (os.equalsIgnoreCase("windows"))
				loadDll();
			else
				loadSo();
		} catch (Exception ex) {
			System.err.println((new StringBuilder())
					.append("load libKCBPCliJNI failed :")
					.append(ex.getMessage()).toString());
		}
	}
}
