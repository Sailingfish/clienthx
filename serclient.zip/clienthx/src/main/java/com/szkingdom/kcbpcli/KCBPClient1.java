package com.szkingdom.kcbpcli;

public class KCBPClient1 extends KCBPClient {

	public KCBPClient1() {
	}

	public native int KCBPCLI_SetOption(int i, int j, Object obj);

	public native Object KCBPCLI_GetOption(int i, int j);
}
