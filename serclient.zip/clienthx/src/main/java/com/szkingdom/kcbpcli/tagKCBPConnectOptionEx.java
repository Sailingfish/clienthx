package com.szkingdom.kcbpcli;

public class tagKCBPConnectOptionEx extends tagKCBPConnectOption {

	public String szProxy;
	public String szSSL;

	public tagKCBPConnectOptionEx() {
		szProxy = new String();
		szSSL = new String();
	}
}
