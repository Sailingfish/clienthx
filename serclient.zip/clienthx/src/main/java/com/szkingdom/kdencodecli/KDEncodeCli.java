package com.szkingdom.kdencodecli;

import com.szkingdom.kcbpcli.KCBPClient;
import java.io.*;
import java.net.URL;

public class KDEncodeCli {

	public KDEncodeCli() {
	}

	public native int KDEncode(int i, byte abyte0[], byte abyte1[],
			byte abyte2[]);

	public String KDComplex_Encode_Length192(String src, String key) {
		if (src == null || src.length() > 192)
			return null;
		int encodeLevel = 6;
		byte dest[] = new byte[256];
		int destLength = KDEncode(encodeLevel, src.getBytes(), dest,
				key.getBytes());
		if (destLength < 0)
			return null;
		else
			return new String(dest, 0, destLength);
	}

	public native int KDReEncode(byte abyte0[], byte abyte1[], int i,
			byte abyte2[], int j, byte abyte3[]);

	private static void loadDll() throws SecurityException,
			UnsatisfiedLinkError, IOException {
		loadJar("kdencode", ".dll");
		loadJar("libKDEncodeCliJNI", ".dll");
	}

	private static void loadJar(String name, String ext) throws IOException,
			SecurityException, UnsatisfiedLinkError {
		String sep = "/";
		String path = (new StringBuilder()).append(sep).append("resources")
				.append(sep).append(name).append(ext).toString();
		String tmpPath = (new StringBuilder())
				.append(KCBPClient.class.getClassLoader().getResource("")
						.getPath()).append(sep).append("resources").toString();
		File tmp = new File(tmpPath);
		if (!tmp.exists())
			tmp.mkdir();
		File jni = new File((new StringBuilder()).append(tmpPath).append(sep)
				.append(name).append(ext).toString());
		if (!jni.exists()) {
			InputStream in = KCBPClient.class.getResourceAsStream(path);
			FileOutputStream out = new FileOutputStream(jni);
			byte buf[] = new byte[1024];
			int i;
			while ((i = in.read(buf)) != -1)
				out.write(buf, 0, i);
			in.close();
			out.close();
			jni.deleteOnExit();
		}
		System.load(jni.toString());
	}

	private static void loadSo() throws SecurityException,
			UnsatisfiedLinkError, IOException {
		loadJar("KdEncodeCli", ".so");
		loadJar("libKDEncodeCliJNI", ".so");
	}

	static {
		String os = "windows";
		os = System.getProperty("os.name");
		os = os.trim();
		if (os.length() >= 7 && os.substring(0, 7).equalsIgnoreCase("windows"))
			os = "windows";
		try {
			if (os.equalsIgnoreCase("windows"))
				loadDll();
			else
				loadSo();
		} catch (Exception ex) {
			System.err.println((new StringBuilder())
					.append("load libKCBPCliJNI failed :")
					.append(ex.getMessage()).toString());
		}
	}
}
