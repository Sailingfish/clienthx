// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst splitstr(nl) ansi nonlb space 
// Source File Name:   AuthClientJni.java

package com.szkingdom.unifiedAuth;

import java.io.File;
import java.io.PrintStream;
import java.net.URI;
import java.net.URL;

public class AuthClientJni {

    public AuthClientJni() {
    }

    public native String UserLogin(String s, long l);

    public native String CheckUserTicket(String s, long l);

    private static void loadDll(String paramString) throws SecurityException, UnsatisfiedLinkError {
        String str = System.getProperty("file.separator");
        System.load((new StringBuilder()).append(paramString).append(str).append("TDXSSO.DLL").toString());
        System.load((new StringBuilder()).append(paramString).append(str).append("libeay32.dll").toString());
        System.load((new StringBuilder()).append(paramString).append(str).append("KDEncodeCli.dll").toString());
        System.load((new StringBuilder()).append(paramString).append(str).append("encrypt.dll").toString());
        System.load((new StringBuilder()).append(paramString).append(str).append("kcbpcrypt.dll").toString());
        System.load((new StringBuilder()).append(paramString).append(str).append("kcxpapi.dll").toString());
        System.load((new StringBuilder()).append(paramString).append(str).append("comclient.dll").toString());
        System.load((new StringBuilder()).append(paramString).append(str).append("AuthenticationClient.dll").toString());
        System.load((new StringBuilder()).append(paramString).append(str).append("AuthenticationClientJNI.dll").toString());
    }

    private static void loadSo(String paramString) throws SecurityException, UnsatisfiedLinkError {
        String str = System.getProperty("file.separator");
        System.load((new StringBuilder()).append(paramString).append(str).append("encrypt.so").toString());
        System.load((new StringBuilder()).append(paramString).append(str).append("AuthClientJni.so").toString());
    }

    static  {
        String str1 = "windows";
        try {
            str1 = System.getProperty("os.name");
            if (str1 == null) {
                System.out.println("unkowned system, we will load as non-window system.");
                str1 = "unkowned system";
            }
            str1 = str1.trim();
            if (str1.length() >= 7 && str1.substring(0, 7).equalsIgnoreCase("windows"))
                str1 = "windows";
        }
        catch (Exception localException1) {
            str1 = "windows";
        }
        try {
            if (str1.equalsIgnoreCase("windows"))
                System.loadLibrary("AuthenticationClientJNI");
            else
                System.loadLibrary("AuthenticationClientJNI");
        }
        catch (SecurityException localSecurityException) {
            System.out.println(localSecurityException.getMessage());
            System.out.println("load AuthClientJni  failed!");
        }
        catch (UnsatisfiedLinkError localUnsatisfiedLinkError1) {
            URL localURL = AuthClientJni.class.getClassLoader().getResource("");
            String str2 = (new File(URI.create(localURL.toExternalForm()))).getAbsolutePath();
            try {
                if (str1.equalsIgnoreCase("windows"))
                    loadDll(str2);
                else
                    loadSo(str2);
            }
            catch (Exception localException2) {
                System.out.println(localException2.getMessage());
                System.out.println("load lib AuthClientJni failed!");
            }
            catch (UnsatisfiedLinkError localUnsatisfiedLinkError2) {
                System.out.println(localUnsatisfiedLinkError2.getMessage());
                System.out.println("load lib AuthClientJni failed!");
            }
        }
        catch (Throwable localThrowable) {
            System.out.println((new StringBuilder()).append("on loading AuthClientJni : ").append(localThrowable.getMessage()).toString());
        }
    }
}
