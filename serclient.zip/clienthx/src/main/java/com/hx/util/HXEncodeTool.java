package com.hx.util;

public class HXEncodeTool
{
	
	private HXEncodeTool()
	{
		System.loadLibrary("HXEncodeDLL");
	}
	
	private static HXEncodeTool instance = null;
	
	public static HXEncodeTool getInstance()
	{
		if (instance == null)
		{
			instance = new HXEncodeTool();
		}
		return instance;
	}
	
	public native String encode(String key, String passwd);
	
	public native String decode(String key, String passwd);
	
	public static void main(String[] args) throws Exception
	{
		String str = HXEncodeTool.getInstance().encode("150000051181", "123123");
		System.out.println(str);
	}
	
}
