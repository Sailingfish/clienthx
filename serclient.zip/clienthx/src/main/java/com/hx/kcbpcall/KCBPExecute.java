package com.hx.kcbpcall;

import java.io.IOException;

import org.apache.log4j.Logger;

import com.hx.kcbpcall.Exception.KCBPException;
import com.hx.kcbpcall.config.FuncConfig;
import com.hx.kcbpcall.util.ParamUtils;
import com.hx.kcbpcall.util.UtilException;
import com.hx.kcbpcall.vo.Function;
import com.hx.kcbpcall.vo.Page;
import com.hx.kcbpcall.vo.ParamVO;
import com.hx.kcbpcall.vo.ResultFactory;
import com.hx.kcbpcall.vo.ResultVO;
import com.hx.kcbpcli.KCBPClientPool;
import com.hx.kcbpcli.KCBPClientWrap;
import com.hx.kcbpcli.KCBPContext;
import com.hx.web.mvc.Constants;
import com.hx.web.mvc.RequestContext;

public class KCBPExecute {
	Logger log = Logger.getLogger(KCBPExecute.class);

	FuncConfig funcConfig = null;

	public static KCBPExecute instance = new KCBPExecute();

	FunctionExec exec = new FunctionExec();

	private LBMCallBack callback;

	private KCBPExecute() {
		callback = new DefaultCallBack();
		funcConfig = new FuncConfig();

		try {
			funcConfig.addConfig(KCBPExecute.class
					.getResourceAsStream("/function.xml"));
		} catch (UtilException e) {
			log.error("parse functions.xml error", e);
		}
	}

	public ResultVO execute(RequestContext requestContext) {
		return execute(requestContext, null, callback, true);
	}

	public ResultVO execute(RequestContext requestContext, String _params) {
		ParamVO pvo = new ParamVO();
		pvo.putAll(ParamUtils.toParamVO(_params));
		return execute(requestContext, pvo, callback, true);
	}

	public ResultVO execute(RequestContext requestContext, String _params,
			boolean hasRequest) {
		ParamVO pvo = new ParamVO();
		pvo.putAll(ParamUtils.toParamVO(_params));
		return execute(requestContext, pvo, callback, hasRequest);
	}

	public ResultVO execute(RequestContext requestContext, ParamVO pvo,
			boolean hasRequest) {
		return execute(requestContext, pvo, callback, hasRequest);
	}

	public ResultVO execute(RequestContext requestContext, ParamVO pvo) {
		return execute(requestContext, pvo, callback, true);
	}

	public ResultVO execute(RequestContext requestContext, ParamVO pvo,
			LBMCallBack _callback, boolean hasRequest) {
		if (pvo == null)
			pvo = new ParamVO();

		String funcid = pvo.getString(Constants.ID);
		if (hasRequest)
			pvo.putAll(requestContext.getParameterMap());
		Page pg = ParamUtils.makePage(pvo);
		if (funcid == null || "".equals(funcid)) {
			funcid = pvo.getString(Constants.ID);
		} else {
			pvo.put(Constants.ID, funcid);
		}
		String serverName = null;
		// ���˲���
		if (funcConfig != null) {
			Function f = funcConfig.getFunction(funcid);
			if (f != null && f.getInParam() != null
					&& !"".equals(f.getInParam()))
				pvo = ParamUtils.filterInputPara(f.getInParam(), pvo);
			if (f != null)
				serverName = f.getServerName();
		}

		// ȡ�ù���������Ҫ�Ĺ�����������vo�м��빫����������lbm�ӿھ�����
		pvo
				.putAll(ParamUtils.getMetaData(requestContext.getOperator(),
						funcid));

		// ���з�ҳ����
		ParamUtils.mergePerPage(pvo, pg);

		ResultVO _result = _execute(pvo, callback, serverName);
		_result.setPage(pg);
		if (pg != null)
			pg.setTotalCount(_result.getTotalRow());
		return _result;
	}

	public ResultVO execute(ParamVO pvo) {
		return execute(pvo, callback);
	}

	public ResultVO execute(ParamVO pvo, String serverName) {
		return execute(pvo, callback, serverName);
	}

	public ResultVO execute(ParamVO pvo, LBMCallBack callback) {
		return _execute(pvo, callback, null);
	}

	public ResultVO execute(ParamVO pvo, LBMCallBack callback, String serverName) {
		return _execute(pvo, callback, serverName);
	}

	private ResultVO _execute(ParamVO pvo, LBMCallBack callback,
			String serverName) {
		KCBPClientWrap cl = connectKCBPServer(serverName);

		if (cl == null || cl.client == null) {
			log.error("��KCBP���ӳ��л�ȡ����ʧ��");
			return ResultFactory.getResultVO(ResultFactory.CONN_ERROR);
		}
		long start = System.currentTimeMillis();
		ResultVO result = null;
		try {
			result = callback.call(cl.hand, pvo, cl, serverName);
		} catch (KCBPException e) {
			result = ResultFactory.getResultVO("500");
		}
		cl.disConnect();
		long elapsed = System.currentTimeMillis() - start;
		if (elapsed < 1000) {
			if (log.isDebugEnabled()) {
				log.debug(debug(elapsed, result, pvo));
			}
		} else {
			log.info(debug(elapsed, result, pvo));
		}
		return result;
	}

	private String debug(long time, ResultVO vo, ParamVO pvo) {
		return "spend time:" + time + " param:" + pvo;
	}

	/**
	 * ����KCBP����
	 * 
	 * @param handle
	 * @return KCBP�ͻ��˰�װ��
	 */
	private KCBPClientWrap connectKCBPServer(String serverName) {
		KCBPClientPool pool = null;
		KCBPClientWrap client = null;
		try {
			pool = KCBPClientPool.getClientPool(serverName);
			client = pool.getKCBPClient();
		} catch (Exception e) {
			log.error("��KCBP���ӳػ�ȡ���ӷ����쳣��" + e.getMessage());
			return null;
		}
		return client;
	}

	public FuncConfig getFuncConfig() {
		return funcConfig;
	}

	public ResultVO callLbm(ParamVO inVo, String serverName) {
		Function function = new Function();
		function.setFuncId((String) inVo.get("funcId"));
		function.setServerName(serverName);
		KCBPContext context = new KCBPContext();
		context.setParamVO(inVo);
		context.setFunction(function);
		return exec.execute(context);
	}

	public void reload() {
		funcConfig = new FuncConfig();
		// .getResourceAsStream("/function.xml")
		try {
			funcConfig.addConfig(KCBPExecute.class.getResource("/function.xml")
					.openStream());
		} catch (UtilException e) {
			log.error("parse functions.xml error", e);
		} catch (IOException e) {
			log.error("parse functions.xml error", e);
		}
	}

}
