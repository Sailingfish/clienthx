package com.hx.kcbpcall.vo;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

public class Channel {

	private AtomicLong totalcount = new AtomicLong();

	private AtomicLong errorcount = new AtomicLong();

	private AtomicInteger curCount = new AtomicInteger();

	private List functionList = new ArrayList();
	private String name;
	private int maxCount;

	private int reachMaxCount;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getMaxCount() {
		return maxCount;
	}

	public void setMaxCount(int maxCount) {
		this.maxCount = maxCount;
	}

	public int getCurCount() {
		return curCount.get();
	}

	public int increment() {
		return curCount.incrementAndGet();
	}

	public long incrementErrorCount() {
		return errorcount.incrementAndGet();
	}

	public int decrement() {
		if (reachMaxCount < getCurCount()) {
			reachMaxCount = getCurCount();
		}
		return curCount.decrementAndGet();
	}

	public boolean checkIsMax() {
		totalcount.incrementAndGet();
		if (maxCount == -1) {
			increment();
			return false;
		}
		return increment() > maxCount;
	}

	public int getReachMaxCount() {
		return reachMaxCount;
	}

	public String toString() {
		return "name=" + name + " maxCount=" + maxCount + " curCount="
				+ curCount + " reachMaxCount=" + reachMaxCount + " errorcount"
				+ errorcount + " totalcount" + totalcount;
	}

	public void addFunList(List lst) {
		functionList.addAll(lst);
	}

	public List getFunList() {
		return functionList;
	}

}
