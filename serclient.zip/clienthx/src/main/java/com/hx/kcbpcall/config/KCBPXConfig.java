package com.hx.kcbpcall.config;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.jdom.Element;

import com.hx.kcbpcall.util.Coerce;
import com.hx.kcbpcall.util.UtilException;
import com.hx.kcbpcall.util.XMLUtil;
import com.hx.kcbpcall.vo.Channel;
import com.hx.kcbpcall.vo.Function;
import com.hx.kcbpcall.vo.KCBPServer;

public class KCBPXConfig {
	public static String DEFAULTCHANNEL = "normal";
	public static String DEFAULT = "default";
	private XMLUtil xml;

	private Map kcbpMap = new HashMap();

	private Map chnlMap = new HashMap();

	private List listens = new ArrayList();

	public Map getKcbpMap() {
		return kcbpMap;
	}

	public Map getChnlMap() {
		return chnlMap;
	}

	/**
	 * ����һ�������ļ�
	 * 
	 * @param is
	 */
	public void addConfig(InputStream is) throws UtilException {
		xml = XMLUtil.getInsance(is);
		initKCBPServers();
		initChannels();
		initListens();
	}

	private void initKCBPServers() throws UtilException {
		List kcbpsList = xml.getAllElements("/config/kcbps");
		Element kcbpsElem = null;
		Element kcbpElem = null;
		List kcbpList = null;
		KCBPServer kcbp = null;
		String _tempStr = null;
		for (Iterator it = kcbpsList.iterator(); it.hasNext();) {
			kcbpsElem = (Element) it.next();

			kcbpList = kcbpsElem.getChildren("kcbp");
			if (kcbpList != null && kcbpList.size() > 0)
				for (int i = 0; i < kcbpList.size(); i++) {
					kcbpElem = (Element) kcbpList.get(i);
					kcbp = new KCBPServer();
					kcbp.setName(kcbpElem.getAttributeValue("name"));
					parseProperties(kcbp, kcbpElem, kcbpElem
							.getChildren("property"));
					kcbpMap.put(kcbp.getName(), kcbp);
				}
		}
	}

	private void initChannels() throws UtilException {
		List chnlsList = xml.getAllElements("/config/channels");
		Element chnlElem = null;
		Channel chnl;
		for (Iterator it = chnlsList.iterator(); it.hasNext();) {
			chnlElem = (Element) it.next();
			List chnlList = chnlElem.getChildren("channel");
			if (chnlList != null && chnlList.size() > 0)
				for (int i = 0; i < chnlList.size(); i++) {
					chnlElem = (Element) chnlList.get(i);
					chnl = new Channel();
					chnl.setName(chnlElem.getAttributeValue("name"));
					try {
						chnl.setMaxCount(new Integer(chnlElem
								.getAttributeValue("maxcount")).intValue());
					} catch (Exception e) {
						e.printStackTrace();
						chnl.setMaxCount(-1);
					}
					String funcs = chnlElem.getValue();
					if (funcs != null)
						chnl.addFunList(Arrays.asList(funcs.split(",")));
					chnlMap.put(chnl.getName(), chnl);
				}
		}
	}

	private void initListens() throws UtilException {
		List chnlsList = xml.getAllElements("/config/listens");
		Element chnlElem = null;
		Channel chnl;
		for (Iterator it = chnlsList.iterator(); it.hasNext();) {
			chnlElem = (Element) it.next();
			List chnlList = chnlElem.getChildren("listen");
			if (chnlList != null && chnlList.size() > 0)
				for (int i = 0; i < chnlList.size(); i++) {
					chnlElem = (Element) chnlList.get(i);
					listens.add(chnlElem.getAttributeValue("className"));

				}
		}
	}

	private void parseProperties(KCBPServer kcbp, Element parentElem, List elems) {
		if (elems == null || elems.size() < 1)
			return;
		Element prop;
		String _name = null;
		String _val = null;
		Map _vmap = new HashMap();
		for (int i = 0; i < elems.size(); i++) {
			prop = (Element) elems.get(i);
			_name = (String) prop.getAttributeValue("name");
			_val = prop.getValue();
			_vmap.put(_name, _val);
		}
		beanSetValue(kcbp, _vmap);
	}

	private void beanSetValue(KCBPServer kcbp, Map _values) {
		String propName = null, value = null;
		BeanInfo beanInfo;
		PropertyDescriptor[] pds = null;
		try {
			beanInfo = Introspector.getBeanInfo(kcbp.getClass(), Object.class);

			pds = beanInfo.getPropertyDescriptors();
		} catch (IntrospectionException e) {
			e.printStackTrace();
			return;
		}
		for (int i = 0, len = pds.length; i < len; ++i) {
			PropertyDescriptor pd = pds[i];
			propName = pd.getName();
			Method setter = pd.getWriteMethod();
			value = (String) _values.get(propName);
			if (setter != null && value != null) {
				Class propType = pd.getPropertyType();
				Object coercedPropVal;
				coercedPropVal = Coerce.toObject((String) value, propType);
				try {
					setter.invoke(kcbp, new Object[] { coercedPropVal });
				} catch (IllegalArgumentException e) {
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					e.printStackTrace();
				} catch (InvocationTargetException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public KCBPServer getKCBPServer(String server) {
		return (KCBPServer) kcbpMap.get(server);
	}

	public Channel getChannel(String chnl) {
		return (Channel) chnlMap.get(chnl);
	}

	public Channel getChannel(Function func) {
		Channel channel = null, defchannel = null;
		String chnl = func.getChannel();
		if (chnl != null)
			return (Channel) chnlMap.get(chnl);
		synchronized (this) {
			chnl = func.getChannel();
			if (chnl != null)
				return (Channel) chnlMap.get(chnl);

			Iterator ite = chnlMap.entrySet().iterator();
			Map.Entry entry = null;
			while (ite.hasNext()) {
				entry = (Map.Entry) ite.next();
				channel = (Channel) entry.getValue();
				if (channel.getFunList().contains(func.getFuncId())) {
					func.setChannel(channel.getName());
					return channel;
				} else if (DEFAULTCHANNEL.equals(channel.getName())) {
					defchannel = channel;
				}
			}
		}

		return defchannel;
	}

	public List getListens() {
		return listens;
	}

	public static void main(String[] args) {
		KCBPXConfig config = new KCBPXConfig();
		InputStream in = null;
		try {
			in = new java.io.FileInputStream(
					"M:\\xwork\\hxcrm\\src\\resources\\kcbp-config.xml");

			// Thread.currentThread().getClass().getResourceAsStream(
			// "/kcbp-config.xml");
			config.addConfig(in);
			in.close();
			System.out.print(config.getKcbpMap());
			System.out.print(config.getChnlMap());
			System.out.print(config.getListens());
		} catch (Exception e) {
			if (in != null)
				try {
					in.close();
				} catch (IOException e1) {
				}
		}
	}
}
