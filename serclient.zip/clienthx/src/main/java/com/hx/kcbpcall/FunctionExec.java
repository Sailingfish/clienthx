package com.hx.kcbpcall;

import java.util.Map;

import org.apache.log4j.Logger;

import com.hx.kcbpcall.Exception.KCBPException;
import com.hx.kcbpcall.vo.Function;
import com.hx.kcbpcall.vo.ParamVO;
import com.hx.kcbpcall.vo.ResultFactory;
import com.hx.kcbpcall.vo.ResultVO;
import com.hx.kcbpcli.KCBPClientManager;
import com.hx.kcbpcli.KCBPClientWrap;
import com.hx.kcbpcli.KCBPContext;
import com.hx.kcbpcli.client.Connection;
import com.hx.kcbpcli.client.KCBPEvent;

public class FunctionExec {
	private static Logger log = Logger.getLogger(FunctionExec.class);
	private KCBPClientManager clientManager = new KCBPClientManager();

	private String debug(long time, ResultVO vo, ParamVO pvo) {
		return "spend time:" + time + " param:" + pvo;
	}

	public ResultVO execute1(KCBPContext kcbpContext) {
		kcbpContext.setClientManager(clientManager);
		Function function = kcbpContext.getFunction();
		LBMCallBack callback = kcbpContext.getCallback();
		ParamVO pvo = kcbpContext.getParamVO();
		String serverName = function.getServerName();

		// ��ȡ����
		KCBPClientWrap cl = clientManager.connectKCBPServer(kcbpContext);

		if (cl == null || cl.client == null) {
			log.error("��KCBP���ӳ��л�ȡ����ʧ��");
			return ResultFactory.getResultVO(ResultFactory.CONN_ERROR);
		}
		long start = System.currentTimeMillis();
		ResultVO result;
		try {
			result = callback.call(cl.hand, pvo, cl, serverName);
			cl.disConnect();
			long elapsed = System.currentTimeMillis() - start;
			if (elapsed < 1000) {
				if (log.isDebugEnabled()) {
					log.debug(debug(elapsed, result, pvo));
				}
			} else {
				log.info(debug(elapsed, result, pvo));
			}
		} catch (KCBPException e) {
			log.error("call execute error", e);
			return ResultFactory.getResultVO(e.getRscode());
		}
		return result;
	}

	public ResultVO execute(Map map) {
		ParamVO inVo = new ParamVO();
		inVo.putAll(map);
		return execute(inVo);
	}
	
	public ResultVO execute(ParamVO inVo, String funcID) {
		inVo.put("funcId", funcID);
		return execute(inVo);
	}
	
	public ResultVO execute(ParamVO inVo) {
		KCBPContext context = new KCBPContext();
		context.setParamVO(inVo);
		Function function = new Function();
		function.setFuncId((String)inVo.get("funcId"));
		if (function.getFuncId()==null){
			return ResultFactory.getResultVO(ResultFactory.CALL_ERROR, "û�����빦�ܺ�");
		}
		context.setFunction(function);
		return execute(context);
	}

	

	public ResultVO execute(KCBPContext kcbpContext) {
		kcbpContext.setClientManager(clientManager);
		try {
			kcbpContext.fire(KCBPEvent.BEFORECALL);
			// ��ȡ����
			clientManager.fire(kcbpContext, KCBPEvent.BEFORECONNECT);
			Connection cl = clientManager.getConnection(kcbpContext);
			kcbpContext.setConnection(cl);
			clientManager.fire(kcbpContext, KCBPEvent.AFTERCONNECT);
			// ִ��
			return cl.execute(kcbpContext);
		} catch (KCBPException e) {
			log.error("call execute error", e);
			return ResultFactory.getResultVO(e.getRscode(), e.getMessage());
		} catch (Exception e) {
			log.error("call execute error", e);
			return ResultFactory.getResultVO(ResultFactory.CALL_ERROR, e
					.getMessage());
		} finally {
			try {
				kcbpContext.fire(KCBPEvent.AFTERCCALL);
			} catch (KCBPException e) {
				log.error("call execute error", e);
				return ResultFactory.getResultVO(e.getRscode(), e.getMessage());
			}
		}
	}

	public KCBPClientManager getClientManager() {
		return clientManager;
	}

}
