package com.hx.kcbpcall.util;

public class UtilException extends Exception {

	private static final long serialVersionUID = 6112831112965286175L;

	public UtilException(String mgs) {
		super(mgs);
	}
}
