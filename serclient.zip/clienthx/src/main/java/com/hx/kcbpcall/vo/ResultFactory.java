package com.hx.kcbpcall.vo;

import com.hx.kcbpcall.Exception.KCBPException;

public class ResultFactory {
	public static String CALL_ERROR = "-1";

	public static String CONN_ERROR = "500";

	public static String FORBIT = "400";

	public static String MAXCALL = "401";

	private static ResultVO callError = new ResultVO("һ���Ե��ô���,���Ժ����ԣ�",
			CALL_ERROR);

	private static ResultVO connError = new ResultVO("��KCBP���ӳ��л�ȡ����ʧ�ܣ�",
			CONN_ERROR);

	private static ResultVO forbitError = new ResultVO("�����ܽ�ֹ���ã�", FORBIT);

	private static ResultVO maxCallError = new ResultVO("�����ܵ��ó�����������������Ժ���ã�",
			MAXCALL);

	public static ResultVO getResultVO(String type) {
		if (CALL_ERROR.equals(type)) {
			return callError;
		} else if (CONN_ERROR.equals(type)) {
			return connError;
		} else if (MAXCALL.equals(type)) {
			return maxCallError;
		} else if (FORBIT.equals(type)) {
			return forbitError;
		}
		return null;
	}

	public static ResultVO getResultVO(int errorCode) {
		if (errorCode == KCBPException.CALL_ERROR) {
			return callError;
		} else if (errorCode == KCBPException.CONN_ERROR) {
			return connError;
		} else if (errorCode == KCBPException.IS_FORBIT) {
			return forbitError;
		} else if (errorCode == KCBPException.IS_MAX_CALL) {
			return maxCallError;
		}
		return null;
	}

	public static ResultVO getResultVO(int errorCode, String msg) {
		return getResultVO(msg, errorCode + "");
	}

	public static ResultVO getResultVO(String msg, String code) {
		ResultVO vo = new ResultVO(msg);
		vo.setRscode(code);
		vo.setRslevel(code);
		return vo;
	}

	public static ResultVO getResultVO(String msg, String code, String level) {
		ResultVO vo = new ResultVO(msg);
		vo.setRscode(code);
		vo.setRslevel(level);
		return vo;
	}
}
