package com.hx.kcbpcall.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jdom.Attribute;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;
import org.jdom.output.XMLOutputter;
import org.jdom.xpath.XPath;

public class XMLUtil {

	private Document doc;

	private Map lookupCache;

	XMLUtil(Document doc) {
		this.doc = null;
		lookupCache = new HashMap();
		this.doc = doc;
	}

	private XMLUtil(InputStream is, boolean validate) throws UtilException {
		doc = null;
		lookupCache = new HashMap();
		SAXBuilder builder = null;
		if (validate) {
			builder = new SAXBuilder("org.apache.xerces.parsers.SAXParser",
					true);
			builder.setFeature(
					"http://apache.org/xml/features/validation/schema", true);
			builder
					.setProperty(
							"http://apache.org/xml/properties/schema/external-schemaLocation",
							"http://www.w3.org/2001/XMLSchema-instance");
		} else {
			builder = new SAXBuilder();
		}

		Charset charset = null;
		if (Charset.isSupported("GBK")) {
			charset = Charset.forName("GBK");
		}
		java.io.Reader r;
		if (charset == null) {
			r = new InputStreamReader(is);
		} else {
			r = new InputStreamReader(is, charset);
		}
		try {
			doc = builder.build(r);
		} catch (JDOMException e0) {
			e0.printStackTrace();
			throw new UtilException(e0.getMessage() + "--JDOMException");
		} catch (IOException e1) {

			e1.printStackTrace();
			throw new UtilException(e1.getMessage() + "--IOException");
		}

	}

	public static XMLUtil getInsance(String filePath) throws UtilException {
		return getInsance(filePath, false);
	}

	public static XMLUtil getInsance(String filePath, boolean validate)
			throws UtilException {
		try {
			return getInsance(((InputStream) (new FileInputStream(filePath))),
					validate);
		} catch (FileNotFoundException e) {
			throw new UtilException(e.getMessage());
		}
	}

	public static XMLUtil getInsance(InputStream is) throws UtilException {
		return getInsance(is, false);
	}

	public static XMLUtil getInsance(InputStream is, boolean validate)
			throws UtilException {
		return new XMLUtil(is, validate);
	}

	public void writeToStream(OutputStream stream) throws UtilException {
		writeToStream(stream, "gb2312");
	}

	public void writeToStream(OutputStream stream, String encoding)
			throws UtilException {
		try {
			XMLOutputter out = new XMLOutputter();
			out.output(doc, stream);
		} catch (Exception e) {
			throw new UtilException(e.getMessage());
		}
	}

	public List getAllElements(String xpath) throws UtilException {
		List elements = null;
		try {
			elements = XPath.selectNodes(doc, xpath);
		} catch (JDOMException e) {
			throw new UtilException(e.getMessage());
		}
		return elements;
	}

	public Element getSingleElement(String xpath) throws UtilException {
		if (lookupCache.containsKey(xpath))
			return (Element) lookupCache.get(xpath);
		Element element = null;
		try {
			element = (Element) XPath.selectSingleNode(doc, xpath);
		} catch (JDOMException e) {
			throw new UtilException(e.getMessage());
		}
		lookupCache.put(xpath, element);
		return element;
	}

	public String getSingleElementText(String xpath) throws UtilException {
		Element element = getSingleElement(xpath);
		if (element == null)
			return null;
		else
			return element.getTextTrim();
	}

	public Attribute getElementAttribute(String xpath, String attrName)
			throws UtilException {
		return getSingleElement(xpath).getAttribute(attrName);
	}

	public String getElementAttributeValue(String xpath, String attrName)
			throws UtilException {
		return getSingleElement(xpath).getAttributeValue(attrName);
	}

/*	public void addElement(String xpath, String elemName, String elemText)
			throws UtilException {
		Element parent = getSingleElement(xpath);
		parent.addContent((new Element(elemName)).addContent(elemText));
	}*/

	public Element removeElement(String xpath) throws UtilException {
		lookupCache.remove(xpath);
		Element element = getSingleElement(xpath);
		if (element.isRootElement())
			return element;
		else
			return (Element) element.detach();
	}

	public void setAttribute(String xpath, String attrName, String attrValue)
			throws UtilException {
		Element element = getSingleElement(xpath);
		try {
			element.setAttribute(attrName, attrValue);
		} catch (Exception e) {
			throw new UtilException(e.getMessage());
		}
	}

	public boolean removeAttribute(String xpath, String attrName)
			throws UtilException {
		Element element = getSingleElement(xpath);
		if (element == null)
			return false;
		else
			return element.removeAttribute(attrName);
	}

}
