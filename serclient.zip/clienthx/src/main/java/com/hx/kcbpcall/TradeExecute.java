package com.hx.kcbpcall;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import rewin.transaction.HXTradeSender;
import rewin.transaction.TradeSession;

import com.hx.kcbpcall.Exception.ParseException;
import com.hx.kcbpcall.vo.ResultVO;
import com.hx.kcbpcall.vo.Operator;
import com.hx.socket.HxCommandFactory;
import com.hx.socket.IHxCommand;
import com.hx.socket.SocketManager;
import com.hx.socket.processor.IProcessor;
import com.hx.socket.util.HxFixParser;
import com.hx.web.mvc.RequestContext;

public class TradeExecute {
	public static HXTradeSender netTrade = new HXTradeSender();
	public static TradeExecute instance = new TradeExecute();
	public static char COMDIV = 0x01;

	public ResultVO executeExt(TradeSession tradeSession, int funcid, String req) {
		return execute(toOperator(null, tradeSession), funcid, req);
	}

	public ResultVO executeExt(Operator oper, int funcid, String req) {
		return execute(funcid, wrapSubmitEx(oper, req));
	}

	public ResultVO executeExt(int funcid, Map req) {
		ResultVO vo = null;
		try {
			IHxCommand command = HxCommandFactory.buildCommand(0x2010, req);
			List list = (List) SocketManager.getInstance().execute(command,
					new IProcessor() {
						public Object process(IHxCommand command) {
							List list = new ArrayList();
							HxFixParser fix = new HxFixParser(command
									.getFixBytes());
							int iRows = fix.getRecordCount();
							int iCols = fix.getFieldCount();
							String[] fields = new String[iCols];
							for (int n = 0; n < iCols; n++)
								fields[n] = fix.getFieldName(n);
							int index = 0;
							try {
								for (int i = 0; i < iRows; i++) {
									index = 0;
									for (int j = 0; j < iCols; j++) {
										System.out.println("field=" + fields[j]
												+ " value="
												+ fix.getValue(i, j));
									}
								}
							} catch (Exception e0) {
								e0.printStackTrace();
							}
							return list;
						}

					});

			vo = parseList(list);
		} catch (Exception e) {
			vo = new ResultVO();
			vo.setRscode("-1");
			vo.setMessage(e.getMessage());
		}
		return vo;
	}

	public ResultVO execute(RequestContext requestContext, int funcid,
			String req) {
		Operator oper = requestContext.getOperator();
		return execute(oper, funcid, req);
	}

	public ResultVO execute(TradeSession tradeSession, int funcid, String req) {
		return execute(toOperator(null, tradeSession), funcid, req);
	}

	public ResultVO execute(Operator oper, int funcid, String req) {
		return execute(funcid, wrapSubmitEx(oper, req));
	}

	public ResultVO execute(int funcid, String req) {
		ResultVO vo = null;
		try {
			vo = parse(submitEx(funcid, req));
		} catch (ParseException e) {
			vo.setRscode("-1");
			vo.setMessage(e.getMessage());
		}
		return vo;
	}

	public String submitEx(int funcid, String req) {
		return netTrade.submitEx(funcid, req);
	}

	public ResultVO parseList(List data) {
		ResultVO vo = new ResultVO();

		vo.setRscode("0");
		vo.setResults(data);
		vo.setTotalRow(data.size());
		return vo;
	}

	public ResultVO parse(String buf) throws ParseException {
		if (buf == null || "".equals(buf))
			return null;
		int fieldCount = 0;
		int recordCount = 0;

		String field[] = buf.split("\\001", -2);
		String sFieldCount = null;
		try {
			sFieldCount = new String(field[0]);
		} catch (Exception e) {
			throw new ParseException("FIX���ķǷ�");
		}
		for (int at = 0; at < sFieldCount.length(); at++)
			if (sFieldCount.charAt(at) < '0' || sFieldCount.charAt(at) > '9')
				throw new ParseException("FIX���������Ƿ�");

		fieldCount = Integer.parseInt(sFieldCount);
		String sRecordCount = null;
		try {
			sRecordCount = field[1];
		} catch (Exception e) {
			throw new ParseException("FIX���ķǷ�");
		}
		for (int at = 0; at < sRecordCount.length(); at++)
			if (sRecordCount.charAt(at) < '0' || sRecordCount.charAt(at) > '9')
				throw new ParseException("FIX���������Ƿ�");

		List results = new ArrayList();
		List fields = new ArrayList();

		recordCount = Integer.parseInt(sRecordCount);
		int idx = 0;
		for (int j = 2; j < fieldCount + 2; j++) {
			String sFieldName = null;
			try {
				sFieldName = field[j];
			} catch (Exception e) {
				throw new ParseException("FIX���������Ƿ�");
			}
			fields.add(idx, sFieldName);
			idx++;
		}
		ResultVO vo = new ResultVO();
		vo.setRscode("0");
		int valCount = fieldCount + 2;
		for (int k = 0; k < recordCount; k++) {
			Map vc = new HashMap();
			for (int i = 0; i < fieldCount; i++) {
				String sFieldValue = null;
				vc.put(fields.get(i), field[valCount]);
				if (k == 0) {
					if ("err_code".equals(fields.get(i))) {
						vo.setRscode(field[valCount]);
					} else if ("err_msg".equals(fields.get(i))) {
						vo.setMessage(field[valCount]);
					}
				}
				valCount++;
			}
			results.add(vc);
		}
		vo.setResults(results);
		vo.setTotalRow(recordCount);
		return vo;
	}

	/*
	 * public String wrapSubmitEx(TradeSession tradeSession, String v0) {
	 * StringBuffer buf = new StringBuffer();
	 * buf.append(tradeSession.userCacheValue.branchID).append(COMDIV).append(
	 * tradeSession.userCacheValue.account).append(COMDIV).append(
	 * tradeSession.userCacheValue.passwd).append(COMDIV).append(
	 * tradeSession.userCacheValue.userIP).append(COMDIV).append(
	 * tradeSession.userCacheValue.customerId).append(COMDIV).append( v0); //
	 * '\001' return buf.toString(); }
	 */
	public String wrapSubmitEx(Operator operator, String v0) {
		StringBuffer buf = new StringBuffer();
		buf.append(operator.getYybbh()).append(COMDIV).append(
				operator.getZjhm()).append(COMDIV).append(operator.getGymm())
				.append(COMDIV).append(
						operator.getCzzd() == null ? "127.0.0.1" : operator
								.getCzzd()).append(COMDIV).append(
						operator.getZjhm()).append(COMDIV).append(v0); // '\001'
		return buf.toString();
	}
	
	public Map wrapSubmitEx2(Operator operator, String v0) {
		Map map=new HashMap();
		//map
		
		return null;
	}
	

	public Operator toOperator(Operator operator, TradeSession ts) {
		if (ts == null)
			return operator;
		if (operator == null)
			operator = new Operator();
		operator.setYybbh(ts.userCacheValue.branchID);
		operator.setZjhm(ts.userCacheValue.account);
		operator.setGymm(ts.userCacheValue.passwd);
		operator.setCzzd(ts.userCacheValue.userIP);
		return operator;
	}
}
