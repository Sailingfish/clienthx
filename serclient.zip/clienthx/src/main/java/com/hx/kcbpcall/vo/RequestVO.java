package com.hx.kcbpcall.vo;

public class RequestVO {
	
	private ParamVO paramVO;
	
	private ResultVO resultVO;
	
	public RequestVO(ParamVO paramVO){
		this.paramVO=paramVO;
	}
	
	public ParamVO getParamVO() {
		return paramVO;
	}
	public void setParamVO(ParamVO paramVO) {
		this.paramVO = paramVO;
	}
	public ResultVO getResultVO() {
		return resultVO;
	}
	public void setResultVO(ResultVO resultVO) {
		this.resultVO = resultVO;
	}
}
