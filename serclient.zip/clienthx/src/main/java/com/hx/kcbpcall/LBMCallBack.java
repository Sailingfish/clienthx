package com.hx.kcbpcall;

import java.util.List;

import com.hx.kcbpcall.Exception.KCBPException;
import com.hx.kcbpcall.vo.ParamVO;
import com.hx.kcbpcall.vo.ResultVO;
import com.hx.kcbpcli.KCBPClientWrap;
import com.hx.kcbpcli.KCBPContext;
import com.hx.kcbpcli.client.KCBPEvent;
import com.szkingdom.kcbpcli.KCBPClient;

public interface LBMCallBack {
	ResultVO call(KCBPContext kcbpContext) throws KCBPException;

	ResultVO call(int hand, ParamVO pvo, KCBPClientWrap client,
			String serverName) throws KCBPException;

	int executeLBM(int hand, ParamVO pvo, KCBPClientWrap client);

	List doResult(int hand, KCBPClient cl);

	ResultVO processResult(ParamVO pvo, List arrayList);
}
