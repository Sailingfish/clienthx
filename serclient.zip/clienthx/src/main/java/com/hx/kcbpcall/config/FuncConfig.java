package com.hx.kcbpcall.config;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.jdom.Element;

import com.hx.kcbpcall.util.UtilException;
import com.hx.kcbpcall.util.XMLUtil;
import com.hx.kcbpcall.vo.Function;

public class FuncConfig {
	private XMLUtil xml;

	private Map functionMap = new HashMap();

	public Map getFunctionMap() {
		return functionMap;
	}

	/**
	 * ����һ�������ļ�
	 * 
	 * @param is
	 */
	public void addConfig(InputStream is) throws UtilException {
		xml = XMLUtil.getInsance(is);
		initFunctions();
	}

	private void initFunctions() throws UtilException {
		List funsList = xml.getAllElements("/config/functions");
		Element funsElem = null;
		Element funElem = null;
		List funList = null;
		Function func = null;
		for (Iterator it = funsList.iterator(); it.hasNext();) {
			funsElem = (Element) it.next();

			funList = funsElem.getChildren("function");
			if (funList != null && funList.size() > 0)
				for (int i = 0; i < funList.size(); i++) {
					funElem = (Element) funList.get(i);
					func = new Function();
					func.setFuncId(funElem.getAttributeValue("funcId"));
					String perm = funElem.getAttributeValue("hasPerm");

					String _server = funElem.getAttributeValue("serverName");
					String _dbname = funElem.getAttributeValue("dbname");
					
					if ("false".equals(perm) || "0".equals(perm)) {
						func.setHasPerm(false);
					}

					String meta = funElem.getAttributeValue("meta");
					if ("false".equals(meta) || "0".equals(meta)) {
						func.setMeta(false);
					}

					if (_server != null && !"".equals(_server)) {
						func.setServerName(_server);
					}
					
					if (_dbname != null && !"".equals(_dbname)) {
						func.setDbname(_dbname);
					}
					
					func.setInParam(funElem.getChildText("inParam"));
					functionMap.put(func.getFuncId(), func);
				}
		}
	}

	public Function getFunction(String func) {
		return (Function) functionMap.get(func);
	}

}
