package com.hx.kcbpcall.vo;

import com.szkingdom.kcbpcli.tagKCBPConnectOption;

public class KCBPServer {
	// Ψһ��ʾ
	private String name;
	// ͨ����������
	private String serverName; // �û��Զ���� KCBP ����������
	private String user; //
	private String password; //
	/* Protocal Э�����ͣ�0 ��ʾʹ�� TCP */
	private String qMgrName;
	private String sendQName;// ���Ͷ������ƣ��ɷ����ָ��
	private String receiveQName;// ���ն������ƣ��ɷ����ָ��
	private String szAddress;// ����� IP
	private int nPort = 21000;// ����˶˿ں�

	// ���ӳ��������
	private String testFunction;
	private int checkoutTimeout;
	private int idleConnectionTestPeriod;
	private int initialPoolSize;
	private int maxIdleTime;
	private int maxPoolSize;
	private int minPoolSize;

	private tagKCBPConnectOption option;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getServerName() {
		return serverName;
	}

	public void setServerName(String serverName) {
		this.serverName = serverName;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getQMgrName() {
		return qMgrName;
	}

	public void setQMgrName(String mgrName) {
		qMgrName = mgrName;
	}

	public String getSendQName() {
		return sendQName;
	}

	public void setSendQName(String sendQName) {
		this.sendQName = sendQName;
	}

	public String getReceiveQName() {
		return receiveQName;
	}

	public void setReceiveQName(String receiveQName) {
		this.receiveQName = receiveQName;
	}

	public String getSzAddress() {
		return szAddress;
	}

	public void setSzAddress(String szAddress) {
		this.szAddress = szAddress;
	}

	public int getNPort() {
		return nPort;
	}

	public void setNPort(int port) {
		nPort = port;
	}

	public String getTestFunction() {
		return testFunction;
	}

	public void setTestFunction(String testFunction) {
		this.testFunction = testFunction;
	}

	public int getCheckoutTimeout() {
		return checkoutTimeout;
	}

	public void setCheckoutTimeout(int checkoutTimeout) {
		this.checkoutTimeout = checkoutTimeout;
	}

	public int getIdleConnectionTestPeriod() {
		return idleConnectionTestPeriod;
	}

	public void setIdleConnectionTestPeriod(int idleConnectionTestPeriod) {
		this.idleConnectionTestPeriod = idleConnectionTestPeriod;
	}

	public int getInitialPoolSize() {
		return initialPoolSize;
	}

	public void setInitialPoolSize(int initialPoolSize) {
		this.initialPoolSize = initialPoolSize;
	}

	public int getMaxIdleTime() {
		return maxIdleTime;
	}

	public void setMaxIdleTime(int maxIdleTime) {
		this.maxIdleTime = maxIdleTime;
	}

	public int getMaxPoolSize() {
		return maxPoolSize;
	}

	public void setMaxPoolSize(int maxPoolSize) {
		this.maxPoolSize = maxPoolSize;
	}

	public int getMinPoolSize() {
		return minPoolSize;
	}

	public void setMinPoolSize(int minPoolSize) {
		this.minPoolSize = minPoolSize;
	}

	public void setOption(tagKCBPConnectOption option) {
		this.option = option;
	}

	public tagKCBPConnectOption getOption() {
		if (option == null && szAddress != null && sendQName != null
				&& receiveQName != null) {
			option = new tagKCBPConnectOption();
			option.szAddress = szAddress;
			option.szServerName = serverName;
			option.szSendQName = sendQName;
			option.szReceiveQName = receiveQName;
			option.nPort = nPort;
		}
		return option;
	}

	public String toString() {
		StringBuilder buf = new StringBuilder();

		buf.append("name=").append(this.name).append(" serverName=").append(
				this.serverName);
		buf.append(" initialPoolSize=").append(this.initialPoolSize);
		buf.append(" maxIdleTime=").append(this.maxIdleTime);
		buf.append(" maxPoolSize=").append(this.maxPoolSize);
		buf.append(" minPoolSize=").append(this.minPoolSize);
		return buf.toString();
	}
}
