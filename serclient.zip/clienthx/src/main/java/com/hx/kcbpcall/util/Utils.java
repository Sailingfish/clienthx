package com.hx.kcbpcall.util;

import java.util.Collection;
import java.util.Map;
import java.util.StringTokenizer;

import com.hx.kcbpcall.vo.Page;
import com.hx.kcbpcall.vo.ParamVO;

public class Utils {
	//public static String ID = "funcId";
	public static String PAGEOFFSET = "PageOffset";

	public static String PAGECOUNT = "PageCount";

	public static String PERPAGE = "isPerPage";
	

/*	public static String PAGENO = "page.pageNo";
	public static String PAGESIZE = "page.pageSize";

	public static String PAGEOFFSET1 = "pager.offset";
	public static String PAGESIZE1 = "pager.length";*/

	public static ParamVO filterInputPara(java.lang.String inputPara, ParamVO vo) {
		ParamVO newVo = new ParamVO();
		java.util.StringTokenizer st = new StringTokenizer(inputPara, ",");
		java.lang.String aparam[] = (java.lang.String[]) null;
		java.lang.String paraPairs = null;
		java.lang.String paramKey = null;
		java.lang.String paramValue = null;
		boolean isHavaDef = false;
		for (int i = 0; st.hasMoreTokens(); i++) {
			isHavaDef = false;
			paraPairs = (java.lang.String) st.nextElement();
			aparam = paraPairs.split(":");
			if (aparam.length > 1) {
				paramKey = aparam[0];
				isHavaDef = true;
			} else {
				paramKey = paraPairs;
			}
			if (vo.containsKey(paramKey)) {
				paramValue = vo.getString(paramKey);
				if (isHavaDef) {
					if (paramValue != null && !paramValue.equals(""))
						newVo.put(paramKey, paramValue);
					else
						newVo.put(paramKey, aparam[1]);
				} else {
					newVo.put(paramKey, paramValue);
				}
				continue;
			}
			if (aparam.length > 1)
				newVo.put(paramKey, aparam[1]);
		}

		return newVo;
	}

	public static ParamVO toParamVO(String params) {
		return toParamVO(params, "&");
	}

	public static ParamVO toParamVO(String params, String split) {
		ParamVO vo = new ParamVO();
		if (split != null && params.indexOf(split) < 0) {
			vo.put(ParamVO.FUNCID, params);
			return vo;
		}
		java.util.StringTokenizer st = new StringTokenizer(params, split);
		for (int i = 0; st.hasMoreTokens(); i++) {
			java.lang.String temp = (java.lang.String) st.nextElement();
			int symbol = temp.indexOf("=");
			java.lang.String name = temp.substring(0, symbol);
			java.lang.String value = temp.substring(symbol + 1);
			vo.put(name, value);
		}
		return vo;
	}

	public static ParamVO toParamVO(String params, String split, String keySplit) {
		ParamVO vo = new ParamVO();
		java.util.StringTokenizer st = new StringTokenizer(params, split);
		for (int i = 0; st.hasMoreTokens(); i++) {
			java.lang.String temp = (java.lang.String) st.nextElement();
			int symbol = temp.indexOf(keySplit);
			java.lang.String name = temp.substring(0, symbol);
			java.lang.String value = temp.substring(symbol + 1);
			vo.put(name, value);
		}
		return vo;
	}

	public static void mergePerPage(ParamVO vo, Page page) {
		if (vo == null || page == null) {
			if (vo != null)
				vo.put("isPerPage", "false");
			return;
		}
		vo.put("isPerPage", "true");
		vo.put(PAGEOFFSET, Integer.toString(page.getPageSize()
				* (page.getPageNo() - 1)));
		vo.put(PAGECOUNT, Integer.toString(page.getPageSize()));
	}

/*	public static Page makePage(ParamVO vo) {
		String perPageParam = vo.getString(PERPAGE);
		if (perPageParam != null && perPageParam.equals("false")) {
			vo.put(PERPAGE, "false");
			return null;
		} else {// pager.offset=75&pager.length=15
			String pageno = vo.getString(PAGENO);
			String offset = vo.getString(PAGEOFFSET1);

			String rowcount = vo.getString(PAGESIZE);
			if (isEmpty(rowcount)) {
				rowcount = vo.getString(PAGESIZE1);
			}
			Page page = new Page(20, false);
			vo.put("isPerPage", "true");

			if (pageno != null && !"".equals(pageno) && !"0".equals(pageno))
				page.setPageNo(new Integer(pageno).intValue());

			if (rowcount != null && !"".equals(rowcount))
				page.setPageSize(new Integer(rowcount).intValue());

			if (!isEmpty(offset)) {
				page.setPageNo((new Integer(offset).intValue() / page
						.getPageSize()) + 1);
			}
			return page;
		}
	}*/

	private static boolean isEmpty(Object pObj) {
		if (pObj == null)
			return true;
		if (pObj == "")
			return true;
		if (pObj instanceof String) {
			if (((String) pObj).length() == 0) {
				return true;
			}
		} else if (pObj instanceof Collection) {
			if (((Collection) pObj).size() == 0) {
				return true;
			}
		} else if (pObj instanceof Map) {
			if (((Map) pObj).size() == 0) {
				return true;
			}
		}
		return false;
	}
}
