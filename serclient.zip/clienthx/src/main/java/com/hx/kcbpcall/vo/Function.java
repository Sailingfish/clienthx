package com.hx.kcbpcall.vo;

public class Function {

	private String funcId;
	private boolean hasPerm = true;

	private String inParam;

	private boolean meta = true;

	private String serverName;

	private String channel;
	
	private String dbname;

	// �������� ��������
	// private boolean cache;

	public String getFuncId() {
		return funcId;
	}

	public void setFuncId(String funcId) {
		this.funcId = funcId;
	}

	public boolean isHasPerm() {
		return hasPerm;
	}

	public void setHasPerm(boolean hasPerm) {
		this.hasPerm = hasPerm;
	}

	public String getInParam() {
		return inParam;
	}

	public void setInParam(String inParam) {
		this.inParam = inParam;
	}

	public boolean isMeta() {
		return meta;
	}

	public void setMeta(boolean meta) {
		this.meta = meta;
	}

	public String getServerName() {
		return serverName;
	}

	public void setServerName(String serverName) {
		this.serverName = serverName;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}
	
	public String getDbname() {
		return dbname;
	}

	public void setDbname(String dbname) {
		this.dbname = dbname;
	}

	public String toString() {
		StringBuilder buf = new StringBuilder();
		buf.append(" serverName=").append(this.getServerName());
		buf.append(" funcId=").append(this.funcId);
		buf.append(" inParam=").append(this.inParam);
		buf.append(" channel=").append(this.getChannel());
		return buf.toString();
	}
}
