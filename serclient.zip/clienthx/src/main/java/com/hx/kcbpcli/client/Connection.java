package com.hx.kcbpcli.client;

import com.hx.kcbpcall.Exception.KCBPException;
import com.hx.kcbpcall.vo.ResultVO;
import com.hx.kcbpcli.KCBPClientWrap;
import com.hx.kcbpcli.KCBPContext;
import com.szkingdom.kcbpcli.KCBPClient;

public interface Connection {
	KCBPClient getClient();
	
	KCBPClientWrap getClientWrap();
	 
	void free(boolean free);

	void close();

	boolean isFree();

	void disabled();
 
	boolean isDisabled();

	int getHandle();

	boolean isConn();

	int getRetcode();

	boolean testConn();

	ResultVO execute(KCBPContext kcbpContext) throws KCBPException;

	void incrementUseCount();

	long getStartTime();

	long setLastActiveTimeMillis(long lastActiveTimeMillis);

	long getLastActiveTimeMillis();
}
