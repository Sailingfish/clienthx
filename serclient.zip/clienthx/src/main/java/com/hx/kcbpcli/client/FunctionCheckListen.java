package com.hx.kcbpcli.client;

import org.apache.log4j.Logger;

import com.hx.kcbpcall.Exception.KCBPException;
import com.hx.kcbpcall.config.KCBPXConfig;
import com.hx.kcbpcall.vo.Channel;
import com.hx.kcbpcall.vo.Function;
import com.hx.kcbpcall.vo.ParamVO;
import com.hx.kcbpcall.vo.ResultVO;
import com.hx.kcbpcli.KCBPClientManager;
import com.hx.kcbpcli.KCBPContext;

/*
 *�ڹ��ܺŵ���ǰ���ݹ��ܺ����ý��м�⣬�������εĵ�����Ϊ��
 *1.����channel�����������
 */
public class FunctionCheckListen implements KCBPListen {
	private Logger logger = Logger.getLogger(FunctionCheckListen.class);
	public static String BEFECALLTIME = "connection";

	private boolean log = true;

	public boolean isLog() {
		return log;
	}

	public void setLog(boolean log) {
		this.log = log;
	}

	public void fire(KCBPContext kcbpContext, int event) throws KCBPException {
		Function function = kcbpContext.getFunction();
		KCBPClientManager manager = kcbpContext.getClientManager();
		if (event == KCBPEvent.BEFORECALL) {
			if (log) {
				if (logger.isDebugEnabled())
					logger.debug("beforeCall=" + getFunctionFlag(kcbpContext)
							+ " begintime=" + System.currentTimeMillis());
				kcbpContext
						.addRequest(BEFECALLTIME, new Long(System.currentTimeMillis()));
			}

			// System.out.println();
			KCBPXConfig config = manager.getKcbpConfig();
			Channel chnl = config.getChannel(function);
			if (chnl != null) {
				if (chnl.checkIsMax()) {
					chnl.decrement();
					chnl.incrementErrorCount();
					kcbpContext.setCallStatus(KCBPException.IS_MAX_CALL);
					throw new KCBPException(KCBPException.IS_MAX_CALL,
							"�����ܵ��ó�����������������Ժ���ã�������������Ϊ" + chnl.getMaxCount()
									+ ",��ǰ�ѵ��ô���Ϊ" + chnl.getCurCount());
				}
			}
		} else if (event == KCBPEvent.BEFORECONNECT) {
			/*
			 * System.out.println(function.getFuncId() +
			 * " before connection,time=" + System.currentTimeMillis());
			 */
		} else if (event == KCBPEvent.AFTERCONNECT) {
			/*
			 * System.out.println(function.getFuncId() +
			 * " after connection,time=" + System.currentTimeMillis());
			 * System.out.println(function.getFuncId() +
			 * "connection spend time=" + (System.currentTimeMillis() - (Long)
			 * kcbpContext .getRequestValue(BEFECALLTIME)) + " " +
			 * wrapFunctionLog(kcbpContext));
			 */
		} else if (event == KCBPEvent.AFTERCCALL) {
			try {
				KCBPXConfig config = manager.getKcbpConfig();
				Channel chnl = config.getChannel(function);
				if (chnl != null
						&& kcbpContext.getCallStatus() != KCBPException.IS_MAX_CALL)
					chnl.decrement();
				if (log)
					debuginfo(kcbpContext);
			} catch (Exception e) {
				logger.error("null exception", e);
				e.printStackTrace();
			}
			/*
			 * System.out.println(function.getFuncId() + " call  spend=" +
			 * (System.currentTimeMillis() - (Long) kcbpContext
			 * .getRequestValue(BEFECALLTIME)) + wrapFunctionLog(kcbpContext));
			 */
		} else if (event == KCBPEvent.BEFOREFCONNECTCREATOR) {

		} else if (event == KCBPEvent.AFTERCONNECTCREATOR) {
			if (log)
				logger.info(kcbpContext.getConnection() + " creator.");
			// System.out.println(kcbpContext.getConnection() + " creator.");
		} else if (event == KCBPEvent.CLOSECONNECT) {
			if (log)
				logger.info(kcbpContext.getConnection() + " close.");
			// System.out.println(kcbpContext.getConnection() + " creator.");
		} else if (event == KCBPEvent.CONNECTCREATORERROR) {
			Connection conn = kcbpContext.getConnection();
			if (log)
				logger.info(conn + " creator error." + conn.getRetcode());
			// System.out.println(kcbpContext.getConnection() +
			// " creator error.");
		} else if (event == KCBPEvent.CONNECTERROR) {
			Connection conn = kcbpContext.getConnection();
			if (conn != null)
				if (log)
					logger.info(conn + " connection error.errorcode:"
							+ conn.getRetcode());
			// System.out.println(conn + " connection error.errorcode:"
			// + conn.getRetcode());
		} else if (event == KCBPEvent.EXECUTEERROR) {
			Connection conn = kcbpContext.getConnection();
			if (conn != null) {
				//conn.disabled();
				if (log)
					logger.info(conn + " execute error.errorcode:"
							+ kcbpContext.getCallresult() + " request="
							+ kcbpContext.getParamVO());
			}
		}
	}

	private String debug(long time, ResultVO vo, ParamVO pvo) {
		return "spend time:" + time + " param:" + pvo;
	}

	private void debuginfo(KCBPContext kcbpContext) {
		long spendtime = System.currentTimeMillis()
				- ((Long) kcbpContext.getRequestValue(BEFECALLTIME)).longValue();
		StringBuilder buf = new StringBuilder();
		buf.append("afterCall=").append(getFunctionFlag(kcbpContext)).append(
				" spendTime:").append(spendtime).append(" functId=").append(
				getFunctionFlag(kcbpContext)).append(" param:").append(
				kcbpContext.getParamVO());
		if (spendtime > 1000)
			logger.info(buf.toString());
		else
			logger.debug(buf.toString());
	}

	private String getFunctionFlag(KCBPContext kcbpContext) {
		return kcbpContext.getFunction().getFuncId() + "_"
				+ kcbpContext.hashCode();
	}
}
