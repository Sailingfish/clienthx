package com.hx.kcbpcli.client;

public class KCBPEvent {
	public static final int BEFORECONNECT = 1;
	public static final int AFTERCONNECT = 2;

	public static final int BEFORECALL = 3;
	public static final int AFTERCCALL = 4;

	public static final int BEFOREEXECUTE = 5;
	public static final int AFTEREXECUTE = 6;

	public static final int BEFOREGETRESULT = 7;
	public static final int AFTERGETRESULT = 8;

	public static final int BEFOREFITRESULT = 9;
	public static final int AFTERFITRESULT = 10;

	public static final int BEFOREFCONNECTCREATOR= 11;
	public static final int AFTERCONNECTCREATOR = 12;
	
	public static final int CLOSECONNECT = 13;
	//public static final int RECYLECONNECT = 14;
	
	public static final int CONNECTERROR = 500;
	
	public static final int EXECUTEERROR = 501;

	public static final int GETRESULTERROR = 502;
	
	public static final int CONNECTCREATORERROR = 503;
}
