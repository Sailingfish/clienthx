package com.hx.kcbpcli;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class KCBPConfig {

	public static KCBPConfig instance = new KCBPConfig();

	public static Map instances = new HashMap();

	// �ļ�·��
	public String configFileName = null;

	private Properties props = null;

	public synchronized static KCBPConfig getInstance(String sName) {
		if (sName == null)
			return instance;
		KCBPConfig _ins = (KCBPConfig) instances.get(sName);
		if (_ins == null) {
			_ins = new KCBPConfig(sName);
			instances.put(sName, _ins);
		}
		return _ins;
	}

	protected KCBPConfig() {
		this(null);
	}

	protected KCBPConfig(String fName) {
		if (fName == null||"".equals(fName))
			configFileName = "/kcbp-pool.properties";
		else
			configFileName = "/kcbp-pool-"+fName+".properties";
		init(configFileName);
	}

	// public static KCBPConfig getIn
	/**
	 * @param fName
	 *            �ļ�·��
	 */
	private void init(String fName) {
		// �ȴ�ϵͳ�Ļ��������ж�ȡ��û�еĻ����ڶ�����
		props = new Properties();
		// getClass().getResourceAsStream(configFileName);
		InputStream is = null;
		try {
			is = getClass().getResource(fName).openConnection()
					.getInputStream();
			props.load(is);
		} catch (Exception e) {
			throw new RuntimeException("���ܶ�ȡ�����ļ� " + configFileName
					+ "����ȷ���ļ��� CLASSPATH·����");
		} finally {
			try {
				is.close();
				is = null;
			} catch (IOException e) {
				e.printStackTrace();
				return;
			}
		}
	}

	public void reload() {
		init(configFileName);
	}

	public String get(String name) {
		return props.getProperty(name);
	}

	public String get(String name, String defValue) {
		return props.getProperty(name, defValue);
	}

	public int getInt(String name) {
		return Integer.parseInt(props.getProperty(name));
	}

	public int getInt(String name, String defValue) {
		return Integer.parseInt(props.getProperty(name, defValue));
	}

	public long getLong(String name) {
		return Long.parseLong(props.getProperty(name));
	}

	public long getLong(String name, String defValue) {
		return Long.parseLong(props.getProperty(name, defValue));
	}
}
