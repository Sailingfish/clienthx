package com.hx.kcbpcli;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

/**
 * KCBP�ͻ������ӳأ����߳�
 */

public class KCBPClientPool implements Runnable {
	protected static final Logger log = Logger
			.getLogger(com.hx.kcbpcli.KCBPClientPool.class);

	private String insName;

	KCBPConfig _ins = null;

	public long time;

	private List list = null;

	private List oldlist = new ArrayList();

	// ����״̬
	private boolean isCreate = false;

	private static KCBPClientPool clientPool = null;

	private static Map pools = new HashMap();

	private String lastReloadTime = null;
	// �ȴ�ʱ��
	int maxTimeout = 200;
	// ���ӳ������
	int maxCount = 10;
	String serverName = null;
	String user = null;
	String password = null;

	// ����ʱ��
	int reloadTime;

	int initCount;
	int reAddConnectCount;

	long interval = 30000;

	/**
	 * ���캯��
	 * 
	 * @throws Exception
	 */
	private KCBPClientPool() {
		this(null);
	}

	private void initConfig(String sName) {
		if (_ins == null)
			_ins = KCBPConfig.getInstance(sName);
		// �ȴ�ʱ��
		maxTimeout = _ins.getInt("max-timeout");
		// ���ӳ������
		maxCount = _ins.getInt("max-count");
		serverName = _ins.get("serverName");
		user = _ins.get("user");
		password = _ins.get("password");

		// ����ʱ��
		reloadTime = _ins.getInt("pool_reload_time");

		initCount = _ins.getInt("init-count");
		reAddConnectCount = Integer.parseInt(_ins.get("readd-connect-count",
				"3"));

		interval = _ins.getLong("interval");
	}

	/**
	 * ���캯��
	 * 
	 * @throws Exception
	 */
	private KCBPClientPool(String sName) {
		this.insName = sName;
		initConfig(sName);
		if (list == null)
			try {
				// ��ʼ��
				init(insName);
			} catch (Exception e) {
				log.error("��KCBP���ӳس�ʼ�������쳣��" + e.getMessage());
			}
		if (!isCreate && reloadTime >= 0 && reloadTime <= 24) {
			isCreate = true;
			Thread thread = new Thread(this);
			thread.start();
		}
	}

	private void init(String sName) throws Exception {
		createKCBPClientPool();
	}

	public static synchronized KCBPClientPool getClientPool() {
		if (clientPool == null) {
			clientPool = new KCBPClientPool();
		}
		return clientPool;
	}

	public static synchronized KCBPClientPool getClientPool(String sName) {
		if (sName == null || "".equals(sName))
			return getClientPool();
		KCBPClientPool cpool = (KCBPClientPool) pools.get(sName);
		if (cpool == null) {
			cpool = new KCBPClientPool(sName);
			pools.put(sName, cpool);
		}
		return cpool;
	}

	/**
	 * ��ȡ�ͻ��ˣ�����KCBP�ͻ��˰�װ��
	 * 
	 * @return
	 */
	public synchronized KCBPClientWrap getKCBPClient() {
		if (list == null)
			return null;

		long startTime = System.currentTimeMillis();

		// �ͷ�disabled������
		for (int i = list.size() - 1; i >= 0; i--) {
			KCBPClientWrap client = (KCBPClientWrap) list.get(i);
			if (client.disabled) {
				client.close();
				list.remove(i);
			}
		}

		// ����ͷ��п��õ�����
		// if (getActiveCount() != 0) {
		for (int i = 0; i < list.size(); i++) {
			KCBPClientWrap client = (KCBPClientWrap) list.get(i);
			if (client.free && client.disabled == false) {
				client.free = false;
				client.start = System.currentTimeMillis();
				return client;
			}
		}

		// } else {

		if (maxCount > list.size()) {
			// �����ͻ��˵�1����
			try {
				KCBPClientWrap client = addKCBPClient(0);
				if (client != null) {
					client.free = false;
					client.start = System.currentTimeMillis();
				}
				return client;
			} catch (Exception e) {
				log.error("����KCBP���Ӷ������쳣��" + e.getMessage());
				return null;
			}
		} else
		// ���������ʱ�ȴ�
		{
			// ��ʾ�����޵�ʱ���ڽ���ѭ��ȡ���ӣ�ֱ��ȡ������Ϊֹ����ֹ����socket����
			while (System.currentTimeMillis() - startTime < maxTimeout) {
				// �ӳ����ҵ����е�����
				for (int i = 0; i < list.size(); i++) {
					KCBPClientWrap client = (KCBPClientWrap) list.get(i);
					if (client.free && client.disabled == false) {
						client.free = false;
						client.start = System.currentTimeMillis();
						return client;
					}
				}
			}
		}

		// }
		return null;
	}

	/**
	 * �ж��Ƿ���Ҫ������KCBP���ӻ���ͨѶ�������Զ�����
	 * 
	 * @param call
	 *            ���ش���
	 * @return true ��Ҫ����
	 */
	public boolean isReconnectCode(int call) {
		if (call == 0 || _ins == null) {
			return false;
		}
		String codes = _ins.get("reconnect-code",
				"2054,2055,2003,2004,2011,2095");
		if (codes.length() > 0) {
			if (codes.charAt(0) != ',') {
				codes = "." + codes;
			}
			if (codes.indexOf(String.valueOf(call)) >= 0) {
				return true;
			} else {
				return false;
			}
		}
		return false;
	}

	// ���з���
	public void run() {

		do {
			try {
				Thread.sleep(interval);
			} catch (Exception e) {
				log.error("ɨ���ʼ�������߳����߷����쳣��" + e.getMessage());
			}
			scan(interval);
			if (oldlist != null && oldlist.size() > 0) {
				clearConnect(oldlist);
			}

		} while (true);

	}

	private void clearConnect(List inputList) {
		long start = System.currentTimeMillis();
		for (int i = inputList.size() - 1; i >= 0; i--) {
			KCBPClientWrap client = (KCBPClientWrap) inputList.get(i);
			if (client.free || client.disabled
					|| start - client.start > 3600000) {
				client.close();
				inputList.remove(i);
			}
		}
	}

	/**
	 * �߳�ɨ��������ӽ������½����ͷ�
	 */
	private void scan(long interval) {
		// �رմ��ڳ�ʼ������������
		Calendar calendar = Calendar.getInstance();
		int currentHour = calendar.get(Calendar.HOUR_OF_DAY);
		Format format = new SimpleDateFormat("yyyyMMdd");
		String currentDate = format.format(calendar.getTime());
		long intervalHour = interval / 3600000;
		if (reloadTime <= currentHour
				&& reloadTime >= currentHour + intervalHour
				&& !currentDate.equals(lastReloadTime)) {
			reInitPool();
			lastReloadTime = currentDate;
			if (log.isInfoEnabled()) {
				log.info("��ʼ��KCBP���ӳ����!����ʼ������:" + lastReloadTime);
			}
		}
	}

	/**
	 * ��ʼ���������ӳ�
	 * 
	 * @param config
	 * @throws Exception
	 */
	private void createKCBPClientPool() throws Exception {
		try {
			long start = System.currentTimeMillis();
			initKCBPClient(initCount);
			long elapsed = System.currentTimeMillis() - start;
			log.info("connected spend time:" + elapsed + " current date:"
					+ new Date());
		} catch (Exception e) {
			log.error("��ʼ���������ӳط����쳣��" + e.getMessage());
			throw new Exception(e.getMessage());
		}
	}

	/**
	 * ��ʼ��KCBP�ͻ���
	 * 
	 * @param count
	 * @throws Exception
	 */
	private void initKCBPClient(int count) throws Exception {
		if (list == null)
			list = new ArrayList(count);
		int i = 0;
		do {
			if (i >= count)
				break;
			KCBPClientWrap c = new KCBPClientWrap(serverName, user, password);
			if (c.client != null) {
				list.add(c);
			}
			i++;
		} while (true);
		if (log.isInfoEnabled()) {
			log.info("ɨ��KCBP�����̴߳���KCBP���ӹ�" + list.size() + "����");
		}
	}

	/**
	 * ����һ��KCBP�ͻ���
	 * 
	 * @param count
	 * @throws Exception
	 */
	private KCBPClientWrap addKCBPClient(int execCount) throws Exception {
		if (list == null)
			list = new ArrayList();

		KCBPClientWrap c = new KCBPClientWrap(serverName, user, password);
		if (c.client != null) {
			list.add(c);
			return c;
		} else {
			while (execCount < reAddConnectCount || reAddConnectCount == -1) {
				execCount++;
				c = addKCBPClient(execCount);
				if (c != null && c.client != null) {
					return c;
				}

			}
			log.error(execCount + " �γ�������KCXPʧ�ܣ�");
		}

		return null;
	}

	/**
	 * ���ӳ���
	 * 
	 * @return
	 */
	public int getTotalCount() {
		return list == null ? 0 : list.size();
	}

	/**
	 * �ռ�����ӳ���
	 * 
	 * @return
	 */
	public int getActiveCount() {
		if (list == null)
			return 0;
		int count = 0;
		for (int i = 0; i < list.size(); i++) {
			KCBPClientWrap client = (KCBPClientWrap) list.get(i);
			if (client.free && client.disabled == false)
				count++;
		}

		return count;
	}

	/**
	 * ��Ч�����ӳ���
	 * 
	 * @return
	 */
	public int getDisableCount() {
		if (list == null)
			return 0;
		int count = 0;
		for (int i = 0; i < list.size(); i++) {
			KCBPClientWrap client = (KCBPClientWrap) list.get(i);
			if (client.disabled == true)
				count++;
		}

		return count;
	}

	/**
	 * �ر���������
	 * 
	 * @return
	 */
	public void reInitPool() {
		long start = System.currentTimeMillis();
		clearConnect(list);
		long elapsed = System.currentTimeMillis() - start;
		log
				.info("cloase spend time:" + elapsed + " current date:"
						+ new Date());
		if (list.size() != 0) {
			oldlist.addAll(list);
		}
		list = null;
		try {
			// ��ʼ��
			init(insName);
		} catch (Exception e) {
			log.error("���³�ʼ��KCBP���ӳط����쳣��" + e.getMessage());
		}

	}

	public static void main(String[] args) {
		/*
		 * CallLBM callLBM = new CallLBM(); for (int i = 0; i < 100; i++) {
		 * callLBM.test(); }
		 */
	}

	public void reload() {
		if (_ins == null)
			return;
		_ins.reload();

		initConfig(insName);

		reInitPool();
	}

}
