package com.hx.kcbpcli.client;

import com.hx.kcbpcall.Exception.KCBPException;
import com.hx.kcbpcli.KCBPContext;

public interface KCBPListen {
	public void fire(KCBPContext kcbpContext, int event) throws KCBPException;
}
