package com.hx.kcbpcli.client;

import java.util.Date;

import org.apache.log4j.Logger;

import com.hx.kcbpcall.LBMCallBack;
import com.hx.kcbpcall.Exception.KCBPException;
import com.hx.kcbpcall.vo.ParamVO;
import com.hx.kcbpcall.vo.ResultFactory;
import com.hx.kcbpcall.vo.ResultVO;
import com.hx.kcbpcli.KCBPClientWrap;
import com.hx.kcbpcli.KCBPContext;
import com.szkingdom.kcbpcli.KCBPClient;
import com.szkingdom.kcbpcli.tagKCBPConnectOption;

public class KCBPConnection implements Connection {
	private static final Logger log = Logger.getLogger(KCBPConnection.class);
	private static int totalcount;
	private String name;
	private KCBPClientWrap clientWrap;
	public KCBPClient client;
	// private KCBPContext kcbpContext;
	private long useCount = 0;
	private long start;
	private String serverName;
	private String user;

	/**
	 * ���췽��
	 * 
	 * @param serverName
	 * @param user
	 * @param password
	 * @throws Exception
	 */
	public KCBPConnection(tagKCBPConnectOption option, String serverName,
			String user, String password) {
		this.serverName = serverName;
		this.user = user;
		clientWrap = new KCBPClientWrap(option, serverName, user, password);
		client = clientWrap.client;
		totalcount++;
		name = "connection_" + totalcount;
	}

	/**
	 * ���췽��
	 * 
	 * @param serverName
	 * @param user
	 * @param password
	 * @throws Exception
	 */
	public KCBPConnection(String serverName, String user, String password) {
		this(null, serverName, user, password);
	}

	public KCBPClientWrap getClientWrap() {
		return clientWrap;
	}

	public KCBPClient getClient() {
		return client;
	}

	public void close() {
		clientWrap.close();
	}

	public void free(boolean free) {
		clientWrap.free = free;
	}

	public boolean isFree() {
		return clientWrap.free;
	}

	public void disabled() {
		clientWrap.disabled = true;
	}

	public boolean isDisabled() {
		return clientWrap.disabled;
	}

	public int getHandle() {
		return clientWrap.hand;
	}

	public boolean isConn() {
		return client != null;
	}

	public int getRetcode() {
		return clientWrap.retcode;
	}

	public boolean testConn() {
		return true;
	}

	public long getUseCount() {
		return useCount;
	}

	public void incrementUseCount() {
		useCount++;
	}

	public long getStartTime() {
		return clientWrap.start;
	}

	public long getLastActiveTimeMillis() {
		return clientWrap.lastActiveTimeMillis;
	}

	public ResultVO execute(KCBPContext kcbpContext) throws KCBPException {
		if (client == null)
			return ResultFactory.getResultVO(ResultFactory.CONN_ERROR);
		try {
			LBMCallBack callback = kcbpContext.getCallback();
			ParamVO pvo = kcbpContext.getParamVO();
			ResultVO result = callback.call(kcbpContext);
			return result;
		} catch (KCBPException ex) {
			throw ex;
		} finally {
			clientWrap.disConnect();
			if (!kcbpContext.isPool()) {
				close();
			} else {
				kcbpContext.getPool().recycle(kcbpContext, this);
			}
		}
	}

	public long setLastActiveTimeMillis(long lastActiveTimeMillis) {
		return clientWrap.lastActiveTimeMillis = lastActiveTimeMillis;
	}

	public String toString() {
		StringBuilder buf = new StringBuilder();
		buf.append(" connection:name=").append(name);
		buf.append(" retcode=").append(this.getRetcode());
		buf.append(" serverName=").append(this.serverName);
		buf.append(" user=").append(this.user);
		buf.append(" userCount=").append(this.useCount);
		buf.append(" startTime=").append(new Date(getStartTime()));
		buf.append(" lastActiveTimeMillis=").append(
				new Date(getLastActiveTimeMillis()));
		return buf.toString();
	}
}
