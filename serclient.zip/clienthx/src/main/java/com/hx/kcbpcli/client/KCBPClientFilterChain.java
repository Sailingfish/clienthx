package com.hx.kcbpcli.client;

import java.util.List;

import com.hx.kcbpcli.KCBPClientWrap;
import com.hx.kcbpcli.KCBPContext;

public class KCBPClientFilterChain {
	private final KCBPContext kcbpContext;
	private final KCBPClientWrap kcbpclient;
	protected int pos = 0;
	private final int filterSize;

	public KCBPClientFilterChain(KCBPContext kcbpContext,KCBPClientWrap kcbpclient) {
		this.kcbpContext=kcbpContext;
		this.kcbpclient = kcbpclient;
		this.filterSize = getFilters().size();
	}

	private List getFilters() {
		return null;
	}

/*	private Filter nextFilter() {
		Filter filter = (Filter) getFilters().get(pos++);
		return filter;
	}*/

	public int getFilterSize() {
		return filterSize;
	}
}
