package com.hx.kcbpcli;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.hx.kcbpcall.Exception.KCBPException;
import com.hx.kcbpcall.config.KCBPXConfig;
import com.hx.kcbpcall.vo.Function;
import com.hx.kcbpcli.client.Connection;
import com.hx.kcbpcli.client.FunctionCheckListen;
import com.hx.kcbpcli.client.KCBPListen;

/*
 * ͨ�����ӳع���
 */
public class KCBPClientManager {
	private static Logger log = Logger.getLogger(KCBPClientManager.class);
	private Map pools = new HashMap();
	private List listens = new ArrayList();// ���ܺ�
	private KCBPXConfig kcbpConfig;

	public KCBPClientManager() {
		loadConfig("/kcbp-config.xml", true);
	}

	private void initListen() {
		if (kcbpConfig == null)
			return;
		List ls = kcbpConfig.getListens();
		for (int i = 0; i < ls.size(); i++) {
			String clsName = (String) ls.get(i);
			try {
				listens.add(Class.forName(clsName).newInstance());
			} catch (Exception e) {
				e.printStackTrace();
				log.error("load listen error", e);
			}
		}
	}

	public void loadConfig(String configName, boolean isClassLoad) {
		InputStream in = null;
		try {
			if (isClassLoad)
				in = KCBPClientManager.class.getResourceAsStream(configName);
			else
				in = new java.io.FileInputStream(configName);
			kcbpConfig = new KCBPXConfig();
			kcbpConfig.addConfig(in);
			in.close();
		} catch (Exception e) {
			if (in != null)
				try {
					in.close();
				} catch (IOException e1) {
				}
			log.error("parse functions.xml error", e);
		}

		initListen();
	}

	public void loadListens() {

	}

	/**
	 * ����KCBP����
	 * 
	 * @param handle
	 * @return KCBP�ͻ��˰�װ��
	 */
	public KCBPClientWrap connectKCBPServer(KCBPContext kcbpContext) {
		Function function = kcbpContext.getFunction();
		String serverName = function.getServerName();

		KCBPClientPool pool = null;
		KCBPClientWrap client = null;
		try {
			pool = KCBPClientPool.getClientPool(serverName);
			client = pool.getKCBPClient();
		} catch (Exception e) {
			log.error("��KCBP���ӳػ�ȡ���ӷ����쳣��" + e.getMessage());
			return null;
		}
		return client;
	}

	public Connection getConnection(KCBPContext kcbpContext)
			throws KCBPException {
		Function function = kcbpContext.getFunction();
		if (function == null) {
			function = new Function();
			if (kcbpContext.getParamVO() != null)
				function.setFuncId((String) kcbpContext.getParamVO().get(
						"funcId"));
			kcbpContext.setFunction(function);
		}
		KCBPClientXPool xpool = getKCBPClientXPool(kcbpContext, function
				.getServerName());
		kcbpContext.setPool(xpool);
		return xpool.getConnection(kcbpContext);
	}

	public KCBPClientXPool getKCBPClientXPool(KCBPContext kcbpContext,
			String serverName) {
		if (serverName == null || KCBPXConfig.DEFAULT.equals(serverName))
			serverName = KCBPXConfig.DEFAULT;
		KCBPClientXPool clientPool = (KCBPClientXPool) pools.get(serverName);
		if (clientPool != null)
			return clientPool;

		synchronized (this) {
			clientPool = (KCBPClientXPool) pools.get(serverName);
			if (clientPool != null)
				return clientPool;
			// ��ʼ�����ӳ�
			clientPool = new KCBPClientXPool(kcbpConfig
					.getKCBPServer(serverName));
			pools.put(serverName, clientPool);
		}
		return clientPool;
	}

	public void fire(KCBPContext context, int event) throws KCBPException {
		if (listens == null)
			return;
		for (int i = 0; i < listens.size(); i++) {
			((KCBPListen) listens.get(i)).fire(context, event);
		}
	}

	public boolean isPool() {
		return true;
	}

	public KCBPXConfig getKcbpConfig() {
		return kcbpConfig;
	}

	public Map getPools() {
		return pools;
	}

	public List getListens() {
		return listens;
	}

}
