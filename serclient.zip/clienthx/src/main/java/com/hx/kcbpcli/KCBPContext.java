package com.hx.kcbpcli;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.hx.kcbpcall.DefaultCallBack;
import com.hx.kcbpcall.LBMCallBack;
import com.hx.kcbpcall.Exception.KCBPException;
import com.hx.kcbpcall.vo.Function;
import com.hx.kcbpcall.vo.ParamVO;
import com.hx.kcbpcall.vo.ResultVO;
import com.hx.kcbpcli.client.Connection;
import com.hx.kcbpcli.client.KCBPEvent;

/*
 * ˵����         ���ܺŵ��ù���������
 * �������ڣ�һ�ι��ܺŵ�������
 */
public class KCBPContext {
	private static LBMCallBack defaultCallback = new DefaultCallBack();//

	private Connection connection;
	private Function function;// ���ܺ�
	private ParamVO paramVO;
	private List resultList;
	private ResultVO resultVO;
	private Map requestMap;
	private KCBPClientXPool pool;
	
	private LBMCallBack callback;//

	private KCBPClientManager clientManager;

	private int callresult; // ���ܺ�ִ�к󷵻ص�״̬����
	private int execCount; // ���ܺű��ε���ִ�д���

	private int callStatus;  //0 Ϊ����״̬  ���Ϊ��0�����ʾ���ι��ܲ�����������

	public Function getFunction() {
		return function;
	}

	public void setFunction(Function function) {
		this.function = function;
	}

	public LBMCallBack getCallback() {
		if (callback == null)
			callback = defaultCallback;
		return callback;
	}

	public void setCallback(LBMCallBack callback) {
		this.callback = callback;
	}

	public ParamVO getParamVO() {
		return paramVO;
	}

	public void setParamVO(ParamVO paramVO) {
		this.paramVO = paramVO;
	}

	public KCBPClientManager getClientManager() {
		return clientManager;
	}

	public void setClientManager(KCBPClientManager clientManager) {
		this.clientManager = clientManager;
	}

	public KCBPClientWrap getKcbpclient() {
		return connection.getClientWrap();
	}

	public boolean isPool() {
		return pool!=null;//clientManager != null && clientManager.isPool();
	}

	public Connection getConnection() {
		return connection;
	}

	public KCBPClientXPool getPool() {
		return pool;
	}

	public void setPool(KCBPClientXPool pool) {
		this.pool = pool;
	}

	public void setConnection(Connection connection) {
		this.connection = connection;
	}
	
	

	public void fire(int event)  throws KCBPException{
		if (clientManager != null)
			clientManager.fire(this, event);
	}



	public int getCallStatus() {
		return callStatus;
	}

	public void setCallStatus(int callStatus) {
		this.callStatus = callStatus;
	}

	public int getCallresult() {
		return callresult;
	}

	/*
	 * ִ�е��ú����÷��ر��
	 */
	public void setCallresult(int callresult) {
		this.callresult = callresult;
	}

	public List getResultList() {
		return resultList;
	}

	/*
	 * ���Զ�����ݻ�ȡ����󣬷��ؽ������
	 */
	public void setResultList(List paramvoList) {
		this.resultList = resultList;
	}

	public ResultVO getResultVO() {
		return resultVO;
	}

	/*
	 * ������ݽ��Ԥ������
	 */
	public void setResultVO(ResultVO resultVO) {
		this.resultVO = resultVO;
	}

	public void addRequest(String key, Object value) {
		if (requestMap == null)
			requestMap = new HashMap();
		requestMap.put(key, value);
	}

	public Map getRequest() {
		return requestMap;
	}

	public Object getRequestValue(String key) {
		if (requestMap == null)
			return null;
		return requestMap.get(key);
	}

}
