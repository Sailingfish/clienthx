package com.hx.kcbpcli;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.log4j.Logger;

import com.hx.kcbpcall.Exception.KCBPException;
import com.hx.kcbpcall.vo.KCBPServer;
import com.hx.kcbpcli.client.Connection;
import com.hx.kcbpcli.client.KCBPConnection;
import com.hx.kcbpcli.client.KCBPEvent;

public class KCBPClientXPool {

	private KCBPServer server;
	private volatile Connection[] connections;

	public final static int DEFAULT_INITIAL_SIZE = 0;
	public final static int DEFAULT_MAX_ACTIVE_SIZE = 8;
	public final static int DEFAULT_MAX_IDLE = 8;
	public final static int DEFAULT_MIN_IDLE = 0;
	public final static int DEFAULT_MAX_WAIT = -1;
	public final static String DEFAULT_VALIDATION_QUERY = null; //
	public final static boolean DEFAULT_TEST_ON_BORROW = true;
	public final static boolean DEFAULT_TEST_ON_RETURN = false;
	public final static boolean DEFAULT_WHILE_IDLE = false;
	public static final long DEFAULT_TIME_BETWEEN_EVICTION_RUNS_MILLIS = -1L;
	public static final long DEFAULT_TIME_BETWEEN_CONNECT_ERROR_MILLIS = 30 * 1000;
	public static final int DEFAULT_NUM_TESTS_PER_EVICTION_RUN = 3;

	private static Logger logger = Logger.getLogger(KCBPClientXPool.class);
	protected final ReentrantLock lock = new ReentrantLock(true);
	private final Condition notEmpty = lock.newCondition();
	private final Condition empty = lock.newCondition();
	protected AtomicLong destroyCount = new AtomicLong();

	protected volatile int initialSize = DEFAULT_INITIAL_SIZE;
	protected volatile int maxActive = DEFAULT_MAX_ACTIVE_SIZE;
	protected volatile int minIdle = DEFAULT_MIN_IDLE;
	protected volatile int maxIdle = DEFAULT_MAX_IDLE;
	protected volatile long maxWait = DEFAULT_MAX_WAIT;
	protected volatile long minEvictableIdleTimeMillis = 1000L * 60L * 30L;

	protected volatile int maxWaitThreadCount = -1;

	private long connectCount = 0L;// ��ȡ���ӵ�����
	private long closeCount = 0L;
	private final AtomicLong connectErrorCount = new AtomicLong();
	private long recycleCount = 0L;
	private long removeAbandonedCount = 0L;
	private long notEmptyWaitCount = 0L;// ��Ϊ�գ����»�ȡ����ʱ������ֵ����Ҫ�ȴ������µ�����
	private long notEmptySignalCount = 0L;
	private long notEmptyWaitNanos = 0L;

	private int activePeak = 0;// ��ʷ���������
	private long activePeakTime = 0;// ��ʷ���ʱ��
	private int poolingPeak = 0;
	private long poolingPeakTime = 0;

	private int poolingCount = 0;
	private int activeCount = 0;// ��ǰ���������
	private long discardCount = 0;
	private int notEmptyWaitThreadCount = 0;
	private int notEmptyWaitThreadPeak = 0;

	protected long createErrorCount;
	protected Throwable createError;

	private volatile boolean closed = false;
	protected volatile boolean inited = false;

	// threads
	private GenKCBPClientThread genKCBPClientThread;
	private DestoryKCBPClientThread destoryKCBPClientThread;
	private final CountDownLatch initedLatch = new CountDownLatch(2); // ��ʼ������

	private String initStackTrace;

	private String connectError;

	private KCBPContext context;

	public KCBPClientXPool(KCBPServer server) {
		initConfig(server);
	}

	public void initConfig(KCBPServer server) {
		this.server = server;
		initialSize = server.getInitialPoolSize();
		maxActive = server.getMaxPoolSize();
		minIdle = server.getMinPoolSize();
		// maxWaitThreadCount= server.getMaxPoolSize()+1;
	}

	public long getMaxWait() {
		return maxWait;
	}

	public void setMaxWait(long maxWaitMillis) {
		if (maxWaitMillis == this.maxWait) {
			return;
		}

		if (inited) {
			logger.error("maxWait changed : " + this.maxWait + " -> "
					+ maxWaitMillis);
		}

		this.maxWait = maxWaitMillis;
	}

	public int getMinIdle() {
		return minIdle;
	}

	public void setMinIdle(int value) {
		if (value == this.minIdle) {
			return;
		}

		if (inited) {
			if (value > this.maxActive) {
				throw new IllegalArgumentException(
						"minIdle greater than maxActive, " + maxActive + " < "
								+ this.minIdle);
			}

			logger.error("minIdle changed : " + this.minIdle + " -> " + value);
		}

		this.minIdle = value;
	}

	public int getMaxIdle() {
		return maxIdle;
	}

	public int getInitialSize() {
		return initialSize;
	}

	public void setInitialSize(int initialSize) {
		if (this.initialSize == initialSize) {
			return;
		}

		if (inited) {
			throw new UnsupportedOperationException();
		}

		this.initialSize = initialSize;
	}

	public long getCreateErrorCount() {
		return createErrorCount;
	}

	public int getMaxWaitThreadCount() {
		return maxWaitThreadCount;
	}

	public void setMaxWaitThreadCount(int maxWaithThreadCount) {
		this.maxWaitThreadCount = maxWaithThreadCount;
	}

	public int getMaxActive() {
		return maxActive;
	}

	public void setMaxActive(int maxActive) {
		if (this.maxActive == maxActive) {
			return;
		}

		if (maxActive == 0) {
			throw new IllegalArgumentException("maxActive can't not set zero");
		}

		if (!inited) {
			this.maxActive = maxActive;
			return;
		}

		if (maxActive < this.minIdle) {
			throw new IllegalArgumentException("maxActive less than minIdle, "
					+ maxActive + " < " + this.minIdle);
		}

		logger.info("maxActive changed : " + this.maxActive + " -> "
				+ maxActive);

		lock.lock();
		try {
			int allCount = this.poolingCount + this.activeCount;

			if (maxActive > allCount) {
				//System.arraycopy(this.connections, 0, this.connections, 0, maxActive);
				// Arrays.copyOf(this.connections, maxActive);
				this.connections = copyOf(this.connections, maxActive);
			} else {
				//System.arraycopy(this.connections, 0, this.connections, 0, allCount);
				//this.connections = Arrays.copyOf(this.connections, allCount);
				this.connections = copyOf(this.connections, allCount);
			}

			this.maxActive = maxActive;
		} finally {
			lock.unlock();
		}
	}

	public static Connection[] copyOf(Object[] original, int newLength) {
		Connection[] copy =  new Connection[newLength];
        System.arraycopy(original, 0, copy, 0,
                         Math.min(original.length, newLength));
        return copy;
    }
	
    public static Object[] copyOf(Object[] original, int newLength, Class newType) {
    	Object[] copy =  new Object[newLength];
    	Array.newInstance(newType.getComponentType(), newLength);
        System.arraycopy(original, 0, copy, 0,
                         Math.min(original.length, newLength));
        return copy;
    }
	
	public Connection getConnection(KCBPContext kcbpContext)
			throws KCBPException {
		return getConnection(kcbpContext, maxWait);
	}

	public Connection getConnection(KCBPContext kcbpContext, long maxWaitMillis)
			throws KCBPException {
		init(kcbpContext);
		return getConnectionDirect(kcbpContext, maxWaitMillis);
	}

	public String toString(StackTraceElement[] stackTrace) {
		if (stackTrace==null||stackTrace.length==0) return null;
		StringBuilder buf = new StringBuilder();
		int i = 0;
		for (i = 0; i < stackTrace.length; i++) {
			buf.append(stackTrace[i]);
			buf.append("\n");
		}
		return buf.toString();
	}

	private void init(KCBPContext kcbpContext) throws KCBPException {
		if (inited) {
			return;
		}

		try {
			lock.lockInterruptibly();
		} catch (InterruptedException e) {
			throw new KCBPException(-1, "interrupt", e);
		}
		this.context = kcbpContext;
		boolean init = false;
		try {
			if (inited) {
				return;
			}

			init = true;

			initStackTrace = toString(Thread.currentThread().getStackTrace());

			if (maxActive <= 0) {
				throw new IllegalArgumentException("illegal maxActive "
						+ maxActive);
			}

			if (maxActive < minIdle) {
				throw new IllegalArgumentException("illegal maxActive "
						+ maxActive);
			}

			if (getInitialSize() > maxActive) {
				throw new IllegalArgumentException("illegal initialSize "
						+ this.initialSize + ", maxActieve " + maxActive);
			}

			connections = new KCBPConnection[maxActive];
			KCBPException error = null;
			try {
				// ��ʼ������
				for (int i = 0, size = getInitialSize(); i < size; ++i) {
					Connection conn = createKCBPConnection();
					if (conn != null && conn.getClient() != null)
						connections[poolingCount++] = conn;
				}

				if (poolingCount > 0) {
					poolingPeak = poolingCount;
					poolingPeakTime = System.currentTimeMillis();
				}
			} catch (KCBPException ex) {
				logger.error("init connection error", ex);
				error = ex;
			}
			startCreatorThread();
			startDestroyThread();

			initedLatch.await();

			if (poolingCount == 0) {
				connectError = "���ӳ��ڵ���initʱ����ʼ��ʧ�ܡ�";
			}
			if (error != null)
				throw error;
		} catch (KCBPException e1) {
			logger.error("init connection error", e1);
			throw new KCBPException(KCBPException.CREATORCONN_ERROR,
					e1.toString());
		} catch (InterruptedException e2) {
			throw new KCBPException(KCBPException.CREATORCONN_ERROR,
					e2.toString());
		} finally {
			inited = true;
			lock.unlock();

			logger.info("{kcbpconnection-" + this.server.getName() + "} inited");

		}
	}

	private void startCreatorThread() {
		genKCBPClientThread = new GenKCBPClientThread(server.getName()
				+ " Kcbp connection creator");
		genKCBPClientThread.start();
	}

	private void startDestroyThread() {
		destoryKCBPClientThread = new DestoryKCBPClientThread(server.getName()
				+ " Kcbp connection destory");
		destoryKCBPClientThread.start();
	}

	public Connection getConnectionDirect(KCBPContext kcbpContext,
			long maxWaitMillis) throws KCBPException {

		if (closed) {
			connectErrorCount.incrementAndGet();
			connectError = "���ӳ��ѹر�";
			return null;
		}

		final long nanos = TimeUnit.MILLISECONDS.toNanos(maxWait);
		final int maxWaitThreadCount = getMaxWaitThreadCount();
		Connection conn;
		try {
			lock.lockInterruptibly();
		} catch (InterruptedException e) {
			connectErrorCount.incrementAndGet();
			throw new KCBPException(506, "interrupt", e);
		}

		try {
			if (maxWaitThreadCount > 0) {
				if (notEmptyWaitThreadCount >= maxWaitThreadCount) {
					connectErrorCount.incrementAndGet();
					throw new KCBPException(508, "maxWaitThreadCount "
							+ maxWaitThreadCount
							+ ", current wait Thread count "
							+ lock.getQueueLength());
				}
			}
			// if (activeCount==0&&poolingCount==0&&notEmptyWaitThreadCount>10)
			// ���ӳ��쳣
			connectCount++;
			this.context = kcbpContext;
			if (maxWait > 0) {
				conn = pollLast(nanos);
			} else {
				conn = takeLast();
			}

			activeCount++;
			if (activeCount > activePeak) {
				activePeak = activeCount;
				activePeakTime = System.currentTimeMillis();
			}

		} catch (InterruptedException e) {
			connectErrorCount.incrementAndGet();
			throw new KCBPException(506, "interrupt", e);
		} finally {
			lock.unlock();
		}

		conn.incrementUseCount();
		// conn.setLastActiveTimeMillis(System.currentTimeMillis());
		conn.free(false);
		return conn;
	}

	public String toString() {
		return getStatInfo().toString();
	}

	public Map getStatInfo() {
		Map map = new HashMap();
		map.put("server", server);
		map.put("CreateErrorCount", Long.valueOf(createErrorCount));// ��������ʧ������
		// map.put("DiscardCount", discardCount);
		map.put("DestroyCount", destroyCount);

		map.put("CloseCount", Long.valueOf(this.closeCount));
		map.put("ActiveCount", Long.valueOf(activeCount));// ��ǰ���������
		map.put("PoolingCount", Long.valueOf(poolingCount));// ���ӳ�����
		map.put("WaitThreadCount", Long.valueOf(maxWaitThreadCount));

		map.put("NotEmptyWaitCount", Long.valueOf(notEmptyWaitCount));// ��Ϊ�գ����»�ȡ����ʱ������ֵ��
		// ��Ҫ�ȴ������µ�����
		map.put("NotEmptyWaitNanos", Long.valueOf(notEmptyWaitNanos));// ��������˵ȴ�ʱ����������ȴ�ʱ����ֵ

		map.put("InitialSize", Long.valueOf(initialSize)); // ��ʼֵ
		map.put("MaxActive", Long.valueOf(this.maxActive));// ���ֵ
		map.put("MinIdle", Long.valueOf(this.minIdle)); // ���ӳ���С����

		map.put("ConnectErrorCount", this.connectErrorCount);// �������ӳ�����
		map.put("activePeak", Long.valueOf(this.activePeak));// ��ʷ���������
		map.put("activePeakTime", new Date(this.activePeakTime));// ��ʷ���ʱ��

		map.put("poolingPeak", Long.valueOf(this.poolingPeak));// ��ʷ������ӳظ���
		map.put("poolingPeakTime", new Date(this.poolingPeakTime));// ��ʷ������ӳظ���ʱ��

		return map;
	}

	public String printDetail() {
		return null;
	}

	Connection takeLast() throws InterruptedException {
		try {
			while (poolingCount == 0) {
				empty.signal(); // send signal to CreateThread create connection
				notEmptyWaitThreadCount++;
				if (notEmptyWaitThreadCount > notEmptyWaitThreadPeak) {
					notEmptyWaitThreadPeak = notEmptyWaitThreadCount;
				}
				try {
					notEmpty.await(); // signal by recycle or creator
				} finally {
					notEmptyWaitThreadCount--;
				}
				notEmptyWaitCount++;
			}
		} catch (InterruptedException ie) {
			notEmpty.signal(); // propagate to non-interrupted thread
			notEmptySignalCount++;
			throw ie;
		}

		poolingCount--;
		Connection last = connections[poolingCount];
		connections[poolingCount] = null;

		return last;
	}

	void putLast(Connection e, long lastActiveTimeMillis) throws KCBPException {
		e.setLastActiveTimeMillis(lastActiveTimeMillis);
		e.free(true);
		connections[poolingCount++] = e;

		if (poolingCount > poolingPeak) {
			poolingPeak = poolingCount;
			poolingPeakTime = lastActiveTimeMillis;
		}

		notEmpty.signal();
		notEmptySignalCount++;
	}

	/**
	 * �������ӣ������л��գ���������
	 * 
	 * @param conn
	 * @throws KCBPException
	 */
	private void discardConnection(Connection conn) throws KCBPException {
		connClose(conn);
		lock.lock();
		try {
			activeCount--;
			discardCount++;
		} finally {
			lock.unlock();
		}
	}

	/**
	 * ��������
	 */
	public void recycle(KCBPContext kcbpContext, Connection conn)
			throws KCBPException {

		try {
			if (conn.isDisabled()) {
				discardConnection(conn);
				return;
			}

			final long lastActiveTimeMillis = System.currentTimeMillis();
			lock.lockInterruptibly();
			try {
				activeCount--;
				closeCount++;

				putLast(conn, lastActiveTimeMillis);
				recycleCount++;
			} finally {
				lock.unlock();
			}
		} catch (InterruptedException e) {
			// connClose(conn);
			try {
				lock.lockInterruptibly();
			} catch (InterruptedException interruptEx) {
				logger.error("recyle error", interruptEx);
			}

			try {
				activeCount--;
				closeCount++;
			} finally {
				lock.unlock();
			}

			logger.error("recyle error", e);
		}
	}

	Connection pollLast(long nanos) throws KCBPException {
		long estimate = nanos;

		for (int i = 0;; ++i) {
			if (poolingCount == 0) {
				empty.signal(); // send signal to CreateThread create connection

				if (estimate <= 0) {
					throw new KCBPException(501, "ʱ��������ò���ȷ���ȴ�ʱ����" + estimate);
				}

				notEmptyWaitThreadCount++;
				if (notEmptyWaitThreadCount > notEmptyWaitThreadPeak) {
					notEmptyWaitThreadPeak = notEmptyWaitThreadCount;
				}

				try {
					long startEstimate = estimate;
					estimate = notEmpty.awaitNanos(estimate); // signal by
					// recycle or
					// creator
					notEmptyWaitCount++;
					notEmptyWaitNanos += (startEstimate - estimate);

				} catch (InterruptedException ie) {
					notEmpty.signal(); // propagate to non-interrupted thread
					notEmptySignalCount++;
					throw new KCBPException(506, "interrupt", ie);
				} finally {
					notEmptyWaitThreadCount--;
				}

				if (poolingCount == 0) {
					if (estimate > 0) {
						continue;
					}

					if (createError != null) {
						throw new KCBPException(510, "create connection error",
								createError);
					} else {
						throw new KCBPException(508, "loopWaitCount " + i
								+ ", wait millis " + (nanos - estimate)
								/ (1000 * 1000));
					}
				}
			}

			poolingCount--;
			Connection last = connections[poolingCount];
			connections[poolingCount] = null;

			return last;
		}
	}

	public class GenKCBPClientThread extends Thread {

		public GenKCBPClientThread(String name) {
			super(name);
			this.setDaemon(true);
		}

		public void run() {
			initedLatch.countDown();

			int errorCount = 0;
			for (;;) {
				// addLast
				try {
					lock.lockInterruptibly();
				} catch (InterruptedException e2) {
					break;
				}

				try {
					// ��������̵߳ȴ����Ŵ�������
					if (poolingCount >= notEmptyWaitThreadCount) {
						empty.await();
					}

					// ��ֹ��������maxActive����������
					if (activeCount + poolingCount >= maxActive) {
						empty.await();
						continue;
					}

				} catch (InterruptedException e) {
					logger.info("create connection wait interrupted", e);
					// lastCreateError = e;
					// lastErrorTimeMillis = System.currentTimeMillis();
					break;
				} finally {
					lock.unlock();
				}

				Connection connection = null;

				try {
					connection = createKCBPConnection();
					if (connection == null || connection.getClient() == null) {
						errorCount++;
					}
				} catch (KCBPException e) {
					e.printStackTrace();
					errorCount++;
					createError = e;
				}

				if (connection == null) {
					continue;
				}

				lock.lock();
				try {
					connections[poolingCount++] = connection;

					if (poolingCount > poolingPeak) {
						poolingPeak = poolingCount;
						poolingPeakTime = System.currentTimeMillis();
					}

					errorCount = 0; // reset errorCount

					notEmpty.signal();
					notEmptySignalCount++;
				} finally {
					lock.unlock();
				}
			}
		}
	}

	private Connection createKCBPConnection() throws KCBPException {
		context.fire(KCBPEvent.BEFOREFCONNECTCREATOR);
		KCBPConnection connection = new KCBPConnection(server.getOption(),
				server.getServerName(), server.getUser(), server.getPassword());
		context.setConnection(connection);
		if (connection.client == null) {
			createErrorCount++;
			context.fire(KCBPEvent.CONNECTCREATORERROR);
			throw new KCBPException(connection.getRetcode(),
					"connection creator error:" + server.toString());
		}
		context.fire(KCBPEvent.AFTERCONNECTCREATOR);
		return connection;
	}

	public boolean isBusy() {
		lock.lock();
		try {
			return this.inited && this.activeCount == maxActive
					&& this.poolingCount == 0;
		} finally {
			lock.unlock();
		}
	}

	public void shrink() {
		shrink(false);
	}

	public void shrink(boolean checkTime) {
		final List evictList = new ArrayList();
		try {
			lock.lockInterruptibly();
		} catch (InterruptedException e) {
			return;
		}

		try {
			final int checkCount = poolingCount - minIdle;
			for (int i = 0; i < checkCount; ++i) {
				Connection connection = connections[i];

				if (checkTime) {
					long idleMillis = System.currentTimeMillis()
							- connection.getLastActiveTimeMillis();
					if (idleMillis >= minEvictableIdleTimeMillis) {
						evictList.add(connection);
					} else {
						break;
					}
				} else {
					evictList.add(connection);
				}
			}

			int removeCount = evictList.size();
			if (removeCount > 0) {
				System.arraycopy(connections, removeCount, connections, 0,
						poolingCount - removeCount);
				Arrays.fill(connections, poolingCount - removeCount,
						poolingCount, null);
				poolingCount -= removeCount;
			}
		} finally {
			lock.unlock();
		}

		// Connection
		int i = 0;
		for (i = 0; i < evictList.size(); i++) {
			connClose((Connection) evictList.get(i));
		}
		// for (Connection connection : evictList) {
		// connClose(connection);
		// }
	}

	private void connClose(Connection connection) {
		connection.close();
		destroyCount.incrementAndGet();
		try {
			if (context != null) {
				context.setConnection(connection);
				context.fire(KCBPEvent.CLOSECONNECT);
			}
		} catch (KCBPException e) {
			logger.error("close error", e);
			// e.printStackTrace();
		}
	}

	public class DestoryKCBPClientThread extends Thread {

		public DestoryKCBPClientThread(String name) {
			super(name);
			this.setDaemon(true);
		}

		public void run() {
			initedLatch.countDown();

			for (;;) {
				// ��ǰ�濪ʼɾ��
				try {
					if (closed) {
						break;
					}

					Thread.sleep(1000);

					if (Thread.interrupted()) {
						break;
					}

					shrink(true);

				} catch (InterruptedException e) {
					break;
				}
			}
		}

	}
}