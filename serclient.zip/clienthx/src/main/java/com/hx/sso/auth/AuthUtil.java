package com.hx.sso.auth;

import java.util.Map;
import java.util.StringTokenizer;
import javax.servlet.http.HttpServletRequest;
import org.apache.log4j.Logger;
import rewin.transaction.HXTradeSender;
import rewin.transaction.NetTrade;

import com.hx.kcbpcall.KCBPExecute;
import com.hx.kcbpcall.vo.Operator;
import com.hx.kcbpcall.vo.ParamVO;
import com.hx.kcbpcall.vo.ResultVO;
import com.hx.sso.util.MD5;
import com.hx.util.KDEncode;
import com.hx.web.mvc.Constants;
import com.hx.web.mvc.RequestContext;
import com.hx.web.mvc.util.UrlHelper;

public class AuthUtil {
	private static Logger log = Logger.getLogger(AuthUtil.class);
	private static HXTradeSender netTrade = new HXTradeSender();
	private static final String NET_TEST_INFO = "Rewin-ECSN";
	private static final char DIV = ',';
	private static final String REQ_NULL = " ";
	public static final String SERVICEACCTTYPE = "F";
	public static final String PRACTICEACCTTYPE = "T";
	public static final String CUSTMANAGEACCTTYPE = "K";
	
	/**
	 * �����˺�У��TOKEN
	 * @param request
	 * @param operator
	 * @param accttype
	 * @param token
	 * @return
	 */
	public static ResultVO serviceTokenQuery(HttpServletRequest request,
			String username,String accttype,String token) {
		ResultVO result = null;
		RequestContext requestContext = new RequestContext(request);
		ParamVO inVo = new ParamVO();
		inVo.put("funcId", "1002466");
		inVo.put("serviceacct", username);
		inVo.put("token", token);
		result = KCBPExecute.instance.execute(requestContext,inVo);
		return result;
	}
	/**
	 * �����˺�У��token
	 * @param request
	 * @param operator
	 * @param accttype
	 * @param token
	 * @return
	 */
	public static ResultVO practiceTokenQuery(HttpServletRequest request,
			String username,String accttype,String token) {
		RequestContext requestContext = new RequestContext(request);
		ResultVO result = null;
		ParamVO inVo = new ParamVO();
		inVo.put("funcId", "1002017");
		inVo.put("funcid", "1002017");
		inVo.put("custid", username);
		inVo.put("custorgid", "9988");
		inVo.put("netaddr", " ");
		inVo.put("orgid", "9988");
		inVo.put("operway", "c");
		inVo.put("ext", "0");
		inVo.put("trdpwd", " ");
		inVo.put("token", token);
		result = KCBPExecute.instance.execute(requestContext,inVo);
		return result;
	}
	/**
	 * ��֤�����˺�
	 * @param request
	 * @param operator
	 * @param accttype
	 * @return
	 */
	public static ResultVO authService(HttpServletRequest request,
			String username, String password,String accttype) {
		RequestContext requestContext = new RequestContext(request);
		String encrypassword = KDEncode.getInstance().encode("1002001",password);
		ResultVO result = null;
		ParamVO inVo = new ParamVO();
		inVo.put("funcId", "1002001");
		inVo.put("funcid", "1002001");
		inVo.put("custid", "0");
		inVo.put("custorgid", "0");
		inVo.put("netaddr", " ");
		inVo.put("orgid", "0");
		inVo.put("operway", " ");
		inVo.put("ext", "0");
		inVo.put("inputid", username);
		inVo.put("inputtype", "s");
		inVo.put("trdpwd", encrypassword);
		inVo.put("newtoken", "1");
		result = KCBPExecute.instance.execute(requestContext,inVo);
		return result;
	}
	
	/**
	 * ��֤�����˺�
	 * @param request
	 * @param operator
	 * @param accttype
	 * @return
	 */
	public static ResultVO authPractice(HttpServletRequest request,
			String username, String password,String accttype) {
		RequestContext requestContext = new RequestContext(request);
		String encrypassword = KDEncode.getInstance().encode("1002001",password);
		ResultVO result = null;
		ParamVO inVo = new ParamVO();
		inVo.put("funcId", "1002001");
		inVo.put("funcid", "1002001");
		inVo.put("custid", username);
		inVo.put("custorgid", "9988");
		inVo.put("netaddr", " ");
		inVo.put("orgid", "9988");
		inVo.put("operway", "c");
		inVo.put("ext", "0");
		inVo.put("inputid", username);
		inVo.put("inputtype", "Z");
		inVo.put("trdpwd", encrypassword);
		inVo.put("newtoken", "1");
		result = KCBPExecute.instance.execute(requestContext,inVo);
		return result;
	}
	/**
	 * ��֤�ͻ���������
	 * add by zhangtao on 2011-12-08
	 * @param request
	 * @param operator
	 * @param accttype
	 * @return
	 */
	public static ResultVO authCustManager(HttpServletRequest request,
			String username, String password,String accttype) {
		RequestContext requestContext = new RequestContext(request);
		ResultVO result = null;
		
		// ͨ��crm�Ŀͻ�������ʽ��֤Ȩ��
		ParamVO vo = new ParamVO();
		vo.put(Constants.ID, "98010001");
		vo.put(Operator.GYBH, "");
		vo.put(Operator.GNBH, "98010001");
		vo.put(Operator.GYMM, "");
		vo.put(Operator.CZZD, "");
		vo.put(Operator.KZCS, "");
		vo.put(Operator.FZDM, "");
		vo.put("authtype", "C");
		vo.put("khjlh", username);
		result = KCBPExecute.instance.execute(requestContext,vo);
		return result;
	}
	/**
	 * ��֤�ʽ��˺�
	 * @param request
	 * @param operator
	 * @param accttype
	 * @return
	 */
	public static ResultVO authCapitalAccount(HttpServletRequest request,
			String username, String password,String orgid,String accttype) {
		ResultVO result = new ResultVO();
		String accttype_inner;
		String marketcode;
		if("0".equals(accttype)) {
			accttype_inner = "0";
			marketcode = "0";
		} else {
			accttype_inner = "0";
			marketcode = accttype;
		}
		String requestinfo = NET_TEST_INFO + DIV 
    	+ password + DIV 
    	+ "2.05" + DIV 
    	+ "R" + DIV 
    	+ "9" + DIV 
    	+ orgid + DIV 
    	+ REQ_NULL + DIV 
    	+ "113" + DIV 
    	+ "127.0.0.1" + DIV 
    	+ REQ_NULL + DIV 
    	+ marketcode + DIV 
    	+ accttype_inner + DIV 
    	+ username + DIV 
    	+ password + DIV 
    	+ REQ_NULL + DIV 
    	+ REQ_NULL + DIV 
    	+ REQ_NULL;
		String response = netTrade.submit(orgid, 113, 1, "", "", requestinfo);
		StringTokenizer tokens = new StringTokenizer(response,
		            "" + NetTrade.DIV, false);
		result.setRscode(tokens.nextToken());
		result.setMessage(tokens.nextToken());
		return result;
	}
	
}
