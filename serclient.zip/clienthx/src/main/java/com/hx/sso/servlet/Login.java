package com.hx.sso.servlet;

import java.io.*;
import java.util.Map;

import javax.servlet.*;
import javax.servlet.http.*;

import com.hx.sso.auth.*;
import com.hx.sso.ticket.*;
import com.hx.util.CommonUtil;

public class Login extends HttpServlet {
	private static final int GRANTING_TIMEOUT_DEFAULT = 8 * 60 * 60;
	private static final int SERVICE_TIMEOUT_DEFAULT = 5 * 60;

	private static final String TGC_ID = "HXTGC";

	private static final String SERVICE = "service";
	private static final String RENEW = "renew";
	private static final String GATEWAY = "gateway";

	private GrantorCache tgcCache;
	private ServiceTicketCache stCache;
	private DefaultAuthHandler handler;
	private String loginForm, genericSuccess, serviceSuccess, confirmService,
			redirect;
	private ServletContext app;

	public void init() throws ServletException {
		app = getServletContext();
		// tgcCache = (GrantorCache) app.getAttribute("tgcCache");
		// stCache = (ServiceTicketCache) app.getAttribute("stCache");
		initCache();
		try {
			// ��֤Ȩ�޽ӿ�ʵ����
			String handlerName = getInitParameter("com.hx.sso.authHandler");
			if (handlerName == null)
				handler = new DefaultAuthHandler();
			else
				handler = (DefaultAuthHandler) Class.forName(handlerName)
						.newInstance();
		} catch (InstantiationException ex) {
			throw new ServletException(ex.toString());
		} catch (ClassNotFoundException ex) {
			throw new ServletException(ex.toString());
		} catch (IllegalAccessException ex) {
			throw new ServletException(ex.toString());
		}

		loginForm = getInitParameter("com.hx.sso.loginForm");
		if (loginForm == null)
			loginForm = "/sso/login.jsp";
		// ��Ҫ��תӦ�õ�url
		serviceSuccess = getInitParameter("com.hx.sso.serviceSuccess");
		if (serviceSuccess == null)
			serviceSuccess = "/sso/success.jsp?goserver=true";
		// û����ת������Ӧ�ã�Ĭ��url
		genericSuccess = getInitParameter("com.hx.sso.genericSuccess");
		if (genericSuccess == null)
			genericSuccess = "/sso/success.jsp";
		// �ض���url
		redirect = getInitParameter("com.hx.sso.redirect");
		if (redirect == null)
			redirect = "/sso/redirect.jsp";
	}

	private void initCache() {
		String grantingTimeoutString = getInitParameter("com.hx.sso.grantingTimeout");
		String serviceTimeoutString = getInitParameter("com.hx.sso.serviceTimeout");
		int grantingTimeout, serviceTimeout;
		try {
			grantingTimeout = Integer.parseInt(grantingTimeoutString);
		} catch (NumberFormatException ex) {
			grantingTimeout = GRANTING_TIMEOUT_DEFAULT;
		} catch (NullPointerException ex) {
			grantingTimeout = GRANTING_TIMEOUT_DEFAULT;
		}
		try {
			serviceTimeout = Integer.parseInt(serviceTimeoutString);
		} catch (NumberFormatException ex) {
			serviceTimeout = SERVICE_TIMEOUT_DEFAULT;
		} catch (NullPointerException ex) {
			serviceTimeout = SERVICE_TIMEOUT_DEFAULT;
		}

		tgcCache = new GrantorCache(TicketGrantingTicket.class, grantingTimeout);
		stCache = new ServiceTicketCache(ServiceTicket.class, serviceTimeout);

		app.setAttribute("tgcCache", tgcCache);
		app.setAttribute("stCache", stCache);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("GBK");
		response.setContentType("text/html; charset=GBK");
		response.setHeader("pragma", "no-cache");
		response.setHeader("Cache-Control", "no-cache");
		response.setHeader("Cache-Control", "no-store");
		response.setDateHeader("Expires", 0);
		String tgc = null;
		// ����Ƿ�����Ȩticket
		Cookie[] cookies = request.getCookies();
		if (cookies != null) {
			for (int i = 0; i < cookies.length; i++) {
				if (cookies[i].getName().equals(TGC_ID)) {
					tgc = cookies[i].getValue();
				}
			}
		}

		try {
			// request.getHeaders("Authorization");
			if (tgc != null) {
				TicketGrantingTicket t = (TicketGrantingTicket) tgcCache
						.getTicket(tgc);
				if (t != null) {
					grantForService(request, response, t, request
							.getParameter(SERVICE), false);
					return;
				}
			}

			String hxtoken = request.getParameter("tgctoken");
			if (hxtoken != null && !"".equals(hxtoken)) {
				TicketGrantingTicket t = (TicketGrantingTicket) tgcCache
						.getTicket(hxtoken);
				if (t != null) {
					grantForService(request, response, t, request
							.getParameter(SERVICE), false);
					return;
				}
			}
		} catch (TicketException e) {
			throw new IOException(e.toString());
		}

		String token = request.getParameter("token");
		String custid = request.getParameter("custid");
		String acctype = request.getParameter("acctype");
		String orgid = request.getParameter("orgid");
		String passtype = request.getParameter("passtype");// 0 �������� 1 ��������

		String uname = request.getParameter("nameUsername");
		String sRand = (String) request.getSession().getAttribute("rand");

		if (CommonUtil.isEmpty(acctype))
			acctype = "0";
		else
			request.setAttribute("acctype", acctype);
		if (!CommonUtil.isEmpty(custid)){
			if ("0".equals(acctype)){//����12λ
				while(custid.length()<12)
					custid = "0" + custid;
			}
			uname = custid;
		}

		request.setAttribute("passtype", passtype);
		request.setAttribute("username", uname);
		request.setAttribute("loginuser", uname);
		if (request.getParameter("nameYyb") != null)
			request.setAttribute("nameYyb", request.getParameter("nameYyb"));

		request.getSession().removeAttribute("rand");
		if (request.getParameter("nameRandom") != null && sRand != null
				&& !sRand.equals(request.getParameter("nameRandom"))) {
			request.setAttribute("errormessage", "��֤�����벻��ȷ��");
			request.setAttribute("authError", "true");
			app.getRequestDispatcher(loginForm).forward(request, response);
			return;
		}

		String upass = request.getParameter("namePassword");
		if ("0".equals(passtype)) {
			upass = request.getParameter("fwPassword");
		}

		if (!CommonUtil.isEmpty(token)&&CommonUtil.isEmpty(upass))
			upass = token;
		request.setAttribute("username", uname);
		request.setAttribute("loginuser", uname);

		if (!CommonUtil.isEmpty(uname)) {
			if (CommonUtil.isEmpty(upass)) {
				request.setAttribute("errormessage", "���� ����Ϊ�գ�");
			} else {
				if (handler.authenticate(request, uname, upass)) {
					// ����ɹ�������tgc
					String loginuser = (String) request
							.getAttribute("username");
					TicketGrantingTicket t = sendTgc(loginuser, acctype,
							request, response);

					grantForService(request, response, t, request
							.getParameter(SERVICE), true);
					return;
				} else {
					request.setAttribute("authError", "true");
				}
			}
		}

		request.setAttribute("com.hx.sso.service", request
				.getParameter(SERVICE));
		if ("clientlogin".equals(request.getParameter(SERVICE))) {
			PrintWriter out = response.getWriter();
			clientFailure(out, (String) request.getAttribute("errormessage"));
		} else {
			// ����¼ҳ��
			app.getRequestDispatcher(loginForm).forward(request, response);
		}
	}

	protected void clientFailure(PrintWriter out, String errorMessage)
			throws IOException {
		out.println("<?xml version=\"1.0\" encoding=\"GBK\"?>");
		out.println("<serviceResponse>");
		out.println("  <authenticationFailure>");
		out.println("    " + errorMessage);
		out.println("  </authenticationFailure>");
		out.println("</serviceResponse>");
	}

	/**
	 * ��ת������
	 */
	private void grantForService(HttpServletRequest request,
			HttpServletResponse response, TicketGrantingTicket t,
			String serviceId, boolean first) throws ServletException,
			IOException {
		try {
			PrintWriter out = response.getWriter();
			if (serviceId != null) {
				ServiceTicket st = new ServiceTicket(t, serviceId);
				String token = stCache.addTicket(st);
				request.setAttribute("serviceId", serviceId);
				request.setAttribute("sttoken", token);
				app.getRequestDispatcher(serviceSuccess).forward(request,
						response);
			} else
				app.getRequestDispatcher(genericSuccess).forward(request,
						response);
		} catch (TicketException ex) {
			throw new ServletException(ex.toString());
		}
	}

	private TicketGrantingTicket sendTgc(String username, String acctype,
			HttpServletRequest request, HttpServletResponse response)
			throws ServletException {
		try {
			Map extinfo = (Map) request.getAttribute("extinfo");
			TicketGrantingTicket t = new TicketGrantingTicket(username,
					acctype, extinfo);
			String token = tgcCache.addTicket(t);
			Cookie tgc = new Cookie(TGC_ID, token);
			if ("https".equals(request.getProtocol()))
				tgc.setSecure(true);
			tgc.setMaxAge(-1);
			// tgc.setDomain(request.getServerName());
			tgc.setPath("/");// request.getContextPath()
			response.addCookie(tgc);
			request.setAttribute(TGC_ID, token);
			return t;
		} catch (TicketException ex) {
			throw new ServletException(ex.toString());
		}
	}
}
