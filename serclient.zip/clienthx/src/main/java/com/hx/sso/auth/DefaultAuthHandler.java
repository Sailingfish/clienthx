package com.hx.sso.auth;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.hx.kcbpcall.KCBPExecute;
import com.hx.kcbpcall.vo.Operator;
import com.hx.kcbpcall.vo.ParamVO;
import com.hx.kcbpcall.vo.ResultVO;
import com.hx.sso.util.MD5;
import com.hx.util.CommonUtil;
import com.hx.web.mvc.Constants;
import com.hx.web.mvc.RequestContext;
import com.hx.web.mvc.util.LoginUtil;

public class DefaultAuthHandler {

	/*
	 * 406 ����brokerstatus 407 ���� 408 ��ְ 4254 ���� 4256 ��ְ�� 3234 1 ����
	 * UserBase.status 3235 2 ��ɾ�� UserBase.status 4106 3 ��ְ UserBase.status 4255
	 * 4 ���� UserBase.status 4257 5 ��ְ�� UserBase.status
	 * 
	 * 
	 * 406 1 ���� BrokerBase.status 407 2 ���� BrokerBase.status 408 3 ��ְ
	 * BrokerBase.status 4254 4 ���� BrokerBase.status 4256 5 ��ְ��
	 * BrokerBase.status
	 */
	public boolean authenticate(HttpServletRequest request, String username,
			String password) {
		if (CommonUtil.isEmpty(username)) {
			request.setAttribute("errormessage", "�������ʺ���Ϣ��");
			return false;
		}

		String token = request.getParameter("token");
		String acctype = request.getParameter("acctype");
		String orgid = request.getParameter("orgid");
		if (CommonUtil.isEmpty(orgid)) {
			orgid = request.getParameter("nameYyb");
		}

		if (orgid != null && !"".equals(orgid)) {
			while (orgid.length() < 4)
				// ����4λ
				orgid = "0" + orgid;
		}

		if ((CommonUtil.isEmpty(orgid)) && username.length() > 4) {
			orgid = username.substring(0, 4);
		}
		request.setAttribute("nameYyb", orgid);
		RequestContext requestContext = new RequestContext(request);
		Operator operator = new Operator();
		requestContext.setOperator(operator);
		if (!CommonUtil.isEmpty(password)) {
			operator.setGymm(password);
		}
		String jspass = request.getParameter("namePassword");
		if (!CommonUtil.isEmpty(token)&&CommonUtil.isEmpty(jspass)) {// tokenУ�鷽ʽ
			ResultVO result = null;
			operator.setToken(token);
			if (AuthUtil.SERVICEACCTTYPE.equals(acctype))
				result = AuthUtil.serviceTokenQuery(request, username, acctype,
						token);
			else if (AuthUtil.PRACTICEACCTTYPE.equals(acctype))
				result = AuthUtil.practiceTokenQuery(request, username,
						acctype, token);
			else {
				operator.setYybbh(orgid);
				operator.setZjhm(username);
				result = LoginUtil.tokenQuery(request, operator, token);
				operator.setGymm("");
			}
			if (result == null) {
				request.setAttribute("errormessage", "��֤ʧ��");
				return false;
			}
			if (!"0".equals(result.getRscode())) {// У��ʧ��
				request.setAttribute("errormessage", result.getMessage());
				return false;
			}
		} else {// �û�������У��
			ResultVO result = null;
			if (AuthUtil.SERVICEACCTTYPE.equals(acctype))
				result = AuthUtil.authService(request, username, password,
						acctype);
			else if (AuthUtil.PRACTICEACCTTYPE.equals(acctype))
				result = AuthUtil.authPractice(request, username, password,
						acctype);
			// add by zhangtao on 2011-12-12
			else if (AuthUtil.CUSTMANAGEACCTTYPE.equals(acctype))
				result = AuthUtil.authCustManager(request, username, password,
						acctype);
			else
				result = AuthUtil.authCapitalAccount(request, username,
						password, orgid, acctype);
			if (AuthUtil.CUSTMANAGEACCTTYPE.equals(acctype)) {
				Map map = result.getFirstData();
				if (map == null) {
					request.setAttribute("errormessage", result.getMessage());
					return false;
				}
				String status = (String) map.get("status_flag");
				if ("3234".equals(status)) {
					String pass = (String) map.get("password");
					if (!pass.equals(MD5.digest(password))) {
						request.setAttribute("errormessage", "�û�������󣬲��ܵ�½��");
						return false;
					}
				} else {
					String error = null;
					if ("4106".equals(status))// 4106 3 ��ְ
						error = "Ա������ְ�����ɵ�½";
					else if ("4263".equals(status))
						error = "�˺��Ѷ��ᣬ���ɵ�½";
					else if ("4263".equals(status))
						error = "�˺���ְ�У����ɵ�½";
					else
						error = "��½�ʺŲ����ڣ�";
					request.setAttribute("errormessage", error);
					return false;
				}

				return bulidExtinfoNull(requestContext, username, password);
			} else {
				if (result == null) {
					request.setAttribute("errormessage", "��֤ʧ��");
					return false;
				}
				if (!"0".equals(result.getRscode())) {// У��ʧ��
					request.setAttribute("errormessage", result.getMessage());
					return false;
				}
			}
		}
		return bulidExtinfo(requestContext, username, acctype, orgid, token);
	}

	private boolean bulidExtinfo(RequestContext requestContext, String custid,
			String acctype, String orgid, String token) {
		Operator operator = requestContext.getOperator();
		ResultVO resultVo;
		ParamVO vo = new ParamVO();
		vo.put(Constants.ID, "12400801");
		requestContext.getParameterMap().put(Constants.ID, "12400801");
		if (AuthUtil.SERVICEACCTTYPE.equals(acctype)) {
			ParamVO inVo = new ParamVO();
			inVo.put("funcId", "1002465");
			inVo.put("serviceacct", custid);
			resultVo = KCBPExecute.instance.execute(requestContext, inVo);
			vo.put("zjhm", ((Map) resultVo.getResults().get(0)).get("custid"));
			vo.put("authtype", "C");
		} else {
			if (acctype!=null&&"C".equals(acctype.toUpperCase())) {
				vo.put("authtype", "C");
			} else
				vo.put("authtype", "Z");
			vo.put("zjhm", custid);
		}
		vo.put("authtoken", token);
		resultVo = KCBPExecute.instance.execute(requestContext, vo, false);
		if (resultVo.getResults().size() < 1) {
			requestContext.getRequest().setAttribute("errormessage",
					resultVo.getMessage());
			return false;
		}
		Map map = (Map) resultVo.getFirstData();
		operator.setZjhm((String) map.get("zjzh"));
		if (!CommonUtil.isEmpty(operator.getToken()))
			map.put("token", operator.getToken());
		if (!CommonUtil.isEmpty(operator.getGymm()))
			map.put("key", CommonUtil.encode(operator.getZjhm(), operator
					.getGymm()));
		requestContext.getRequest().setAttribute("extinfo", map);
		return true;
	}

	private boolean bulidExtinfoNull(RequestContext requestContext,
			String custid, String password) {
		Operator operator = requestContext.getOperator();
		operator.setZjhm(custid);
		Map map = new HashMap();
		map.put("token", "");
		map.put("key", CommonUtil.encode(custid, password));
		requestContext.getRequest().setAttribute("extinfo", map);
		return true;
	}
}
