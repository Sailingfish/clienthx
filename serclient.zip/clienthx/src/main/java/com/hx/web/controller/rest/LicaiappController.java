package com.hx.web.controller.rest;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.hx.kcbpcall.KCBPExecute;
import com.hx.kcbpcall.util.ParamUtils;
import com.hx.kcbpcall.vo.Operator;
import com.hx.kcbpcall.vo.ParamVO;
import com.hx.kcbpcall.vo.ResultVO;
import com.hx.util.CommonUtil;
import com.hx.web.mvc.Constants;
import com.hx.web.mvc.RequestContext;
import com.hx.web.mvc.SingletonController;
import com.hx.web.mvc.route.Route;
import com.hx.web.mvc.view.FtlView;
import com.hx.web.mvc.view.JsonView;
import com.hx.web.mvc.view.JspView;
import com.hx.web.mvc.view.View;



public class LicaiappController extends SingletonController {

	/*
	 *  ��ȡ ����app ��Ϣ
	 *  http://${apiserver}/rest/json/licaiapp/getnew/param/licaiapptype/1/id/1
	 *  ����jsonЭ�������  
	 */
	public Object getnew(RequestContext requestContext) throws Exception {
		String licaiapptype = (String) requestContext.getParameter("licaiapptype");// ��ȡ�ͻ���
		if (CommonUtil.isEmpty(licaiapptype)) {
			return error("licaiapptype Ϊ�ա�");
		}
		String id = (String) requestContext.getParameter("id");// ��ȡ�ͻ���
		if (id==null || "".equals(id)) {
			id="-1";
		}
		
		ParamVO vo = new ParamVO();
		vo.put(Constants.ID, "98020401");
		vo.put("licaiapptype", licaiapptype);
		vo.put("id", id);
		vo.put("operstate", "Q");
		vo.put("isPerPage", "false");
		Operator operator = requestContext.getOperator();
		if (operator == null) {
			operator = new Operator();
			operator.setGybh("1");
			requestContext.setOperator(operator);
		}
		ResultVO resultVo = KCBPExecute.instance.execute(requestContext, vo);
		Route route = requestContext.getRoute();
		String rsType = requestContext.getParameter(Constants.RSTYPE);
		if(rsType==null || "".equals(rsType)){
			rsType="json";
		}
		return bulidview(requestContext, resultVo, rsType);
	}
	
	
	
	private Object bulidview(RequestContext requestContext, ResultVO resultVo,
			String rsType) {
		if ("jsp".equals(rsType)) {
			JspView jv = new JspView();
			jv.setPath(requestContext.getParameter(Constants.FORWARD));
			return jv;
		} else if ("json".equals(rsType)) {
			JsonView jsonView = new JsonView(resultVo);
			return jsonView;
		} else if ("xml".equals(rsType)) {
			FtlView v = new FtlView();
			String path = requestContext.getParameter(Constants.FORWARD);
			if (path == null || "".equals(path))
				path = "xmldata"; // ȷʵxmlģ��
			v.setPath(path);
			return v;
		} else {
			return error("��֧�����͡�");
		}
	}
	
	public Object error(String error) {
		return null;
	}
}
