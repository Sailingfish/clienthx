package com.hx.web.controller.rest;

import com.hx.kcbpcall.KCBPExecute;
import com.hx.kcbpcall.vo.Operator;
import com.hx.kcbpcall.vo.ParamVO;
import com.hx.kcbpcall.vo.ResultVO;
import com.hx.util.CommonUtil;
import com.hx.web.mvc.Constants;
import com.hx.web.mvc.RequestContext;
import com.hx.web.mvc.SingletonController;
import com.hx.web.mvc.route.Route;
import com.hx.web.mvc.view.FtlView;
import com.hx.web.mvc.view.JsonView;
import com.hx.web.mvc.view.JspView;

/*
 * �����ͻ�������Ϣ�ӿ�
 */
public class JfclController extends SingletonController {
	//��ȡ�ͻ��Ļ�������
	public Object view(RequestContext requestContext) throws Exception {
		String custid = (String) requestContext.getParameter(Constants.ID);// ��ȡ�ͻ���
		if (CommonUtil.isEmpty(custid)) {
			return error("û�пͻ���Ϣ��");
		}
		ParamVO vo = new ParamVO();
		vo.put(Constants.ID, "91020008");
		requestContext.getParameterMap().put(Constants.ID, "91020008");
		vo.put("operatetype", "Q");
		vo.put("balancevalue", custid);
		buildOperator(requestContext);
		ResultVO resultVo = KCBPExecute.instance.execute(requestContext, vo);

		Route route = requestContext.getRoute();
		String rsType = requestContext.getParameter(Constants.RSTYPE);

		bulidModel(requestContext, resultVo);

		return bulidview(requestContext, resultVo, rsType);
	}
	//�齱�ۼ�����
	public Object deduction1 (RequestContext requestContext) throws Exception {
		String custid = (String) requestContext.getParameter(Constants.ID);// ��ȡ�ͻ���
		if (CommonUtil.isEmpty(custid)) {
			return error("û�пͻ���Ϣ��");
		}
		ParamVO vo = new ParamVO();
		vo.put(Constants.ID, "91020008");
		requestContext.getParameterMap().put(Constants.ID, "91020008");
		vo.put("operatetype", "C");
		vo.put("balancevalue", custid);
		buildOperator(requestContext);
		ResultVO resultVo = KCBPExecute.instance.execute(requestContext, vo);

		Route route = requestContext.getRoute();
		String rsType = requestContext.getParameter(Constants.RSTYPE);

		bulidModel(requestContext, resultVo);

		return bulidview(requestContext, resultVo, rsType);
	}
	//���¿ۼ�����
	public Object deduction2 (RequestContext requestContext) throws Exception {
		String custid = (String) requestContext.getParameter(Constants.ID);// ��ȡ�ͻ���
		if (CommonUtil.isEmpty(custid)) {
			return error("û�пͻ���Ϣ��");
		}
		ParamVO vo = new ParamVO();
		vo.put(Constants.ID, "91020008");
		requestContext.getParameterMap().put(Constants.ID, "91020008");
		vo.put("operatetype", "J");
		vo.put("balancevalue", custid);
		buildOperator(requestContext);
		ResultVO resultVo = KCBPExecute.instance.execute(requestContext, vo);

		Route route = requestContext.getRoute();
		String rsType = requestContext.getParameter(Constants.RSTYPE);

		bulidModel(requestContext, resultVo);

		return bulidview(requestContext, resultVo, rsType);
	}
	
	protected Operator buildOperator(RequestContext requestContext) {
		Operator operator = requestContext.getOperator();
		if (operator == null) {
			operator = new Operator();
			operator.setAcctype("U");// �ͻ� �ͻ�����
			operator.setGybh("1");
			requestContext.setOperator(operator);
		}
		return operator;
	}

	private Object bulidview(RequestContext requestContext, ResultVO resultVo,
			String rsType) {
		if ("jsp".equals(rsType)) {
			JspView jv = new JspView();
			jv.setPath(requestContext.getParameter(Constants.FORWARD));
			return jv;
		} else if ("json".equals(rsType)) {
			JsonView jsonView = new JsonView(resultVo);
			return jsonView;
		} else if ("xml".equals(rsType)) {
			FtlView v = new FtlView();
			String path = requestContext.getParameter(Constants.FORWARD);
			if (path == null || "".equals(path))
				path = "xmldata"; // ȷʵxmlģ��
			v.setPath(path);
			return v;
		} else {
			return error("��֧�����͡�");
		}
	}

	private void bulidModel(RequestContext requestContext, ResultVO resultVo) {
		String rsName = Constants.RESULT;
		if (requestContext.getParameter(Constants.RSNAME) != null
				&& !requestContext.getParameter(Constants.RSNAME).equals("")) {
			rsName = requestContext.getParameter(Constants.RSNAME);
		}
		requestContext.getRequest().setAttribute(Constants.RESULTVO, resultVo);// ���ر�׼��ʽ�Ľ�֤�ӿ�����
		requestContext.getRequest().setAttribute(rsName, resultVo.getResults());// ֻ���ؽ������
	}

	public Object error(String error) {
		return null;
	}
}
