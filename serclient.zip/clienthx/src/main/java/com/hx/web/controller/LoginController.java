package com.hx.web.controller;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.hx.kcbpcall.vo.Operator;
import com.hx.kcbpcall.vo.ParamVO;
import com.hx.kcbpcall.vo.ResultVO;
import com.hx.sso.ticket.ServiceTicket;
import com.hx.sso.ticket.ServiceTicketCache;
import com.hx.util.CommonUtil;
import com.hx.web.mvc.Constants;
import com.hx.web.mvc.RequestContext;
import com.hx.web.mvc.SingletonController;
import com.hx.web.mvc.util.LoginUtil;
import com.hx.web.mvc.util.UrlHelper;
import com.hx.web.mvc.view.JspView;

/*
 * ִ��ͨ��function���߼�����
 * ����·����/commFunc/ //commFunc/execute/12345678/view
 * testurl:http://10.33.4.51:9080/do?custid=160000000022&token=f475782d6c9fa8e9ba8129f2d6c59117937bb326271c51c7fc1dd2434748737b
 */
public class LoginController extends SingletonController {

	public JspView index(RequestContext requestContext) throws Exception {
		JspView v = new JspView();
		v.setPath("login");
		return v;
	}

	public JspView login(RequestContext requestContext) throws Exception {
		String username = requestContext.getParameter("username");
		String password = requestContext.getParameter("password");
		String token = requestContext.getParameter("token");
		String orgid = requestContext.getParameter("orgid");
		boolean loginOk = true;
		Operator operator = new Operator();
		operator.setGybh(username);
		operator.setGymm(password);

		ParamVO vo = new ParamVO();
		vo.put(Constants.ID, "12400801");
		vo.put("authtoken", password);
		ResultVO result = null;
		if (token != null && !"".equals(token.trim())) {
			if ((orgid == null || "".equals(orgid)) && username != null) {
				orgid = username.substring(0, 4);
			}
			operator.setGybh(username);
			operator.setYybbh(orgid);
			operator.setZjhm(username);
			operator.setGymm("");
			operator.setToken(token);
			result = LoginUtil.tokenQuery(requestContext.getRequest(),
					operator, token);
			if ("0".equals(result.getRscode()))
				result = LoginUtil
						.buildOperator(requestContext, operator, null);//û�в��������ѯ
		} else {
			result = LoginUtil.buildOperator(requestContext, operator, vo);
		}

		// 12400801
		// ��֤ʧ�ܣ����¶�λ
		if (!"0".equals(result.getRscode())) {
			requestContext.getRequest()
					.setAttribute(Constants.RESULTVO, result);
			requestContext.getRequest().setAttribute(Constants.ERRORMESSAGE,
					result.getMessage());
			requestContext.getRequest().setAttribute("username", username);
			requestContext.getRequest().setAttribute("authtoken", token);
			return index(requestContext);
		}
		HttpSession s = requestContext.getRequest().getSession();

		String path = (String) s.getAttribute(Constants.ORGILURL);
		if (path == null || path.indexOf("/do/login") > 0) {
			path = requestContext.getRequest().getContextPath() + "/do/";
		}
		JspView v = new JspView();
		v.setRedirect(true);
		v.setPath(path);
		s.removeAttribute(Constants.ORGILURL);
		if (token != null && !"".equals(token.trim())) {
			Cookie cookie = new Cookie("token", username + "|" + orgid + "|"
					+ token);
			// cookie.setMaxAge(12*3600);
			cookie.setPath("/");
			requestContext.getResponse().addCookie(cookie);
		}
		return v;
	}

	public JspView logout(RequestContext requestContext) throws Exception {
		HttpSession s = requestContext.getRequest().getSession();
		s.removeAttribute(Constants.OPERATOR);
		s.removeAttribute(Constants.ORGILURL);
		s.removeAttribute("tradeSession");
		s.removeAttribute("hasCheckAnswers");
		s.removeAttribute("agreeRisk");
		JspView v = new JspView();
		// requestContext.getRequest().setAttribute("action", "logout");
		v.setPath("login?action=logout");
		return v;
	}

	public JspView ssologin(RequestContext requestContext) throws Exception {
		HttpServletRequest req = requestContext.getRequest();
		HttpSession s = req.getSession();
		String path = (String) s.getAttribute(Constants.ORGILURL);
		String tgctoken = null;
		Cookie[] cookies = req.getCookies();
		Cookie cookie;
		if (cookies != null)
			for (int i = 0; i < cookies.length; ++i) {
				cookie = cookies[i];
				if ("HXTGC".equals(cookie.getName()))
					tgctoken = cookie.getValue();
			}

		if (CommonUtil.isEmpty(tgctoken)) {
			tgctoken = requestContext.getRequest().getParameter("tgctoken");
			if (!CommonUtil.isEmpty(tgctoken)) {
				// ����token��cookie,ҳ���ض���
				Cookie tgc = new Cookie("HXTGC", tgctoken);
				tgc.setMaxAge(-1);
				tgc.setPath("/");// request.getContextPath()
				requestContext.getResponse().addCookie(tgc);

				JspView v = new JspView();
				v.setRedirect(true);
				v.setPath(path);
				return v;
				// return ;
			}
		}
		// �����������token,��Ҫ��path����ת��
		// http://test?custid=990800000016&&orgid=9988token=668
		// c34ffb317dcbb24c009e154718e72469ac9e055caf9ef86567798287b8e04
		// &acctype=0
		// ��Ʒϵͳ��Ҫ����custid�ȼ������������ݵ�http:${server}/sso/login�����ǵ���¼�����������ӵ�ַΪ
		// http://${server}/sso/login?custid=990800000016&&orgid=9988token=668
		// c34ffb317dcbb24c009e154718e72469ac9e055caf9ef86567798287b8e04
		// &zhlx=0&service=http%3a%2f%2ftest%3a8090%2f

		String slogin = requestContext.getServletContext().getInitParameter(
				"ssologin");
		if (slogin == null)
			slogin = "https://www.hx168.com.cn/sso/login";
		StringBuffer buf = new StringBuffer(slogin);
		String token = req.getParameter("token");
		String custid = req.getParameter("custid");
		String acctype = req.getParameter("acctype");
		String orgid = req.getParameter("orgid");
		String operway = req.getParameter("operway");
		if (slogin.indexOf("?") < 0)
			buf.append("?");
		if (!CommonUtil.isEmpty(token)) {
			buf.append("token=").append(token);
			buf.append("&custid=").append(custid);
			buf.append("&tcheck=1");
			if (orgid != null)
				buf.append("&orgid=").append(orgid);
			if (acctype != null)
				buf.append("&acctype=").append(acctype);
			if (operway != null)
				buf.append("&operway=").append(operway);
			//?token=1234556
			String url=UrlHelper.getFullRequestUrl(req);
			if (url.indexOf("?token=")>=0){
				url=url.replaceFirst("[?]token=", "?otoken=");
			}else{
				url=url.replaceFirst("[&]token=", "&otoken=");
			}
			
			buf.append("&service="
					+ java.net.URLEncoder.encode(url,
							"GBK"));
		}else{
			buf.append("&service="
					+ java.net.URLEncoder.encode(UrlHelper.getFullRequestUrl(req),
							"GBK"));
		}

		
		JspView v = new JspView();
		v.setRedirect(true);
		v.setPath(buf.toString());
		return v;
	}

	public Object validate(RequestContext requestContext) throws Exception {
		HttpSession s = requestContext.getRequest().getSession();

		String path = (String) s.getAttribute(Constants.ORGILURL);
		String sttoken = requestContext.getParameter("sttoken");

		ServiceTicketCache stCache = (ServiceTicketCache) requestContext
				.getServletContext().getAttribute("stCache");

		ServiceTicket st = (ServiceTicket) stCache.getTicket(sttoken);
		Pattern pattern = Pattern.compile("sttoken[=]ST([^&])*");
		Matcher matcher = pattern.matcher(path);

		path = matcher.replaceFirst("");
		if (path.endsWith("?"))
			path = path.substring(0, path.length() - 1);

		s.setAttribute(Constants.ORGILURL, path);

		String username = st.getUsername();
		Operator operator = new Operator();
		operator.setGybh((String) st.getExtinfo().get("khbh"));
		operator.setAcctype(st.getAccType());
		Map map = (Map) st.getExtinfo();
		if (map != null) {
			try {
				operator.setCustid((String) map.get("custid"));
				operator.setZjhm((String) map.get("zjzh"));
				if (!CommonUtil.isEmpty(map.get("token")))
					operator.setToken((String) map.get("token"));
				if (!CommonUtil.isEmpty(map.get("key")))
					operator.setGymm(CommonUtil.decode(operator.getZjhm(),
							(String) map.get("key")));
			} catch (Exception ex) {
                 ex.printStackTrace();
			}
		}
		operator.setCzzd(requestContext.getRequest().getRemoteAddr());
		LoginUtil.buildOperator(requestContext, operator, null);
		return to(requestContext, operator);
	}

	private JspView to(RequestContext requestContext, Operator operator) {
		HttpSession s = requestContext.getRequest().getSession();
		s.setAttribute(Constants.OPERATOR, operator);
		String pre = (String) requestContext.getRequest().getAttribute(
				Constants.URLPATTERN);
		String path = (String) s.getAttribute(Constants.ORGILURL);
		if (path == null || path.indexOf(pre + "/login") > 0) {
			path = requestContext.getRequest().getContextPath() + pre;
		}
		JspView v = new JspView();
		v.setRedirect(true);
		v.setPath(path);
		s.removeAttribute(Constants.ORGILURL);
		return v;
	}
}
