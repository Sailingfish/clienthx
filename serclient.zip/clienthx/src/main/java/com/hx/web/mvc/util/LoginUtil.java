package com.hx.web.mvc.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import rewin.transaction.TradeSession;

import com.hx.kcbpcall.KCBPExecute;
import com.hx.kcbpcall.TradeExecute;
import com.hx.kcbpcall.vo.Level;
import com.hx.kcbpcall.vo.Operator;
import com.hx.kcbpcall.vo.ParamVO;
import com.hx.kcbpcall.vo.ResultVO;
import com.hx.util.Base64;
import com.hx.web.mvc.Constants;
import com.hx.web.mvc.RequestContext;
import com.hx.web.mvc.route.Route;

public class LoginUtil {
	private static Logger log = Logger.getLogger(LoginUtil.class);

	public static Operator fromTradeSession(TradeSession tradeSession) {
		if (tradeSession == null)
			return null;
		Operator operator = new Operator();
		operator.setGybh(tradeSession.getCustomerId());
		operator.setGymc(tradeSession.getAccountName());
		operator.setYybbh(tradeSession.getDeptID());
		operator.setZjhm(tradeSession.getAccount());
		operator.setCzzd(tradeSession.userCacheValue.userIP);
		return operator;
	}

	public static Operator fromTradeSession(HttpServletRequest request) {
		TradeSession tradeSession = (TradeSession) request.getSession()
				.getAttribute("tradeSession");
		return fromTradeSession(tradeSession);
	}

	public static ResultVO buildOperator(RequestContext requestContext,
			Operator operator, ParamVO vo) {// funcId,zjhm,authtoken,authtype:0
		if (operator == null)
			return null;
		if (vo == null) {
			vo = new ParamVO();
			// authtoken,authtype=1 token��֤��ʽ
			vo.put(Constants.ID, "12400801");// �ͻ���֤���ܺ�
			vo.put("zjhm", operator.getZjhm());
			String token = operator.getToken();
			if ("9988".equals(operator.getYybbh()) && token != null
					&& !"".equals(token)) {// ����ͻ�
				vo.put("authtype", "T");
				// operator.setKzcs(token);
				vo.put("authtoken", token);
			} else {
				vo.put("authtype", "Q");// authtype='Q'��ʱ��ֱ�Ӳ�ѯ�ͻ���
			}
		}

		requestContext.setOperator(operator);// kcxpִ��ʱ����ò�������
		ResultVO result = KCBPExecute.instance.execute(requestContext, vo);
		if (!"0".equals(result.getRscode())) {
			return result;
		}

		List datas = result.getResults();
		if (datas != null & datas.size() > 0) {
			Map data = (Map) datas.get(0);
			operator.setResult(data);
			operator.setGybh((String) data.get("khbh"));
			operator.setZjhm((String) data.get("khzzh"));
			operator.setGymc((String) data.get("khxm"));
			String yyb = (String) data.get("ywxtbh");
			operator.setYybbh(yyb);
			operator.setYybmc((String) data.get("yybmc"));
			String jb = (String) data.get("khjb");// data.get("kz_nkjb");
			if (jb == null || "".equals(jb.trim())) {
				operator.setLevel(Level.v0);
			} else {
				try {
					operator.setLevel(Level.getLevel(
							Integer.valueOf(jb.trim()), yyb));
				} catch (Exception e) {
					operator.setLevel(Level.v0);
				}
			}
			String jf0 = (String) data.get("balancevalue");
			if (jf0 != null && !"".equals(jf0)) {
				try {
					operator.setJf(Float.valueOf(jf0));
				} catch (Exception e) {

				}
			}
		} else {
			result.setMessage("�ͻ����ϲ�����");
			result.setRscode("-1");
			return result;
		}

		HttpSession s = requestContext.getRequest().getSession();
		s.setAttribute(Constants.OPERATOR, operator);
		// ���ÿͻ�������Ϣ

		try {
			ResultVO vo1 = queryRisk(operator);
			if (vo1 != null) {
				Map data = vo1.getFirstData();
				log.info(operator.getZjhm() + "=" + data);
				String status = (String) data.get("status");
				String holdtime = (String) data.get("holdtime");
				// log.info("holdtime:"+holdtime);
				if (holdtime != null && !"".equals(holdtime.trim())) {
					operator.setInvest(Integer.valueOf(holdtime).intValue());
				} else {
					operator.setInvest(-1);
				}
				String risklevel = (String) data.get("risklevel");
				log.info("holdtime:" + risklevel);
				if (risklevel != null && !"".equals(risklevel.trim())) {
					operator
							.setRinkLevel(Integer.valueOf(risklevel).intValue());
				}
				// status 0��������Ч��1��δ������2���������ڣ�
				if ("1".equals(status)) {
					operator.setRinkLevel(-1);
				}
				// log.info("status:"+status);
				// log.info("rinkname="+operator.getRinkName());
			}
			// operator.setRinkLevel(rinkLevel)
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public static boolean checkLogin(RequestContext requestContext) {
		return true;
	}

	public static ResultVO tokenQuery(HttpServletRequest request,
			Operator operator, String token) {
		ResultVO result = new ResultVO();
		String userIP = Constants.DEFAULTIP;
		// operator.setGymm("");
		if (request != null) {
			userIP = request.getRemoteAddr();
			operator.setCzzd(userIP);
		}
		if ("9988".equals(operator.getYybbh())) {
			result.setRscode("0");
			result.setMessage("");
			return result;
		}
		String acctype = request.getParameter("acctype");
		String operway = request.getParameter("operway");
		if (operway == null || "".equals(operway))
			operway = "c";
		if (acctype == null || "".equals(acctype))
			acctype = "Z";
		String content = TradeExecute.instance.wrapSubmitEx(operator, token
				+ Constants.COMDIV + operway + Constants.COMDIV + acctype
				+ Constants.COMDIV);
		// operator.getYybbh() + Constants.COMDIV
		// + operator.getZjhm() + Constants.COMDIV + operator.getGymm()
		// + Constants.COMDIV + userIP + Constants.COMDIV
		// + operator.getZjhm() + Constants.COMDIV + token
		// + Constants.COMDIV;

		String rs = TradeExecute.instance.submitEx(Constants.LOGINNO, content);
		// 21err_codeerr_msg0��ѯ�ɹ�
		if (rs == null) {
			result.setRscode("-1");
			result.setMessage("û�з��ؽ��");
			return result;
		}
		try {
			StringTokenizer tokens = new StringTokenizer(rs, "\001", false);
			String t1 = tokens.nextToken();// 2
			String t2 = tokens.nextToken();// 1
			String t3 = tokens.nextToken();// err_code
			String t4 = tokens.nextToken();// err_msg
			String err_code = tokens.nextToken();
			String err_msg = tokens.nextToken();
			// 21err_codeerr_msg-1002017001-1002017001�ͻ�������Ч
			// 21err_codeerr_msg0��ѯ�ɹ�!
			result.setRscode(err_code);
			result.setMessage(err_msg);
		} catch (Exception ex) {
			log.info("request error:" + content, ex);
			result.setRscode("-1");
			result.setMessage(ex.toString());
			return result;
		}
		return result;
	}

	public static ResultVO queryRisk(Operator operator) {
		if (operator == null)
			return null;
		return TradeExecute.instance.execute(operator, 32012, "");
	}

	/* ��ѯͶ���˷��ճ���������� */
	/*
	 * �жϿͻ��Ƿ��״�������Ʊ����ÿ����״Σ�����������Ʊ���� ���ؽ�� ����״̬ status char(1)
	 * 0��������Ч��1��δ������2���������ڣ�����Ч���������⣻3���ѹ���ʧЧ ���յȼ� risklevel char(1)
	 * status=0��2ʱ��Ч��1���ͷ��գ�2���з��գ�3���߷��ա�����statusʱΪ�� �ֹ����� holdtime char(1)
	 * 0:���ߣ�1�����ߣ�2������
	 */
	public static ResultVO queryRisk(TradeSession tradeSession) {
		if (tradeSession == null)
			return null;
		return TradeExecute.instance.execute(tradeSession, 32012, "");
	}

	public static boolean isRiskTest(TradeSession tradeSession) {
		ResultVO result = queryRisk(tradeSession);
		if (result == null)
			return true;
		Map data = result.getFirstData();
		if (data == null)
			return true;
		String status = (String) data.get("status");
		return "0".equals(status) || "2".equals(status);
		/*
		 * if (tradeSession == null) return true; String ans =
		 * netTrade.submitEx(32012, wrapSubmitEx(tradeSession, "")); try {
		 * FixParser fixRiskLevel = new FixParser(); fixRiskLevel.parse(ans);
		 * String retRiskLevel = fixRiskLevel.getFieldValue("risklevel", 0);
		 * fixRiskLevel.getFieldValue("status", 0);
		 * fixRiskLevel.getFieldValue("status", 0); return
		 * "1".equals(fixRiskLevel.getFieldValue("needrisk", 0));//0������Ҫ 1����Ҫ }
		 * catch (Exception e) { e.printStackTrace(); return true; }
		 */
	}

	public static String getRiskLevel(Operator operator) throws Exception {
		/* ��ѯͶ���˷��ճ���������� */
		if (operator == null)
			return null;
		int funcID = 30001;
		StringBuffer sbuf = new StringBuffer();
		sbuf.append(String.valueOf(operator.getZjhm()))
				.append(Constants.COMDIV);
		sbuf.append(String.valueOf(operator.getYybbh())).append(
				Constants.COMDIV);
		sbuf.append(String.valueOf(operator.getYybbh())).append(
				Constants.COMDIV);
		sbuf.append(String.valueOf("2")).append(Constants.COMDIV);
		ResultVO result = TradeExecute.instance.execute(operator, funcID, sbuf
				.toString());
		// String riskLevelAns = netTrade.submitEx(funcID, wrapSubmitEx(
		// tradeSession, sbuf.toString()));
		// FixParser fixRiskLevel = new FixParser();
		// fixRiskLevel.parse(riskLevelAns);
		// String retRiskLevel = fixRiskLevel.getFieldValue("risklevel", 0);
		if (result == null || result.getFirstData() == null)
			return null;
		return (String) result.getFirstData().get("risklevel");
	}

	// ����Ƿ������֤����Ϣ ����false��ʾ����Ҫ��֤��
	public static boolean needLgoin(RequestContext requestContext,
			String[] noAuths) {
		HttpServletRequest req = requestContext.getRequest();
		Operator op = requestContext.getOperator();
		if (op != null) {
			return false;
		}
		Route route = requestContext.getRoute();
		if ("login".equals(route.getControllerName())) {
			return false;
		}
		String token = req.getParameter("token");
		if (token != null && token.length() > 10)
			return true;
		String fpath = requestContext.getParameter(Constants.FORWARD);
		if (noAuths != null)
			for (int i = 0; i < noAuths.length; i++) {
				String t0 = noAuths[i];
				if (!t0.startsWith("/")) {
					t0 = "/" + t0;
				}
				if (fpath != null && fpath.startsWith(t0)) {
					return false;
				}
			}

		return true;
	}

	private static void decodeLogin(RequestContext requestContext,
			String encoded, String charset) {
		String username = null;
		String password = null;
		Base64.Decoder decoder = new Base64.Decoder();
		decoder.decode(encoded);
		String decoded = "";

		// Charset-aware decoding of the credentials bytes
		if (charset != null) {
			try {
				decoded = new String(decoder.drain(), charset);
			} catch (Exception ex) {
			}
		} else {
			decoded = new String(decoder.drain());
		}

		int colon = decoded.indexOf(":");
		if (colon > 0 && colon < decoded.length() - 1) {
			username = decoded.substring(0, colon);
			password = decoded.substring(colon + 1);
		}
		Map uMap = new HashMap();
		if (username != null && password != null) {
			uMap.put("username", username);
			uMap.put("password", password);
			requestContext.addParameterMap(uMap);
		}
	}
}
