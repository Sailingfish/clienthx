package com.hx.socket.domain;

public interface KeyValue {
	public Object getKey();

	public Object getValue();
}
