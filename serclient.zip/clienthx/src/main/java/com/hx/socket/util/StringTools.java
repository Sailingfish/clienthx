package com.hx.socket.util;

import java.io.UnsupportedEncodingException;

public class StringTools {
	private StringTools() {
	}

	public static String replace(String sVal) {
		return (sVal == null) ? "" : sVal;
	}

	/**
	 * �滻Null�ַ���Ϊָ��Ĭ��ֵ
	 * 
	 * @param sVal
	 * @param sDef
	 */
	public static String replace(String sVal, String sDef) {
		return (sVal == null) ? sDef : sVal;
	}

	public static String toSqlString(String source, String mark) {
		String t_str = "";
		if (source == null || mark == null)
			return null;
		if (source.trim().length() == 0)
			return "";
		String[] tempArray = source.split(mark);
		for (int i = 0; i < tempArray.length; i++) {
			if (i == 0)
				t_str += "'";
			t_str += tempArray[i];
			t_str += (i == tempArray.length - 1) ? "'" : "','";
		}
		return t_str;
	}

	/**
	 * �������ı��еķ����滻��html��ʶ
	 * 
	 * @param s
	 * @return s
	 */
	public static String escapeHTML(String s) {
		s = s.replaceAll("&", "&amp;");
		s = s.replaceAll("<", "&lt;");
		s = s.replaceAll(">", "&gt;");
		s = s.replaceAll("\"", "&quot;");
		s = s.replaceAll("'", "&apos;");
		return s;
	}

	/**
	 * ����html��ʶ�滻�ı��еķ���
	 * 
	 * @param s
	 * @return s
	 */
	public static String formatHTML(String s) {
		s = s.replaceAll("&nbsp;", " ");
		s = s.replaceAll("&amp;", "&");
		s = s.replaceAll("&lt;", "<");
		s = s.replaceAll("&gt;", ">");
		s = s.replaceAll("&quot;", "\"");
		s = s.replaceAll("&apos;", "'");
		return s;
	}

	/**
	 * ��strSource�е�strFromͳһ�滻ΪstrTo
	 * 
	 * @param strSource
	 * @param strFrom
	 * @param strTo
	 */
	public static String replace(String strSource, String strFrom, String strTo) {
		if (strSource == null || strFrom == null)
			return strSource;
		if (strTo == null)
			strTo = "";
		StringBuffer strDest = new StringBuffer(strSource);
		int intFromLen = strFrom.length();
		int intToLen = strTo.length();
		int intPos = 0;
		while ((intPos = strDest.indexOf(strFrom, intPos)) != -1) {
			strDest.replace(intPos, intPos + intFromLen, strTo);
			intPos += intToLen;
		}
		return strDest.toString();
	}

	/**
	 * ȡ��Ӣ�Ļ�ϵ��ַ�������,��һ�������ַ��������ֽڿ�
	 * 
	 * @param sStr
	 *            Ҫ�жϵ��ַ���
	 * @return int ����
	 */
	public static int getCnStrWidth(String sStr) {
		if (sStr == null)
			return 0;
		int c = 0;
		String b;
		for (int i = 0; i < sStr.length(); i++) {
			b = "" + sStr.charAt(i);
			c += (b.hashCode() < 256) ? 1 : 2;
		}
		return c;
	}

	/**
	 * ת���ַ������ַ�����Ӣ�ı��뵽���ı���
	 * 
	 * @param s_str
	 *            Ҫ�������ַ���
	 * @return ��������ַ���
	 */
	public static String toCnString(String s_str) {
		String n_str = "";
		if (s_str != null && s_str.length() > 0) {
			try {
				n_str = new String(s_str.getBytes("ISO8859-1"), "GB2312");
			} catch (Exception e) {
				n_str = "";
			}
		}
		return n_str;
	}

	/**
	 * ת���ַ������ַ������ı��뼯��Ӣ�ı���
	 * 
	 * @param s_str
	 *            Ҫ�������ַ���
	 * @return ��������ַ���
	 */
	public static String cnToEnEncode(String s_str) {
		String n_str = "";
		if (s_str != null && s_str.length() > 0) {
			try {
				n_str = new String(s_str.getBytes("GB2312"), "ISO8859-1");
			} catch (Exception e) {
				n_str = "";
			}
		}
		return n_str;
	}

	public String toUnicode(String strText, String code)
			throws UnsupportedEncodingException {
		char c;
		String strRet = "";
		int intAsc;
		String strHex;
		strText = new String(strText.getBytes("8859_1"), code);
		for (int i = 0; i < strText.length(); i++) {
			c = strText.charAt(i);
			intAsc = (int) c;
			if (intAsc > 128) {
				strHex = Integer.toHexString(intAsc);
				strRet = strRet + "&#x" + strHex + ";";
			} else {
				strRet = strRet + c;
			}
		}
		return strRet;
	}

	public static void main(String[] args) {
		/*
		 * String from = "\""; String to = "&quot;";
		 * System.out.println(StringTools.replace("jdkfdfjd\"dfjdkf\"fjdkf",
		 * from, to));
		 */

		try {
			String testStr = "����";
			byte[] byteGBK = testStr.getBytes("GBK");
			// String tempStr = new String(byteGBK, "iso8859-1");
			byte[] byteISO = testStr.getBytes("iso8859-1");
			for (int i = 0; i < byteGBK.length; i++) {
				System.out.println("GBK:[" + i + "]"
						+ Integer.toHexString(byteGBK[i]).substring(6, 8));
			}
			for (int i = 0; i < byteISO.length; i++) {
				System.out.println("ISO:[" + i + "]"
						+ Integer.toHexString(byteISO[i]));
			}

			String strRet = "";
			char c;
			int intAsc;
			String strHex;
			for (int i = 0; i < testStr.length(); i++) {
				c = testStr.charAt(i);
				intAsc = (int) c;
				if (intAsc > 128) {
					strHex = Integer.toHexString(intAsc);
					System.out.println(strHex);
					strRet = strRet + "&#x" + strHex + ";";
				} else {
					strRet = strRet + c;
				}
			}
			System.out.println(strRet);

		} catch (Exception e) {
			System.out.println(e.toString());
		}
	}

	/**
	 * ��to�����е�Ԫ����Ϊָ���ķ��Ž��кϲ�.<BR>
	 * String to[] = { "1", "2", "3", "4" };<BR>
	 * String f_str = arrayToStr( to, "'" );<BR>
	 * f_str => '1','2','3','4'<BR>
	 * 
	 * @param to
	 *            Ҫ�ϲ�������
	 * @param def
	 *            �ָ���
	 * @return �ַ���
	 */
	public static String arrayToStr(String to[], String def) {
		String t_str = def;
		for (int i = 0; i < to.length; i++) {
			t_str += to[i];
			t_str += (i == to.length - 1) ? def : def + "," + def;
		}
		return t_str;
	}

	public static String join(Object[] objs, char split) {
		StringBuffer buf = new StringBuffer();
		for (int i=0;i<objs.length;i++){
		//for (Object obj : objs) {
			Object obj = objs[i];
			if (obj == null)
				obj = "";
			buf.append(obj);
			buf.append(split);
		}
		return buf.toString();
	}
}
