package com.hx.socket;
import java.net.Socket;
import java.io.DataOutputStream;
import java.io.DataInputStream;
import java.io.IOException; 
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;

import com.hx.socket.util.HxFixParser;
import com.hx.socket.util.SocketTools;


public class FuncClient {
	
	public static void main(String[] args) {
		IHxCommand command = HxCommandFactory.proc_run("");
		//HxCommandImp command = HxCommandFactory.tdxca_czmm("2800", "280000005972", "888888");
		IHxCommand result = null;
		try {
			result = SocketClient.sendCaCmd(command.makeCmdBytes());
		} catch (IOException ioe) {
			System.out.println("ϵͳ����socketServer����ʧ��");
		}

		System.out.println("ReqType:=" + result.getReqType());
		System.out.println("RetCode:=" + result.getRetCode());
		System.out.println("SerialNo:=" + result.getSerialNo());
		System.out.println("FixLen:=" + result.getFixLength());
	
		HxFixParser fix = new HxFixParser(result.getFixBytes());
		int iRows = fix.getRecordCount();
		int iCols = fix.getFieldCount();
		for (int n=0; n<iCols; n++)
			System.out.println(fix.getFieldName(n));
		for (int i=0; i<iRows; i++) {
			for (int j=0; j<iCols; j++) {
				System.out.println(fix.getValue(i, j));
			}
		}
	}
}
