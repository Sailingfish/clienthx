package com.hx.socket.util;

import java.util.Properties;
import java.io.InputStream;
import java.io.IOException;

public class UtilParameters {

	static public String SOCKETSERVER = "socket_server";

	static public String SOCKETPORT = "socket_port";

	static private UtilParameters utilParamInstance = new UtilParameters();

	private String server = "10.200.120.10", port = "8888";

	private boolean encode = true;

	public void setEncode(boolean encode) {
		this.encode = encode;
	}

	public void setServer(String server) {
		this.server = server;
	}

	public void setPort(String port) {
		this.port = port;
	}

	public void setProps(Properties props) {
		this.props = props;
	}

	public Properties getProps() {
		return props;
	}

	private Properties props = null;

	protected UtilParameters() {
		init();
	}

	private void init() {
		// �ȴ�ϵͳ�Ļ��������ж�ȡ��û�еĻ����ڶ�����
		props = new Properties();
		server = System.getProperty("socket_server");
		port = System.getProperty("socket_port");
		String ecd = System.getProperty("encode");
		if (server != null && !"".equals(server) && port != null
				&& !"".equals(server)) {
			props.put("socket_server", server);
			props.put("socket_port", port);
			if (!"true".equals(ecd)){
				encode=false;
			}
			return;
		}
		InputStream is = getClass().getResourceAsStream("/util.ini");

		try {
			props.load(is);
			server = getValue("socket_server");
			port = getValue("socket_port");
			encode = "true".equals(getValue("encode"));
		} catch (Exception e) {
			//e.printStackTrace();
			//System.err.println(e
			//		+ "���ܶ�ȡ�����ļ� util.ini����ȷ��util.ini�� CLASSPATH ·����");
			throw new RuntimeException("���ܶ�ȡ�����ļ� util.ini����ȷ��util.ini�� CLASSPATH ·����");
		} finally {
			try {
				is.close();
				is = null;
			} catch (IOException e) {
				e.printStackTrace();
				return;
			}
		}
	}

	public void reload() {
		init();
	}

	static public UtilParameters getInstance() {
		return utilParamInstance;
	}

	public String getValue(String name) {
		return props.getProperty(name);
	}

	public String getServer() {
		return server;
	}

	public boolean isEncode() {
		return encode;
	}

	public String getPort() {
		return port;
	}

}
