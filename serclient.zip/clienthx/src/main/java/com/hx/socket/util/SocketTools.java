package com.hx.socket.util;

public class SocketTools {
	private SocketTools() {
	}

	public static byte[] h2l(byte[] b) {
		byte temp;
		int times = b.length / 2;
		for (int i = 0; i < times; i++) {
			temp = b[i];
			b[i] = b[b.length - 1 - i];
			b[b.length - 1 - i] = temp;
		}
		return b;
	}

	public static int bytes2int(byte[] b) {
		int mask = 0xff;
		int temp = 0;
		int res = 0;
		for (int i = 0; i < 4; i++) {
			res = res << 8;
			temp = b[i] & mask;
			res = res | temp;
		}
		return res;
	}

	public static byte[] int2bytes(int n) {
		byte[] b = new byte[4];
		b[0] = (byte) (n >> 24 & 0xff);
		b[1] = (byte) (n >> 16 & 0xff);
		b[2] = (byte) (n >> 8 & 0xff);
		b[3] = (byte) (n & 0xff);
		return b;
	}

	public static byte[] int2c_bytes(int n) {
		byte[] b = new byte[4];
		b[0] = (byte) (n & 0xff);
		b[1] = (byte) (n >> 8 & 0xff);
		b[2] = (byte) (n >> 16 & 0xff);
		b[3] = (byte) (n >> 24 & 0xff);
		return b;
	}

	public static int c_bytes2int(byte[] b) {
		int iRet = bytes2int(h2l(b));
		return iRet;
	}

	public String toHexString(int i) {
		return Integer.toHexString(i);
	}

}
