/*
 * �������� 2007-6-6
 *
 * TODO Ҫ���Ĵ����ɵ��ļ���ģ�壬��ת��
 * ���� �� ��ѡ�� �� Java �� ������ʽ �� ����ģ��
 */
package com.hx.socket;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.hx.socket.domain.Param;
import com.hx.socket.util.StringTools;
import com.hx.socket.util.UtilParameters;
import com.hx.util.HXJniTool;

public class HxCommandFactory {
	public final static char DIV = 0x01;

	public static IHxCommand proc_run(String errString) {
		IHxCommand command = null;
		/*
		 * List<Param> params = new ArrayList(); params.add(new
		 * Param("PROCEDURE_NAME", "proc_test")); params.add(new Param("ZJZH",
		 * "150000000001")); params.add(new Param("YYBID", "1500"));
		 * 
		 * //command = HxCommandHelper.buildStoreCommand(params); if (command !=
		 * null) return command;
		 * 
		 * int reqType = 0x8888; int serialNo = 1000001; // test StringBuffer
		 * cmdBuf = new StringBuffer(); cmdBuf.append("3"); cmdBuf.append(DIV);
		 * cmdBuf.append("1"); cmdBuf.append(DIV);
		 * cmdBuf.append("PROCEDURE_NAME"); cmdBuf.append(DIV);
		 * cmdBuf.append("ZJZH"); cmdBuf.append(DIV); cmdBuf.append("YYBID");
		 * cmdBuf.append(DIV); cmdBuf.append("proc_test"); cmdBuf.append(DIV);
		 * cmdBuf.append("150000000001"); cmdBuf.append(DIV);
		 * cmdBuf.append("1500"); cmdBuf.append(DIV); command = new
		 * HxcaCommand(reqType, serialNo, cmdBuf.toString() .getBytes());
		 */
		return command;
	}

	public static IHxCommand buildCommand(int type, Map params) {

		StringBuffer cmdBuf = new StringBuffer();
		int len = params.size();
		cmdBuf.append(len);
		cmdBuf.append(DIV);
		cmdBuf.append("1");
		cmdBuf.append(DIV);
		Object[] keys = new Object[len];
		Object[] values = new Object[len];
		Iterator ite = params.entrySet().iterator();
		int i = 0;
		while (ite.hasNext()) {
			Map.Entry p = (Map.Entry) ite.next();
			keys[i] = (String) p.getKey();
			values[i] = (String) p.getValue();
			i++;
		}
		cmdBuf.append(StringTools.join(keys, DIV));
		cmdBuf.append(StringTools.join(values, DIV));
		String buf = cmdBuf.toString();
		if (UtilParameters.getInstance().isEncode()) {
			buf = encrypt(buf);
		}

		IHxCommand command = new HxcaCommand(type, 1000001, buf.getBytes());
		return command;
	}

	public static IHxCommand buildCommand(int type, List params) {

		StringBuffer cmdBuf = new StringBuffer();
		int len = params.size();
		cmdBuf.append(len);
		cmdBuf.append(DIV);
		cmdBuf.append("1");
		cmdBuf.append(DIV);
		Object[] keys = new Object[len];
		Object[] values = new Object[len];
		for (int i = 0; i < len; i++) {
			Param p = (Param) params.get(i);
			keys[i] = (String) p.getKey();
			values[i] = (String) p.getValue();
		}
		cmdBuf.append(StringTools.join(keys, DIV));
		cmdBuf.append(StringTools.join(values, DIV));
		String buf = cmdBuf.toString();
		if (UtilParameters.getInstance().isEncode()) {
			buf = encrypt(buf);
		}

		IHxCommand command = new HxcaCommand(type, 1000001, buf.getBytes());
		return command;
	}

	public static IHxCommand buildCommand(List params) {

		StringBuffer cmdBuf = new StringBuffer();
		int len = params.size();
		cmdBuf.append(len);
		cmdBuf.append(DIV);
		cmdBuf.append("1");
		cmdBuf.append(DIV);
		Object[] keys = new Object[len];
		Object[] values = new Object[len];
		for (int i = 0; i < len; i++) {
			Param p = (Param) params.get(i);
			keys[i] = (String) p.getKey();
			values[i] = (String) p.getValue();
		}
		cmdBuf.append(StringTools.join(keys, DIV));
		cmdBuf.append(StringTools.join(values, DIV));
		String buf = cmdBuf.toString();
		if (UtilParameters.getInstance().isEncode()) {
			buf = encrypt(buf);
		}

		IHxCommand command = new HxcaCommand(0x2010, 1000001, buf.getBytes());
		return command;
	}

	public static String encrypt(String buf) {
		HXJniTool tool = new HXJniTool();
		return tool.Encrypt(buf);
	}

	public static String dncrypt(String buf) {
		HXJniTool tool = new HXJniTool();
		return tool.Dncrypt(buf);
	}

	public static IHxCommand buildStoreCommand(String storeName, List params) {
		params.add(0, new Param("PROCEDURE_NAME", storeName));
		return buildCommand(params);
	}

	public static IHxCommand error_value(String errString) {
		StringBuffer errBuf = new StringBuffer();
		errBuf.append("2");
		errBuf.append(DIV);
		errBuf.append("1");
		errBuf.append(DIV);
		errBuf.append("err_code");
		errBuf.append(DIV);
		errBuf.append("err_msg");
		errBuf.append(DIV);
		errBuf.append("-1");
		errBuf.append(DIV);
		errBuf.append(errString);
		errBuf.append(DIV);
		IHxCommand command = new HxcaCommand(-1, 0, 0, errBuf.toString()
				.getBytes());
		return command;
	}

	public static IHxCommand ret_value(int reqType, int retCode, int serialNo,
			byte[] fixBytes) {
		IHxCommand command = new HxcaCommand(reqType, retCode, serialNo,
				fixBytes);
		return command;
	}

	/**
	 * ��������,ע��zjzh,pwd���벻��Ϊnull,��ΪStringBuffer���Զ���nullת����"null"
	 * 
	 * @param zjzh
	 * @param pwd
	 * @return
	 */
	public static IHxCommand rzkl_czmm(String zjzh, String pwd) {
		int reqType = 0x0004;
		int serialNo = 1000001; // test
		StringBuffer cmdBuf = new StringBuffer();
		cmdBuf.append("2");
		cmdBuf.append(DIV);
		cmdBuf.append("1");
		cmdBuf.append(DIV);
		cmdBuf.append("CA_ZJZH");
		cmdBuf.append(DIV);
		cmdBuf.append("CA_RZKL");
		cmdBuf.append(DIV);
		cmdBuf.append(zjzh);
		cmdBuf.append(DIV);
		cmdBuf.append(pwd);
		cmdBuf.append(DIV);
		IHxCommand command = new HxcaCommand(reqType, serialNo, cmdBuf
				.toString().getBytes());
		return command;
	}

	/**
	 * ͨ������������
	 * 
	 * @param reqType
	 * @param serialNo
	 * @param yybid
	 * @param zjzh
	 * @param pwd
	 * @return
	 */
	public static IHxCommand tdxca_czmm(String yybid, String zjzh, String pwd) {
		pwd = StringTools.replace(pwd);
		int reqType = 0x1001;
		int serialNo = 1000001; // test
		StringBuffer cmdBuf = new StringBuffer();
		cmdBuf.append("4");
		cmdBuf.append(DIV);
		cmdBuf.append("1");
		cmdBuf.append(DIV);
		cmdBuf.append("QSID");
		cmdBuf.append(DIV);
		cmdBuf.append("YYBID");
		cmdBuf.append(DIV);
		cmdBuf.append("ZJZH");
		cmdBuf.append(DIV);
		cmdBuf.append("PWD");
		cmdBuf.append(DIV);
		cmdBuf.append("����֤ȯ");
		cmdBuf.append(DIV);
		cmdBuf.append(yybid);
		cmdBuf.append(DIV);
		cmdBuf.append(zjzh);
		cmdBuf.append(DIV);
		cmdBuf.append(pwd);
		cmdBuf.append(DIV);
		IHxCommand command = new HxcaCommand(reqType, serialNo, cmdBuf
				.toString().getBytes());
		return command;
	}

}
