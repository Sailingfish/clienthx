package com.hx.socket;

import com.hx.socket.util.SocketTools;

public class HxcaCommand implements IHxCommand {
	private final static char DIV = 0x01;
	private int reqType = 0; // ��������
	private int retCode = 0; // ������,0 �ɹ�������ʧ��
	private int fixLength = 0; // ���峤�ȣ���������ͷ���֣�
	private int serialNo = 0; // ���кţ�����˲����κ��޸ķ���
	private String szRoute = "0000"; // ·�ɴ��룬���ݴ˴��������
	private byte[] fixBytes = null;

	public HxcaCommand(int type, int no, byte[] bytes) {
		reqType = type;
		no = serialNo;
		fixBytes = bytes;
		fixLength = bytes.length;
	}

	public HxcaCommand(int type, int code, int no, byte[] bytes) {
		reqType = type;
		retCode = code;
		no = serialNo;
		fixBytes = bytes;
		fixLength = bytes.length;
	}

	public int getFixLength() {
		return fixLength;
	}

	public void setFixLength(int fixLength) {
		this.fixLength = fixLength;
	}

	public int getReqType() {
		return reqType;
	}

	public void setReqType(int reqType) {
		this.reqType = reqType;
	}

	public int getRetCode() {
		return retCode;
	}

	public void setRetCode(int retCode) {
		this.retCode = retCode;
	}

	public int getSerialNo() {
		return serialNo;
	}

	public void setSerialNo(int serialNo) {
		this.serialNo = serialNo;
	}

	public byte[] getFixBytes() {
		return fixBytes;
	}

	public void setFixBytes(byte[] fixBytes) {
		this.fixBytes = fixBytes;
	}

	public byte[] makeCmdBytes() {
		byte[] buf = new byte[25 + fixLength];
		byte[] temp = SocketTools.int2c_bytes(reqType);//0x8888, 
		System.arraycopy(temp, 0, buf, 0, temp.length);
		temp = SocketTools.int2c_bytes(retCode);
		System.arraycopy(temp, 0, buf, 4, temp.length);
		temp = SocketTools.int2c_bytes(fixLength);
		System.arraycopy(temp, 0, buf, 8, temp.length);
		temp = SocketTools.int2c_bytes(serialNo);
		System.arraycopy(temp, 0, buf, 12, temp.length);
		System.arraycopy(szRoute.getBytes(), 0, buf, 16,
				(szRoute.length() < 9) ? szRoute.length() : 9);
		System.arraycopy(fixBytes, 0, buf, 25, fixBytes.length);
		return buf;
	}
}
