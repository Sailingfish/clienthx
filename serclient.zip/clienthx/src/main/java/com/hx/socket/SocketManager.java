package com.hx.socket;
 
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.hx.socket.exception.SocketException;
import com.hx.socket.processor.IProcessor;

public class SocketManager {

	private static SocketManager instance;

	private SocketManager() {

	}

	public static SocketManager getInstance() {
		if (instance == null) {
			instance = new SocketManager();
		}
		return instance;
	}

	/*
	 * public SocketClient getSocketClient() { return null; }
	 */
	public Object execute(IHxCommand command, IProcessor process)
			throws SocketException {
		try {
			command = SocketClient.sendCaCmd(command.makeCmdBytes());
		} catch (IOException ioe) {
			throw new SocketException("ϵͳ����socketServer����ʧ��", ioe);
		}
		return process.process(command);
	}
}
