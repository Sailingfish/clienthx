package com.hx.socket.util;

import java.util.HashMap;
import java.util.ArrayList;

public class HxFixParser {
	public final static char DIV = 0x01;
	private int recordCount;
	private int fieldCount;
	private ArrayList valueList = new ArrayList();
	private HashMap no2FNameMap = new HashMap();

	public HxFixParser(byte[] byteBuf) {
		parse(byteBuf);
	}

	public int getFieldCount() {
		return fieldCount;
	}

	public int getRecordCount() {
		return recordCount;
	}

	/**
	 * ȡ��nField(0,1,2...)�е��ֶ�����
	 * 
	 * @nField �����
	 *@return ����
	 */
	public String getFieldName(int nField) {
		if (nField >= fieldCount)
			return null;
		return (String) no2FNameMap.get(new Integer(nField));
	}

	/**
	 * ȡ������ΪfieldName�ĵ�nRecord�е��ֶ�ֵ����
	 * 
	 * @param nRecord
	 * @param fieldName
	 * @return
	 */
	public String getValue(int nRecord, String fieldName) {
		if (nRecord >= recordCount)
			return null;
		HashMap valueMap = (HashMap) valueList.get(nRecord);
		return (String) valueMap.get(fieldName);
	}

	/**
	 * ȡ������ΪfieldName�ĵ�nRecord�е��ֶ�ֵ����
	 * 
	 * @param nRecord
	 * @param nField
	 * @return
	 */
	public String getValue(int nRecord, int nField) {
		if ((nRecord >= recordCount) || (nField >= fieldCount))
			return null;
		HashMap valueMap = (HashMap) valueList.get(nRecord);
		return (String) valueMap.get(no2FNameMap.get(new Integer(nField)));
	}

	/**
	 * ��Fix���������ݸ�ʽ��Fix�ַ������
	 * 
	 * @param stringBuf
	 * @return
	 */
	public boolean build(StringBuffer stringBuf) {
		stringBuf.append(fieldCount);
		stringBuf.append(DIV);
		stringBuf.append(recordCount);
		stringBuf.append(DIV);
		for (int i = 0; i < fieldCount; i++) {
			stringBuf.append(getFieldName(i));
			stringBuf.append(DIV);
		}
		for (int i = 0; i < recordCount; i++) {
			for (int j = 0; j < fieldCount; j++) {
				stringBuf.append(getValue(i, j));
				stringBuf.append(DIV);
			}
		}
		return true;
	}

	/**
	 * ��Fix��ʽ�ַ�������Fix����
	 * 
	 * @param byteBuf
	 * @param fixLength
	 * @return
	 */
	private boolean parse(byte[] byteBuf) {
		clear();
		int fixLength = byteBuf.length;
		int nStart = 0;
		int nField = 0;
		HashMap valueMapTemp = new HashMap();
		for (int i = 0; i < byteBuf.length; i++) {
			if (byteBuf[i] == 0x01) {
				int flen = i - nStart;
				switch (nField) {
				case 0: // ����
				{
					if (flen > 10) {
						return false;
					}
					String rdCountStr = new String(byteBuf, nStart, flen);
					fieldCount = Integer.parseInt(rdCountStr);
				}
					break;

				case 1: // ����
				{
					if (flen > 10) {
						return false;
					}
					String fdCountStr = new String(byteBuf, nStart, flen);
					recordCount = Integer.parseInt(fdCountStr);
				}
					break;

				default: {
					if (nField < 2 + fieldCount)// ����
					{
						String fNameStr = new String(byteBuf, nStart, flen);
						no2FNameMap.put(new Integer(nField - 2), fNameStr);
					} else // ֵ
					{
						int nf = nField - 2 - fieldCount;// ֵ�����
						int nRow = nf / fieldCount; // ֵӦ�����ڵ���
						int nCol = nf % fieldCount;

						String valueStr = new String(byteBuf, nStart, flen);
						valueMapTemp.put((String) no2FNameMap.get(new Integer(
								nCol)), valueStr);
						if (nCol == fieldCount - 1) {
							valueList.add(valueMapTemp.clone());
							valueMapTemp.clear();
						}
					}
				}
					break;
				}
				nStart = i + 1;
				nField++;
			}
		}
		return true;
	}

	/**
	 * ���fix����������
	 */
	public void clear() {
		recordCount = 0;
		fieldCount = 0;
		valueList.clear();
		no2FNameMap.clear();
	}
}
