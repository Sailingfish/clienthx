package com.hx.socket.processor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.hx.socket.IHxCommand;
import com.hx.socket.util.HxFixParser;

public class Listprocessor implements IProcessor {

	
	
	public Object process(IHxCommand command) {
		List list = new ArrayList();
		HxFixParser fix = new HxFixParser(command.getFixBytes());
		int iRows = fix.getRecordCount();
		int iCols = fix.getFieldCount();
		String[] fields = new String[iCols];
		for (int n = 0; n < iCols; n++)
			fields[n] = fix.getFieldName(n);
		for (int i = 0; i < iRows; i++) {
			Map map = new HashMap();
			for (int j = 0; j < iCols; j++) {
				map.put(fields[j], fix.getValue(i, j));
			}
			list.add(map);
		}
		return list;
	}

}
