package com.hx.socket;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

import com.hx.socket.util.SocketTools;
import com.hx.socket.util.UtilParameters;
import com.hx.util.HXJniTool;

public class SocketClient {

	static public IHxCommand sendCaCmd(byte[] byteContent) throws IOException {
		IHxCommand result = null;
		Socket clientSocket = null;
		DataOutputStream outbound = null;
		DataInputStream inbound = null;
		HXJniTool eTool = null;
		boolean isEncode = false;
		try {
			String socketServer = UtilParameters.getInstance().getServer();
			String socketPort = UtilParameters.getInstance().getPort();
			isEncode = UtilParameters.getInstance().isEncode();
			if (isEncode) {
				try {
					eTool = new HXJniTool();
					//byteContent = eTool.Encrypt(new String(byteContent))
					//		.getBytes();
				} catch (Error error) {
					isEncode = false;
				}
			}
			clientSocket = new Socket(socketServer, Integer.parseInt(socketPort));
			clientSocket.setSoTimeout(5000);
			outbound = new DataOutputStream(new BufferedOutputStream(clientSocket.getOutputStream()));
			inbound = new DataInputStream(new BufferedInputStream(clientSocket.getInputStream()));
			outbound.write(byteContent);
			outbound.flush();
			
			int reqType = 0;
			int retCode = 0;
			int fixLength = 0;
			int serialNo = 0;
			byte[] bHead = new byte[25];
			if ((inbound.read(bHead, 0, 25)) > 0) {
				byte[] bTempBuf = new byte[4];
				System.arraycopy(bHead, 0, bTempBuf, 0, 4);
				reqType = SocketTools.c_bytes2int(bTempBuf);
				System.arraycopy(bHead, 4, bTempBuf, 0, 4);
				retCode = SocketTools.c_bytes2int(bTempBuf);
				System.arraycopy(bHead, 8, bTempBuf, 0, 4);
				fixLength = SocketTools.c_bytes2int(bTempBuf);
				System.arraycopy(bHead, 12, bTempBuf, 0, 4);
				serialNo = SocketTools.c_bytes2int(bTempBuf);
				byte[] bFix = new byte[fixLength];
				
				int iPos = 0;
				int iLen = (fixLength>500)?500:fixLength;
				int iRead = 0;
				while (iPos < fixLength) {
					iRead = inbound.read( bFix, iPos, iLen );
					if (iRead != -1) {
						iPos = iPos + iRead;
						if (iPos+iLen>fixLength)
							iLen = fixLength - iPos;
					}

				}
				//inbound.read(bFix, 0, fixLength);
				
				if (isEncode) {
					bFix = eTool.Dncrypt(new String(bFix)).getBytes();
				}

				result = HxCommandFactory.ret_value(reqType, retCode, serialNo,
						bFix);
				
			}

		} catch (IOException ioe) {
			
			// result = HxCommandFactory.error_value("ϵͳ���쳣,SocketͨѶ����ʧ�ܣ�");
			throw ioe;// new InterruptedIOException("ϵͳ���쳣,SocketͨѶ����ʧ�ܣ�");
		} finally {
			if (outbound != null)
				outbound.close();
			if (inbound != null)
				inbound.close();
			if (clientSocket != null)
				clientSocket.close();
		}
		return result;
	}
}
