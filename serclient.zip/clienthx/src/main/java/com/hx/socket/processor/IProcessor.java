package com.hx.socket.processor;

import com.hx.socket.IHxCommand;

public interface IProcessor {
	public Object process(IHxCommand command);
}
