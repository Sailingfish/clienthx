package com.hx.test;

import java.util.ArrayList;
import java.util.List;

import com.hx.socket.HxCommandFactory;
import com.hx.socket.IHxCommand;
import com.hx.socket.SocketManager;
import com.hx.socket.domain.Param;
import com.hx.socket.exception.SocketException;
import com.hx.socket.processor.IProcessor;
import com.hx.socket.util.HxFixParser;
import com.hx.util.HXEncodeTool;
import com.hx.util.HXJniTool;

public class JRSocketTest
{
	
	public void testLogin() throws SocketException
	{
		List params = new ArrayList();
		Param param = new Param("acctype", "Z");
		params.add(param);
		
		param = new Param("account", "20000839712");
		params.add(param);
		param = new Param("orgid", "0200");
		params.add(param);
		
		param = new Param("operway", "g");
		params.add(param);
		String v = HXEncodeTool.getInstance().encode("hxsz@2008", "123321");//hxsz@20090423144800!@#$% 
		param = new Param("trdpwd", v);// KDEncode.getInstance().encode("1002001", "123321"));
		
		//paraMap.put("trdpwd", KDEncode.getInstance().encode("1002001", pwd));
		params.add(param);
		
		IHxCommand command = HxCommandFactory.buildCommand(0x2010, params);
		List list = (List) SocketManager.getInstance().execute(command, new IProcessor()
		{
			public Object process(IHxCommand command)
			{
				List list = new ArrayList();
				HxFixParser fix = new HxFixParser(command.getFixBytes());
				int iRows = fix.getRecordCount();
				int iCols = fix.getFieldCount();
				String[] fields = new String[iCols];
				for (int n = 0; n < iCols; n++)
					fields[n] = fix.getFieldName(n);
				int index = 0;
				try
				{
					for (int i = 0; i < iRows; i++)
					{
						index = 0;
						for (int j = 0; j < iCols; j++)
						{
							System.out.println("field=" + fields[j] + " value=" + fix.getValue(i, j));
						}
					}
				}
				catch (Exception e0)
				{
					e0.printStackTrace();
				}
				return list;
			}
			
		});
	}
	
	public static void main(String[] args) throws SocketException
	{
		JRSocketTest test = new JRSocketTest();
		test.testLogin();
	}
	
}
