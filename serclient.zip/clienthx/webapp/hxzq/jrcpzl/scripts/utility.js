

$(document).ready(function () {
							
	
	$('#accordion-1').easyAccordion({ 
			autoStart: true, 
			slideInterval: 10000
	});
	
	$('#accordion-2').easyAccordion({ 
			autoStart: false	
	});
	
	$('#accordion-3').easyAccordion({ 
			autoStart: true,
			slideInterval: 10000,
			slideNum:false	
	}); 
	
	$('#accordion-4').easyAccordion({ 
			autoStart: false,
			slideInterval: 10000
	}); 
		

});